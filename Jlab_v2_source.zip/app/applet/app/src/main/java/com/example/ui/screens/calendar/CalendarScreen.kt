package com.example.ui.screens.calendar

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.TaskEntity
import com.example.ui.components.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun CalendarScreen(
    tasks: List<TaskEntity>,
    onNavigateBack: () -> Unit
) {
    var selectedCalendarDate by remember { mutableStateOf(Calendar.getInstance()) }
    val daysInMonth = remember(selectedCalendarDate) {
        val cal = selectedCalendarDate.clone() as Calendar
        cal.set(Calendar.DAY_OF_MONTH, 1)
        val maxDays = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
        val list = mutableListOf<Calendar>()
        for (i in 1..maxDays) {
            val d = cal.clone() as Calendar
            d.set(Calendar.DAY_OF_MONTH, i)
            list.add(d)
        }
        list
    }

    val selectedDateYearMonthDay = remember(selectedCalendarDate) {
        SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(selectedCalendarDate.time)
    }

    val dayTasks = tasks.filter { task ->
        if (task.dueDate == null) false
        else {
            val taskDateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(task.dueDate))
            taskDateStr == selectedDateYearMonthDay
        }
    }

    Scaffold(
        topBar = {
            JlabTopBar(
                title = "Local Calendar",
                subtitle = SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(selectedCalendarDate.time)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Month navigation
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = {
                    val cal = selectedCalendarDate.clone() as Calendar
                    cal.add(Calendar.MONTH, -1)
                    selectedCalendarDate = cal
                }) {
                    Icon(imageVector = Icons.Default.ChevronLeft, contentDescription = "Previous Month")
                }

                Text(
                    text = SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(selectedCalendarDate.time),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                IconButton(onClick = {
                    val cal = selectedCalendarDate.clone() as Calendar
                    cal.add(Calendar.MONTH, 1)
                    selectedCalendarDate = cal
                }) {
                    Icon(imageVector = Icons.Default.ChevronRight, contentDescription = "Next Month")
                }
            }

            // Days horizontal ribbon
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(daysInMonth) { dateCal ->
                    val isSelected = dateCal.get(Calendar.DAY_OF_MONTH) == selectedCalendarDate.get(Calendar.DAY_OF_MONTH) &&
                            dateCal.get(Calendar.MONTH) == selectedCalendarDate.get(Calendar.MONTH)
                    val dayNum = dateCal.get(Calendar.DAY_OF_MONTH)
                    val dayName = SimpleDateFormat("EEE", Locale.getDefault()).format(dateCal.time)

                    Surface(
                        modifier = Modifier
                            .width(52.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { selectedCalendarDate = dateCal.clone() as Calendar },
                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
                        shadowElevation = if (isSelected) 3.dp else 1.dp
                    ) {
                        Column(
                            modifier = Modifier.padding(vertical = 10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = dayName,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "$dayNum",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            SectionHeader(
                title = "Agenda: ${SimpleDateFormat("EEEE, MMM d", Locale.getDefault()).format(selectedCalendarDate.time)}",
                count = dayTasks.size
            )

            if (dayTasks.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    EmptyState(
                        icon = Icons.Default.EventAvailable,
                        title = "No events on this day",
                        message = "No deadlines or tasks scheduled. Enjoy your clear schedule."
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(dayTasks) { task ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                PriorityBadge(priority = task.priority)
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = task.title,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    if (task.description.isNotBlank()) {
                                        Text(
                                            text = task.description,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                StatusBadge(status = task.status)
                            }
                        }
                    }
                }
            }
        }
    }
}

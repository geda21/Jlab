package com.example.ui.screens.search

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.*
import com.example.ui.components.EmptyState
import com.example.ui.components.JlabTopBar

data class SearchResult(
    val id: String,
    val type: String, // "TASK", "PROJECT", "NOTE", "PROMPT", "INFO", "LEARNING", "BUSINESS"
    val title: String,
    val subtitle: String,
    val category: String? = null
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GlobalSearchScreen(
    tasks: List<TaskEntity>,
    projects: List<ProjectEntity>,
    notes: List<NoteEntity>,
    prompts: List<PromptEntity>,
    infoList: List<InformationEntity>,
    learningList: List<LearningEntity>,
    businessList: List<BusinessEntity>,
    onSelectResult: (SearchResult) -> Unit,
    onNavigateBack: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }

    val results = remember(searchQuery, tasks, projects, notes, prompts, infoList, learningList, businessList) {
        if (searchQuery.isBlank()) emptyList()
        else {
            val q = searchQuery.trim().lowercase()
            val list = mutableListOf<SearchResult>()

            tasks.filter { it.title.lowercase().contains(q) || it.description.lowercase().contains(q) }
                .forEach { list.add(SearchResult(it.id, "TASK", it.title, it.description, it.priority)) }

            projects.filter { it.name.lowercase().contains(q) || it.objective.lowercase().contains(q) }
                .forEach { list.add(SearchResult(it.id, "PROJECT", it.name, it.objective, it.status)) }

            notes.filter { it.title.lowercase().contains(q) || it.content.lowercase().contains(q) }
                .forEach { list.add(SearchResult(it.id, "NOTE", it.title.ifBlank { "Untitled Note" }, com.example.ui.screens.notes.RichTextParser.toPlainText(it.content), it.category)) }

            prompts.filter { it.title.lowercase().contains(q) || it.fullPrompt.lowercase().contains(q) }
                .forEach { list.add(SearchResult(it.id, "PROMPT", it.title, it.fullPrompt, it.category)) }

            infoList.filter { it.title.lowercase().contains(q) || it.information.lowercase().contains(q) }
                .forEach { list.add(SearchResult(it.id, "INFORMATION", it.title, it.information, it.category)) }

            learningList.filter { it.title.lowercase().contains(q) || it.goal.lowercase().contains(q) }
                .forEach { list.add(SearchResult(it.id, "LEARNING", it.title, it.goal, it.type)) }

            businessList.filter { it.name.lowercase().contains(q) || it.description.lowercase().contains(q) }
                .forEach { list.add(SearchResult(it.id, "BUSINESS", it.name, it.description)) }

            list
        }
    }

    Scaffold(
        topBar = {
            JlabTopBar(
                title = "Global Search",
                subtitle = "Search everything offline",
                navigationIcon = Icons.Default.ArrowBack,
                onNavigationClick = onNavigateBack
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search tasks, projects, notes, prompts, knowledge...") },
                leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(12.dp)
            )

            if (searchQuery.isBlank()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        text = "Type any keyword to search across all Jlab modules.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else if (results.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    EmptyState(
                        icon = Icons.Default.SearchOff,
                        title = "No results found",
                        message = "No matching items for '$searchQuery'"
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(results) { res ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelectResult(res) },
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = res.type,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = res.title,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    if (res.subtitle.isNotBlank()) {
                                        Text(
                                            text = res.subtitle,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

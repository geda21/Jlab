package com.example.ui.screens.prompts

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.PromptEntity
import com.example.ui.components.*
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

enum class PromptFilterTab(val label: String) {
    ALL("All"),
    FAVORITES("Favorites"),
    RECENT("Recent")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PromptsScreen(
    prompts: List<PromptEntity>,
    onSavePrompt: (PromptEntity) -> Unit,
    onMarkCopied: (String) -> Unit,
    onDeletePrompt: (String) -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilterTab by remember { mutableStateOf(PromptFilterTab.ALL) }
    var selectedCategoryFilter by remember { mutableStateOf<String?>(null) }

    var showEditor by remember { mutableStateOf(false) }
    var editingPrompt by remember { mutableStateOf<PromptEntity?>(null) }
    var viewingPromptDetail by remember { mutableStateOf<PromptEntity?>(null) }
    var promptToDelete by remember { mutableStateOf<PromptEntity?>(null) }
    var promptToFillVariables by remember { mutableStateOf<PromptEntity?>(null) }

    // Derive active user categories dynamically
    val userCategories = remember(prompts) {
        prompts.map { it.category.trim() }.filter { it.isNotBlank() }.distinct().sorted()
    }

    val filteredPrompts = remember(prompts, searchQuery, selectedFilterTab, selectedCategoryFilter) {
        var list = prompts

        // Filter by tab
        list = when (selectedFilterTab) {
            PromptFilterTab.ALL -> list
            PromptFilterTab.FAVORITES -> list.filter { it.isFavorite }
            PromptFilterTab.RECENT -> list.sortedByDescending { it.lastCopiedAt ?: it.updatedAt }
        }

        // Filter by category if selected
        if (selectedCategoryFilter != null) {
            list = list.filter { it.category.equals(selectedCategoryFilter, ignoreCase = true) }
        }

        // Search query across title, fullPrompt, category, tags, notes
        if (searchQuery.isNotBlank()) {
            val q = searchQuery.trim().lowercase()
            list = list.filter {
                it.title.lowercase().contains(q) ||
                it.fullPrompt.lowercase().contains(q) ||
                it.category.lowercase().contains(q) ||
                it.tags.lowercase().contains(q) ||
                it.notes.lowercase().contains(q)
            }
        }

        list
    }

    // Full Prompt Editor View
    if (showEditor || editingPrompt != null) {
        PromptEditorScreen(
            initialPrompt = editingPrompt,
            existingCategories = userCategories,
            onSave = { saved ->
                onSavePrompt(saved)
                showEditor = false
                editingPrompt = null
            },
            onDismiss = {
                showEditor = false
                editingPrompt = null
            }
        )
        return
    }

    // Full Prompt Detail View
    if (viewingPromptDetail != null) {
        val currentDetail = viewingPromptDetail!!
        PromptDetailView(
            prompt = currentDetail,
            onCopy = {
                val variables = extractPromptVariables(currentDetail.fullPrompt)
                if (variables.isNotEmpty()) {
                    promptToFillVariables = currentDetail
                } else {
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("Jlab Prompt", currentDetail.fullPrompt))
                    onMarkCopied(currentDetail.id)
                    Toast.makeText(context, "Prompt copied to clipboard!", Toast.LENGTH_SHORT).show()
                }
            },
            onFillVariables = {
                promptToFillVariables = currentDetail
            },
            onEdit = {
                editingPrompt = currentDetail
                viewingPromptDetail = null
            },
            onToggleFavorite = {
                val updated = currentDetail.copy(isFavorite = !currentDetail.isFavorite)
                onSavePrompt(updated)
                viewingPromptDetail = updated
            },
            onDuplicate = {
                val duplicate = currentDetail.copy(
                    id = UUID.randomUUID().toString(),
                    title = "${currentDetail.title} (Copy)",
                    createdAt = System.currentTimeMillis(),
                    updatedAt = System.currentTimeMillis()
                )
                onSavePrompt(duplicate)
                Toast.makeText(context, "Prompt duplicated!", Toast.LENGTH_SHORT).show()
                viewingPromptDetail = null
            },
            onDelete = {
                promptToDelete = currentDetail
                viewingPromptDetail = null
            },
            onBack = { viewingPromptDetail = null }
        )
        return
    }

    Scaffold(
        topBar = {
            JlabTopBar(
                title = "Prompt Library",
                subtitle = if (prompts.isEmpty()) "Private storage" else "${prompts.size} saved prompts",
                navigationIcon = Icons.Default.ArrowBack,
                onNavigationClick = onNavigateBack,
                actions = {
                    IconButton(onClick = { showEditor = true }) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Add Prompt")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Search Bar
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surface,
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    TextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Search prompts, tags, notes...", style = MaterialTheme.typography.bodyMedium) },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent
                        )
                    )
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }, modifier = Modifier.size(24.dp)) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Clear", modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }

            // Filters Ribbon (Tabs + Dynamic user categories)
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(PromptFilterTab.values()) { tab ->
                    FilterChip(
                        selected = selectedFilterTab == tab && selectedCategoryFilter == null,
                        onClick = {
                            selectedFilterTab = tab
                            selectedCategoryFilter = null
                        },
                        label = { Text(tab.label, style = MaterialTheme.typography.labelMedium) }
                    )
                }

                items(userCategories) { cat ->
                    FilterChip(
                        selected = selectedCategoryFilter == cat,
                        onClick = {
                            selectedCategoryFilter = if (selectedCategoryFilter == cat) null else cat
                        },
                        label = { Text(cat, style = MaterialTheme.typography.labelMedium) }
                    )
                }
            }

            // Prompt List or Empty State
            if (filteredPrompts.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(bottom = 60.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier.padding(32.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.surfaceVariant),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = if (searchQuery.isNotBlank() || selectedCategoryFilter != null) "No matching prompts" else "Prompt Library",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (searchQuery.isNotBlank()) "Try different keywords or clear filters." else "Save the prompts you want to reuse.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (searchQuery.isBlank() && selectedCategoryFilter == null) {
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Your prompts stay on this device.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f)
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = { showEditor = true },
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Add Prompt", style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 90.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredPrompts, key = { it.id }) { prompt ->
                        val variables = remember(prompt.fullPrompt) { extractPromptVariables(prompt.fullPrompt) }
                        PromptCompactCard(
                            prompt = prompt,
                            variableCount = variables.size,
                            onClick = { viewingPromptDetail = prompt },
                            onCopy = {
                                if (variables.isNotEmpty()) {
                                    promptToFillVariables = prompt
                                } else {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("Jlab Prompt", prompt.fullPrompt))
                                    onMarkCopied(prompt.id)
                                    Toast.makeText(context, "Prompt copied to clipboard!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            onToggleFavorite = {
                                onSavePrompt(prompt.copy(isFavorite = !prompt.isFavorite))
                            }
                        )
                    }
                }
            }
        }
    }

    // Fill Variables Dialog
    promptToFillVariables?.let { prompt ->
        FillVariablesDialog(
            prompt = prompt,
            onDismiss = { promptToFillVariables = null },
            onCopyFilled = { filledText ->
                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("Jlab Filled Prompt", filledText))
                onMarkCopied(prompt.id)
                Toast.makeText(context, "Filled prompt copied!", Toast.LENGTH_SHORT).show()
                promptToFillVariables = null
            },
            onCopyRaw = {
                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("Jlab Prompt Template", prompt.fullPrompt))
                onMarkCopied(prompt.id)
                Toast.makeText(context, "Raw template copied!", Toast.LENGTH_SHORT).show()
                promptToFillVariables = null
            }
        )
    }

    // Delete Confirmation Dialog
    promptToDelete?.let { prompt ->
        AlertDialog(
            onDismissRequest = { promptToDelete = null },
            title = { Text("Delete Prompt") },
            text = { Text("Are you sure you want to delete '${prompt.title}'?") },
            confirmButton = {
                Button(
                    onClick = {
                        onDeletePrompt(prompt.id)
                        promptToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { promptToDelete = null }) { Text("Cancel") }
            }
        )
    }
}

@Composable
fun PromptCompactCard(
    prompt: PromptEntity,
    variableCount: Int,
    onClick: () -> Unit,
    onCopy: () -> Unit,
    onToggleFavorite: () -> Unit
) {
    val relativeTime = formatPromptRelativeTime(prompt.updatedAt)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header Row: Title & Favorite Star
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = prompt.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                IconButton(
                    onClick = onToggleFavorite,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = if (prompt.isFavorite) Icons.Default.Star else Icons.Outlined.StarBorder,
                        contentDescription = "Favorite",
                        tint = if (prompt.isFavorite) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // Category & Variable Chips Row
            Row(
                modifier = Modifier.padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = prompt.category,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp)
                    )
                }

                if (variableCount > 0) {
                    Surface(
                        color = JlabIndigoContainerLight,
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = "$variableCount var${if (variableCount > 1) "s" else ""}",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = JlabIndigoPrimary,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp)
                        )
                    }
                }

                if (prompt.tags.isNotBlank()) {
                    Text(
                        text = prompt.tags,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Snippet Preview (max 2 lines)
            Text(
                text = prompt.fullPrompt,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 4.dp, bottom = 8.dp)
            )

            // Footer Row: Updated time & 1-tap Copy Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Updated $relativeTime",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Button(
                    onClick = onCopy,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp),
                    modifier = Modifier.height(30.dp)
                ) {
                    Icon(imageVector = if (variableCount > 0) Icons.Default.Tune else Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (variableCount > 0) "Fill & Copy" else "Copy", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PromptDetailView(
    prompt: PromptEntity,
    onCopy: () -> Unit,
    onFillVariables: () -> Unit,
    onEdit: () -> Unit,
    onToggleFavorite: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var showMenu by remember { mutableStateOf(false) }
    val variables = remember(prompt.fullPrompt) { extractPromptVariables(prompt.fullPrompt) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(prompt.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = onToggleFavorite) {
                        Icon(
                            imageVector = if (prompt.isFavorite) Icons.Default.Star else Icons.Outlined.StarBorder,
                            contentDescription = "Favorite",
                            tint = if (prompt.isFavorite) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurface
                        )
                    }
                    IconButton(onClick = onEdit) {
                        Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit")
                    }
                    IconButton(onClick = { showMenu = true }) {
                        Icon(imageVector = Icons.Default.MoreVert, contentDescription = "More")
                    }
                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Duplicate") },
                            onClick = {
                                showMenu = false
                                onDuplicate()
                            },
                            leadingIcon = { Icon(Icons.Default.ContentCopy, contentDescription = null) }
                        )
                        DropdownMenuItem(
                            text = { Text("Share Template") },
                            onClick = {
                                showMenu = false
                                val sendIntent = Intent().apply {
                                    action = Intent.ACTION_SEND
                                    putExtra(Intent.EXTRA_TEXT, prompt.fullPrompt)
                                    type = "text/plain"
                                }
                                context.startActivity(Intent.createChooser(sendIntent, "Share Prompt"))
                            },
                            leadingIcon = { Icon(Icons.Default.Share, contentDescription = null) }
                        )
                        HorizontalDivider()
                        DropdownMenuItem(
                            text = { Text("Delete", color = MaterialTheme.colorScheme.error) },
                            onClick = {
                                showMenu = false
                                onDelete()
                            },
                            leadingIcon = { Icon(Icons.Default.DeleteOutline, contentDescription = null, tint = MaterialTheme.colorScheme.error) }
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Badges
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = prompt.category,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }

                if (variables.isNotEmpty()) {
                    Surface(
                        color = JlabIndigoContainerLight,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = "${variables.size} Placeholders",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = JlabIndigoPrimary,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }

                if (prompt.tags.isNotBlank()) {
                    Text(
                        text = prompt.tags,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Copy Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (variables.isNotEmpty()) {
                    Button(
                        onClick = onFillVariables,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Tune, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Fill & Copy", fontWeight = FontWeight.Bold)
                    }
                }

                OutlinedButton(
                    onClick = onCopy,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                ) {
                    Icon(imageVector = Icons.Default.CopyAll, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(if (variables.isNotEmpty()) "Copy Raw" else "Copy Prompt", fontWeight = FontWeight.Bold)
                }
            }

            // Optional Notes Card (if present)
            if (prompt.notes.isNotBlank() || prompt.purpose.isNotBlank()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "Notes / Purpose",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (prompt.notes.isNotBlank()) prompt.notes else prompt.purpose,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Prompt Content Box
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Template Content",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "${prompt.fullPrompt.length} chars",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = prompt.fullPrompt,
                        style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 22.sp),
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

@Composable
fun FillVariablesDialog(
    prompt: PromptEntity,
    onDismiss: () -> Unit,
    onCopyFilled: (String) -> Unit,
    onCopyRaw: () -> Unit
) {
    val variableNames = remember(prompt.fullPrompt) { extractPromptVariables(prompt.fullPrompt) }
    val variableValues = remember { mutableStateMapOf<String, String>() }

    // Live generated prompt
    val liveFilledPrompt = remember(prompt.fullPrompt, variableValues.toMap()) {
        var result = prompt.fullPrompt
        for (vName in variableNames) {
            val userVal = variableValues[vName]?.trim()
            val replacement = if (!userVal.isNullOrBlank()) userVal else "{$vName}"
            result = result.replace("{$vName}", replacement)
        }
        result
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.Tune, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Fill Prompt Variables", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Fill in the placeholders for '${prompt.title}':",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                variableNames.forEach { vName ->
                    OutlinedTextField(
                        value = variableValues[vName] ?: "",
                        onValueChange = { variableValues[vName] = it },
                        label = { Text("{$vName}") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text("Live Preview:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = liveFilledPrompt,
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(10.dp),
                        maxLines = 6,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onCopyFilled(liveFilledPrompt) },
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Copy Filled")
            }
        },
        dismissButton = {
            Row {
                TextButton(onClick = onCopyRaw) {
                    Text("Copy Raw")
                }
                TextButton(onClick = onDismiss) {
                    Text("Cancel")
                }
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PromptEditorScreen(
    initialPrompt: PromptEntity?,
    existingCategories: List<String>,
    onSave: (PromptEntity) -> Unit,
    onDismiss: () -> Unit
) {
    var title by remember { mutableStateOf(initialPrompt?.title ?: "") }
    var fullPrompt by remember { mutableStateOf(initialPrompt?.fullPrompt ?: "") }
    var category by remember { mutableStateOf(initialPrompt?.category ?: if (existingCategories.isNotEmpty()) existingCategories.first() else "General") }
    var customCategoryInput by remember { mutableStateOf("") }
    var isCustomCategoryMode by remember { mutableStateOf(false) }
    var tags by remember { mutableStateOf(initialPrompt?.tags ?: "") }
    var notes by remember { mutableStateOf(initialPrompt?.notes ?: "") }

    val suggestedCategories = listOf("General", "Coding", "Business", "Marketing", "Research", "Writing", "Design", "Productivity")
    val allCategoryOptions = (suggestedCategories + existingCategories).distinct()

    val quickVariables = listOf("topic", "role", "audience", "tone", "format", "context", "instructions", "language")

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (initialPrompt != null) "Edit Prompt" else "Add Prompt", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                    }
                },
                actions = {
                    Button(
                        onClick = {
                            if (title.isNotBlank() && fullPrompt.isNotBlank()) {
                                val finalCategory = if (isCustomCategoryMode && customCategoryInput.isNotBlank()) {
                                    customCategoryInput.trim()
                                } else {
                                    category.trim().ifBlank { "General" }
                                }

                                val entity = initialPrompt?.copy(
                                    title = title.trim(),
                                    fullPrompt = fullPrompt.trim(),
                                    category = finalCategory,
                                    tags = tags.trim(),
                                    notes = notes.trim(),
                                    updatedAt = System.currentTimeMillis()
                                ) ?: PromptEntity(
                                    title = title.trim(),
                                    fullPrompt = fullPrompt.trim(),
                                    category = finalCategory,
                                    tags = tags.trim(),
                                    notes = notes.trim()
                                )
                                onSave(entity)
                            }
                        },
                        enabled = title.isNotBlank() && fullPrompt.isNotBlank(),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Save")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Prompt Title *") },
                placeholder = { Text("e.g. Clean Code Reviewer") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            // Category Selector with Custom Category Support
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Category:", style = MaterialTheme.typography.labelMedium)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(allCategoryOptions) { cat ->
                        FilterChip(
                            selected = !isCustomCategoryMode && category == cat,
                            onClick = {
                                category = cat
                                isCustomCategoryMode = false
                            },
                            label = { Text(cat, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                    item {
                        FilterChip(
                            selected = isCustomCategoryMode,
                            onClick = { isCustomCategoryMode = true },
                            label = { Text("+ Custom", style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                if (isCustomCategoryMode) {
                    OutlinedTextField(
                        value = customCategoryInput,
                        onValueChange = { customCategoryInput = it },
                        label = { Text("Enter Custom Category Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            }

            // Quick Variable Insertion Ribbon
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Insert Variables into Prompt:", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(quickVariables) { v ->
                        AssistChip(
                            onClick = {
                                fullPrompt += " {$v}"
                            },
                            label = { Text("+$v", style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
            }

            // Prompt Content Box
            OutlinedTextField(
                value = fullPrompt,
                onValueChange = { fullPrompt = it },
                label = { Text("Prompt Template * (${fullPrompt.length} chars)") },
                placeholder = { Text("Act as a senior engineer. Review the following {language} code for {topic}...\n\nInstructions: {instructions}") },
                minLines = 8,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 200.dp),
                shape = RoundedCornerShape(12.dp)
            )

            OutlinedTextField(
                value = tags,
                onValueChange = { tags = it },
                label = { Text("Tags (optional)") },
                placeholder = { Text("#engineering #review #quality") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Notes / Purpose (optional)") },
                placeholder = { Text("Guidance or context on when to run this prompt...") },
                minLines = 2,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )
        }
    }
}

// Regex to extract all variables of the form {variable_name}
fun extractPromptVariables(text: String): List<String> {
    val regex = Regex("\\{([a-zA-Z0-9_-]+)\\}")
    return regex.findAll(text).map { it.groupValues[1] }.distinct().toList()
}

private fun formatPromptRelativeTime(timestamp: Long): String {
    val diff = System.currentTimeMillis() - timestamp
    val mins = diff / (60 * 1000)
    val hours = diff / (60 * 60 * 1000)
    val days = diff / (24 * 60 * 60 * 1000)

    return when {
        mins < 1 -> "just now"
        mins < 60 -> "${mins}m ago"
        hours < 24 -> "${hours}h ago"
        days == 1L -> "yesterday"
        days < 7 -> "${days}d ago"
        else -> SimpleDateFormat("MMM d", Locale.getDefault()).format(Date(timestamp))
    }
}

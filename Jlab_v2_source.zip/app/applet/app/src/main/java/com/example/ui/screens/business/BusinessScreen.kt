package com.example.ui.screens.business

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.*
import com.example.ui.components.EmptyState
import com.example.ui.theme.*
import kotlinx.coroutines.flow.Flow
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BusinessScreen(
    businesses: List<BusinessEntity>,
    allTasks: List<TaskEntity> = emptyList(),
    allProjects: List<ProjectEntity> = emptyList(),
    allGoals: List<GoalEntity> = emptyList(),
    allNotes: List<NoteEntity> = emptyList(),
    allFiles: List<FileAttachmentEntity> = emptyList(),
    activities: List<ActivityEntity> = emptyList(),
    onSaveBusiness: (BusinessEntity) -> Unit,
    onDeleteBusiness: (String) -> Unit,
    onSaveGoal: (GoalEntity) -> Unit,
    onDeleteGoal: (String) -> Unit,
    onSaveTask: (TaskEntity) -> Unit,
    onCompleteTask: (String, String) -> Unit,
    onDeleteTask: (String) -> Unit,
    onSaveProject: (ProjectEntity) -> Unit,
    onOpenProject: (ProjectEntity) -> Unit,
    onOpenNote: (NoteEntity) -> Unit,
    onCreateBusinessNote: (String) -> Unit,
    onOpenResource: (FileAttachmentEntity) -> Unit,
    onAttachResource: (String) -> Unit,
    onNavigateBack: () -> Unit
) {
    var selectedBusiness by remember { mutableStateOf<BusinessEntity?>(null) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedStatusFilter by remember { mutableStateOf("ALL") }
    val statusFilters = listOf("ALL", "ACTIVE", "PAUSED", "PLANNING")

    var showCreateDialog by remember { mutableStateOf(false) }

    val currentBusiness = remember(businesses, selectedBusiness) {
        selectedBusiness?.let { sb -> businesses.find { it.id == sb.id } ?: sb }
    }

    BackHandler {
        if (selectedBusiness != null) {
            selectedBusiness = null
        } else {
            onNavigateBack()
        }
    }

    // 1. BUSINESS DETAIL WORKSPACE VIEW
    if (currentBusiness != null) {
        val bizGoals = remember(allGoals, currentBusiness.id) { allGoals.filter { it.businessId == currentBusiness.id } }
        val bizTasks = remember(allTasks, currentBusiness.id) { allTasks.filter { it.businessId == currentBusiness.id } }
        val bizProjects = remember(allProjects, currentBusiness.id) { allProjects.filter { it.businessId == currentBusiness.id } }
        val bizNotes = remember(allNotes, currentBusiness.id) { allNotes.filter { it.businessId == currentBusiness.id } }
        val bizFiles = remember(allFiles, currentBusiness.id) { allFiles.filter { it.businessId == currentBusiness.id } }

        BusinessDetailScreen(
            business = currentBusiness,
            goals = bizGoals,
            tasks = bizTasks,
            projects = bizProjects,
            notes = bizNotes,
            resources = bizFiles,
            allProjects = allProjects,
            activities = activities,
            onUpdateBusiness = { updated ->
                onSaveBusiness(updated)
                selectedBusiness = updated
            },
            onDeleteBusiness = {
                onDeleteBusiness(currentBusiness.id)
                selectedBusiness = null
            },
            onSaveGoal = onSaveGoal,
            onDeleteGoal = onDeleteGoal,
            onSaveTask = onSaveTask,
            onCompleteTask = onCompleteTask,
            onDeleteTask = onDeleteTask,
            onLinkProject = { projId ->
                val p = allProjects.find { it.id == projId }
                if (p != null) {
                    onSaveProject(p.copy(businessId = currentBusiness.id))
                }
            },
            onCreateProject = onSaveProject,
            onOpenProject = onOpenProject,
            onOpenNote = onOpenNote,
            onCreateNote = { onCreateBusinessNote(currentBusiness.id) },
            onOpenResource = onOpenResource,
            onAttachResource = { onAttachResource(currentBusiness.id) },
            onBack = { selectedBusiness = null }
        )
        return
    }

    // 2. BUSINESS HOME LIST VIEW
    val filteredBusinesses = remember(businesses, searchQuery, selectedStatusFilter) {
        var list = businesses
        if (selectedStatusFilter != "ALL") {
            list = list.filter { it.status.equals(selectedStatusFilter, ignoreCase = true) }
        }
        if (searchQuery.isNotBlank()) {
            val q = searchQuery.trim().lowercase()
            list = list.filter {
                it.name.lowercase().contains(q) ||
                it.description.lowercase().contains(q) ||
                it.goals.lowercase().contains(q)
            }
        }
        list
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Business Workspace",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${businesses.size} entrepreneurial ventures",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { showCreateDialog = true }) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "New Business", tint = MaterialTheme.colorScheme.primary)
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Search Input
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search businesses, goals, offerings...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // Status Filter Chips
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    statusFilters.forEach { status ->
                        FilterChip(
                            selected = selectedStatusFilter == status,
                            onClick = { selectedStatusFilter = status },
                            label = { Text(status) }
                        )
                    }
                }
            }

            // List or Empty State
            if (filteredBusinesses.isEmpty()) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(vertical = 32.dp), contentAlignment = Alignment.Center) {
                        EmptyState(
                            icon = Icons.Default.BusinessCenter,
                            title = if (searchQuery.isNotEmpty()) "No matching businesses" else "No business records",
                            message = "Organize ventures, revenue goals, marketing angles, and product offerings.",
                            actionButtonText = "New Business",
                            onActionClick = { showCreateDialog = true }
                        )
                    }
                }
            } else {
                items(filteredBusinesses, key = { it.id }) { biz ->
                    val bizGoals = allGoals.count { it.businessId == biz.id }
                    val bizTasks = allTasks.count { it.businessId == biz.id && it.status != "COMPLETED" }
                    val bizProjects = allProjects.count { it.businessId == biz.id }
                    val bizNotes = allNotes.count { it.businessId == biz.id }

                    CompactBusinessCard(
                        business = biz,
                        goalsCount = bizGoals,
                        tasksCount = bizTasks,
                        projectsCount = bizProjects,
                        notesCount = bizNotes,
                        onClick = { selectedBusiness = biz },
                        onDelete = { onDeleteBusiness(biz.id) }
                    )
                }
            }
        }
    }

    if (showCreateDialog) {
        CreateBusinessDialog(
            onDismiss = { showCreateDialog = false },
            onSave = { newBiz ->
                onSaveBusiness(newBiz)
                showCreateDialog = false
                selectedBusiness = newBiz
            }
        )
    }
}

@Composable
private fun CompactBusinessCard(
    business: BusinessEntity,
    goalsCount: Int,
    tasksCount: Int,
    projectsCount: Int,
    notesCount: Int,
    onClick: () -> Unit,
    onDelete: () -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = JlabEmerald.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = business.status,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = JlabEmerald,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }

                Box {
                    IconButton(onClick = { showMenu = true }, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.MoreVert, contentDescription = "Options", modifier = Modifier.size(16.dp))
                    }
                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Open Workspace") },
                            onClick = {
                                showMenu = false
                                onClick()
                            },
                            leadingIcon = { Icon(Icons.Default.OpenInNew, contentDescription = null) }
                        )
                        HorizontalDivider()
                        DropdownMenuItem(
                            text = { Text("Delete Business", color = MaterialTheme.colorScheme.error) },
                            onClick = {
                                showMenu = false
                                onDelete()
                            },
                            leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = business.name,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            if (business.description.isNotBlank()) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = business.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Operational metrics row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                MetricSmallPill(label = "$goalsCount Goals", icon = Icons.Outlined.Flag)
                MetricSmallPill(label = "$tasksCount Tasks", icon = Icons.Outlined.CheckCircle)
                MetricSmallPill(label = "$projectsCount Projects", icon = Icons.Outlined.Folder)
                MetricSmallPill(label = "$notesCount Notes", icon = Icons.Outlined.NoteAlt)
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Open Workspace →",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

@Composable
private fun MetricSmallPill(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(12.dp))
            Text(text = label, style = MaterialTheme.typography.labelSmall, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun CreateBusinessDialog(
    onDismiss: () -> Unit,
    onSave: (BusinessEntity) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var goals by remember { mutableStateOf("") }
    var revenueNotes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New Business Venture", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Business Name *") },
                    placeholder = { Text("e.g. Fiverr Services, SaaS, Shop") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Value Proposition") },
                    placeholder = { Text("What product or service is delivered?") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = goals,
                    onValueChange = { goals = it },
                    label = { Text("Primary Growth Goal") },
                    placeholder = { Text("e.g. Get 5 consistent client orders/month") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = revenueNotes,
                    onValueChange = { revenueNotes = it },
                    label = { Text("Revenue / Pricing Model") },
                    placeholder = { Text("e.g. Hourly rate, fixed package, recurring") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        onSave(
                            BusinessEntity(
                                name = name.trim(),
                                description = description.trim(),
                                goals = goals.trim(),
                                revenueNotes = revenueNotes.trim(),
                                status = "ACTIVE"
                            )
                        )
                    }
                },
                enabled = name.isNotBlank()
            ) {
                Text("Create Business")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

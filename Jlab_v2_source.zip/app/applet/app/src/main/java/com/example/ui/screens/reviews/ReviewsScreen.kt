package com.example.ui.screens.reviews

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.DailyReviewEntity
import com.example.data.local.entity.WeeklyReviewEntity
import com.example.ui.components.JlabTopBar
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun ReviewsScreen(
    completedTodayCount: Int,
    onSaveDailyReview: (DailyReviewEntity) -> Unit,
    onSaveWeeklyReview: (WeeklyReviewEntity) -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableStateOf(0) }
    val todayDateStr = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()) }
    val currentWeekStr = remember { SimpleDateFormat("yyyy-'W'ww", Locale.getDefault()).format(Date()) }

    var whatWentWell by remember { mutableStateOf("") }
    var whatNeedsAttention by remember { mutableStateOf("") }

    var weeklyReflection by remember { mutableStateOf("") }
    var weeklyPriorities by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            JlabTopBar(
                title = "Reflections & Reviews",
                subtitle = "Close the loop on execution",
                navigationIcon = Icons.Default.ArrowBack,
                onNavigationClick = onNavigateBack
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            TabRow(selectedTabIndex = selectedTab) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Daily Review") }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Weekly Review") }
                )
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                if (selectedTab == 0) {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(text = "Today's Output: $todayDateStr", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(text = "• Tasks completed today: $completedTodayCount", style = MaterialTheme.typography.bodyMedium)
                        }
                    }

                    OutlinedTextField(
                        value = whatWentWell,
                        onValueChange = { whatWentWell = it },
                        label = { Text("What went well today?") },
                        minLines = 3,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    OutlinedTextField(
                        value = whatNeedsAttention,
                        onValueChange = { whatNeedsAttention = it },
                        label = { Text("What needs attention tomorrow?") },
                        minLines = 3,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Button(
                        onClick = {
                            onSaveDailyReview(
                                DailyReviewEntity(
                                    dateStr = todayDateStr,
                                    completedTasksCount = completedTodayCount,
                                    focusMinutes = 0,
                                    whatWentWell = whatWentWell.trim(),
                                    whatNeedsAttention = whatNeedsAttention.trim()
                                )
                            )
                            Toast.makeText(context, "Daily review saved locally!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Save, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Save Daily Review")
                    }
                } else {
                    Text(text = "Week: $currentWeekStr", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                    OutlinedTextField(
                        value = weeklyReflection,
                        onValueChange = { weeklyReflection = it },
                        label = { Text("Weekly Reflection (Wins, Roadblocks, Learnings)") },
                        minLines = 4,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    OutlinedTextField(
                        value = weeklyPriorities,
                        onValueChange = { weeklyPriorities = it },
                        label = { Text("Next Week's 3 Non-Negotiable Priorities") },
                        minLines = 4,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Button(
                        onClick = {
                            onSaveWeeklyReview(
                                WeeklyReviewEntity(
                                    weekStr = currentWeekStr,
                                    tasksCompletedCount = completedTodayCount,
                                    focusMinutes = 0,
                                    reflection = weeklyReflection.trim(),
                                    nextWeekPriorities = weeklyPriorities.trim()
                                )
                            )
                            Toast.makeText(context, "Weekly review saved locally!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Save, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Save Weekly Review")
                    }
                }
            }
        }
    }
}

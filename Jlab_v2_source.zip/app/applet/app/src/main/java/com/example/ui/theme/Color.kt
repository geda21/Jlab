package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Jlab Brand Identity — Clean Indigo & Violet
val JlabIndigoPrimary = Color(0xFF4F46E5)
val JlabIndigoLight = Color(0xFF6366F1)
val JlabIndigoDark = Color(0xFF3730A3)
val JlabIndigoContainerLight = Color(0xFFEEF2FF)
val JlabIndigoContainerDark = Color(0xFF2A285E)

// Semantic Status Colors
val JlabEmerald = Color(0xFF10B981) // Completed, Success
val JlabEmeraldLight = Color(0xFF34D399)
val JlabEmeraldContainerLight = Color(0xFFECFDF5)
val JlabEmeraldContainerDark = Color(0xFF064E3B)

val JlabAmber = Color(0xFFF59E0B) // Pending, In-Progress, Warning
val JlabAmberLight = Color(0xFFFBBF24)
val JlabAmberContainerLight = Color(0xFFFFFBEB)
val JlabAmberContainerDark = Color(0xFF78350F)

val JlabRuby = Color(0xFFEF4444) // Overdue, Critical, Destructive
val JlabRubyLight = Color(0xFFF87171)
val JlabRubyContainerLight = Color(0xFFFEF2F2)
val JlabRubyContainerDark = Color(0xFF7F1D1D)

val JlabCyan = Color(0xFF06B6D4) // Active, Info
val JlabCyanDark = Color(0xFF0E7490)
val JlabCyanContainerLight = Color(0xFFECFEFF)
val JlabCyanContainerDark = Color(0xFF164E63)

val JlabSlate = Color(0xFF64748B)

// Note Highlight Palette (Optimized for contrast in both Light & Dark modes)
val HighlightYellow = Color(0xFFFFF176)
val HighlightGreen = Color(0xFFA5D6A7)
val HighlightBlue = Color(0xFF90CAF9)
val HighlightPink = Color(0xFFF48FB1)
val HighlightPurple = Color(0xFFCE93D8)

// Dark Theme Surfaces (Layered Obsidian & Charcoal)
val DarkBackground = Color(0xFF0A0C10)
val DarkSurface = Color(0xFF12151D)
val DarkSurfaceVariant = Color(0xFF1A1F2C)
val DarkSurfaceContainer = Color(0xFF232A3B)
val DarkOnBackground = Color(0xFFF8FAFC)
val DarkOnSurface = Color(0xFFF1F5F9)
val DarkOnSurfaceVariant = Color(0xFF94A3B8)
val DarkPrimary = Color(0xFF818CF8)
val DarkPrimaryContainer = Color(0xFF312E81)
val DarkSecondary = Color(0xFF38BDF8)
val DarkTertiary = Color(0xFFFBBF24)
val DarkOutline = Color(0xFF2D3548)
val DarkOutlineVariant = Color(0xFF1E2433)

// Light Theme Surfaces (Soft Neutral Slate & Clean Elevated White)
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightSurfaceContainer = Color(0xFFE2E8F0)
val LightOnBackground = Color(0xFF0F172A)
val LightOnSurface = Color(0xFF1E293B)
val LightOnSurfaceVariant = Color(0xFF64748B)
val LightPrimary = Color(0xFF4F46E5)
val LightPrimaryContainer = Color(0xFFEEF2FF)
val LightSecondary = Color(0xFF0284C7)
val LightTertiary = Color(0xFFD97706)
val LightOutline = Color(0xFFE2E8F0)
val LightOutlineVariant = Color(0xFFCBD5E1)

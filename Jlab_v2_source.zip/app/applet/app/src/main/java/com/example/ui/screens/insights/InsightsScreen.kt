package com.example.ui.screens.insights

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.ActivityEntity
import com.example.data.local.entity.ProjectEntity
import com.example.data.local.entity.TaskEntity
import com.example.ui.components.*
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun InsightsScreen(
    completedTasksCount: Int,
    totalTasksCount: Int,
    pendingTasksCount: Int = 0,
    activeProjectsCount: Int,
    activities: List<ActivityEntity>,
    completedTasks: List<TaskEntity> = emptyList(),
    allTasks: List<TaskEntity> = emptyList(),
    activeProjects: List<ProjectEntity> = emptyList()
) {
    val completionRate = if (totalTasksCount > 0) {
        ((completedTasksCount.toFloat() / totalTasksCount.toFloat()) * 100).toInt()
    } else 0

    // Calculate 7-Day Completion Trend from real completed tasks
    val trendData = remember(completedTasks) {
        val calendar = Calendar.getInstance()
        val dayFormat = SimpleDateFormat("EEE", Locale.getDefault())
        val dayKeyFormat = SimpleDateFormat("yyyyMMdd", Locale.getDefault())

        val days = mutableListOf<Pair<String, Int>>()
        for (i in 6 downTo 0) {
            val cal = Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, -i)
            }
            val dayKey = dayKeyFormat.format(cal.time)
            val dayLabel = dayFormat.format(cal.time)

            val count = completedTasks.count { task ->
                val taskCal = Calendar.getInstance().apply { timeInMillis = task.completedAt ?: task.updatedAt }
                dayKeyFormat.format(taskCal.time) == dayKey
            }
            days.add(Pair(dayLabel, count))
        }
        days
    }

    // Overdue tasks count
    val overdueCount = remember(allTasks) {
        val startOfToday = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        allTasks.count { it.status != "COMPLETED" && it.status != "CANCELLED" && it.dueDate != null && it.dueDate < startOfToday }
    }

    Scaffold(
        topBar = {
            JlabTopBar(
                title = "Insights & Analytics",
                subtitle = "Your productivity overview"
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. KPI Stats Grid (Row 1)
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StatCard(
                        title = "Tasks Done",
                        value = "$completedTasksCount",
                        icon = Icons.Default.CheckCircle,
                        accentColor = JlabEmerald,
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = "Pending Tasks",
                        value = "$pendingTasksCount",
                        icon = Icons.Default.PendingActions,
                        accentColor = JlabAmber,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // 1. KPI Stats Grid (Row 2)
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StatCard(
                        title = "Completion Rate",
                        value = "$completionRate%",
                        icon = Icons.Default.DonutLarge,
                        accentColor = JlabCyanDark,
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = "Active Projects",
                        value = "$activeProjectsCount",
                        icon = Icons.Default.Folder,
                        accentColor = JlabIndigoPrimary,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // 2. Chart 1: 7-Day Completion Trend
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Task Completion Trend",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Last 7 days",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        val maxVal = (trendData.maxOfOrNull { it.second } ?: 1).coerceAtLeast(4)

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Bottom
                        ) {
                            trendData.forEach { (dayLabel, count) ->
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    if (count > 0) {
                                        Text(
                                            text = "$count",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary,
                                            fontSize = 11.sp
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                    }

                                    val barHeightRatio = (count.toFloat() / maxVal.toFloat()).coerceIn(0.08f, 1f)
                                    Box(
                                        modifier = Modifier
                                            .width(22.dp)
                                            .fillMaxHeight(barHeightRatio)
                                            .clip(RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp))
                                            .background(
                                                if (count > 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                            )
                                    )

                                    Spacer(modifier = Modifier.height(6.dp))

                                    Text(
                                        text = dayLabel,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 3. Chart 2: Task Status Donut Chart
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Task Status Distribution",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceAround
                        ) {
                            // Donut Canvas
                            val completedColor = JlabEmerald
                            val pendingColor = JlabAmber
                            val overdueColor = MaterialTheme.colorScheme.error
                            val emptyColor = MaterialTheme.colorScheme.surfaceVariant

                            val total = (completedTasksCount + pendingTasksCount).coerceAtLeast(1)
                            val completedSweep = (completedTasksCount.toFloat() / total.toFloat()) * 360f
                            val pendingSweep = (pendingTasksCount.toFloat() / total.toFloat()) * 360f

                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier.size(110.dp)
                            ) {
                                Canvas(modifier = Modifier.fillMaxSize()) {
                                    val strokeWidth = 18.dp.toPx()
                                    val radius = (size.minDimension - strokeWidth) / 2
                                    val center = Offset(size.width / 2, size.height / 2)

                                    if (completedTasksCount == 0 && pendingTasksCount == 0) {
                                        drawCircle(
                                            color = emptyColor,
                                            radius = radius,
                                            center = center,
                                            style = Stroke(width = strokeWidth)
                                        )
                                    } else {
                                        var currentStartAngle = -90f
                                        if (completedSweep > 0) {
                                            drawArc(
                                                color = completedColor,
                                                startAngle = currentStartAngle,
                                                sweepAngle = completedSweep,
                                                useCenter = false,
                                                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                                            )
                                            currentStartAngle += completedSweep
                                        }
                                        if (pendingSweep > 0) {
                                            drawArc(
                                                color = pendingColor,
                                                startAngle = currentStartAngle,
                                                sweepAngle = pendingSweep,
                                                useCenter = false,
                                                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                                            )
                                        }
                                    }
                                }

                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = "${completedTasksCount + pendingTasksCount}",
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Tasks",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            // Donut Legend
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                LegendItem(color = completedColor, label = "Completed", value = "$completedTasksCount")
                                LegendItem(color = pendingColor, label = "Pending", value = "$pendingTasksCount")
                                if (overdueCount > 0) {
                                    LegendItem(color = overdueColor, label = "Overdue", value = "$overdueCount")
                                }
                            }
                        }
                    }
                }
            }

            // 4. Chart 3: Active Projects Progress
            if (activeProjects.isNotEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "Project Execution Progress",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            activeProjects.take(4).forEach { proj ->
                                Column(modifier = Modifier.padding(vertical = 4.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = proj.name,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.SemiBold,
                                            maxLines = 1
                                        )
                                        Text(
                                            text = "${proj.progressPercent}%",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    LinearProgressIndicator(
                                        progress = { (proj.progressPercent / 100f).coerceIn(0f, 1f) },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(6.dp)
                                            .clip(RoundedCornerShape(3.dp)),
                                        color = MaterialTheme.colorScheme.primary,
                                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 5. Activity History Log
            item {
                SectionHeader(
                    title = "Activity History",
                    count = activities.size
                )
            }

            if (activities.isEmpty()) {
                item {
                    EmptyState(
                        icon = Icons.Outlined.History,
                        title = "No activity logged yet",
                        message = "Your completed tasks, locked plans, and saved notes will appear here."
                    )
                }
            } else {
                items(activities) { activity ->
                    val timeStr = SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()).format(Date(activity.timestamp))
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(
                                        when (activity.actionType) {
                                            "COMPLETED" -> JlabEmerald.copy(alpha = 0.18f)
                                            "CREATED" -> MaterialTheme.colorScheme.primaryContainer
                                            "EDITED", "UPDATED" -> JlabAmber.copy(alpha = 0.18f)
                                            "DELETED" -> MaterialTheme.colorScheme.errorContainer
                                            else -> MaterialTheme.colorScheme.surfaceVariant
                                        }
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = when (activity.actionType) {
                                        "COMPLETED" -> Icons.Default.Check
                                        "CREATED" -> Icons.Default.Add
                                        "EDITED", "UPDATED" -> Icons.Default.Edit
                                        "DELETED" -> Icons.Default.Delete
                                        "LOCKED" -> Icons.Default.Lock
                                        else -> Icons.Outlined.EventNote
                                    },
                                    contentDescription = null,
                                    tint = when (activity.actionType) {
                                        "COMPLETED" -> JlabEmerald
                                        "CREATED" -> MaterialTheme.colorScheme.primary
                                        "EDITED", "UPDATED" -> JlabAmber
                                        "DELETED" -> MaterialTheme.colorScheme.error
                                        else -> MaterialTheme.colorScheme.onSurfaceVariant
                                    },
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = activity.title,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                if (activity.summary.isNotBlank()) {
                                    Text(
                                        text = activity.summary,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Text(
                                text = timeStr,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LegendItem(
    color: Color,
    label: String,
    value: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(color)
        )
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

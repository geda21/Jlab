package com.example.ui.screens.plans

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.PlanEntity
import com.example.ui.components.EmptyState
import com.example.ui.components.JlabTopBar
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlansScreen(
    plans: List<PlanEntity>,
    onSavePlan: (PlanEntity) -> Unit,
    onLockPlan: (String, String) -> Unit,
    onUnlockPlan: (String, String) -> Unit,
    onDeletePlan: (String) -> Unit,
    onNavigateBack: () -> Unit
) {
    var isCreatingPlan by remember { mutableStateOf(false) }
    var viewingPlan by remember { mutableStateOf<PlanEntity?>(null) }
    var lockingPlan by remember { mutableStateOf<PlanEntity?>(null) }
    var unlockingPlan by remember { mutableStateOf<PlanEntity?>(null) }

    var selectedTypeFilter by remember { mutableStateOf("ALL") }
    val typeFilters = listOf("ALL", "DAILY", "WEEKLY", "MONTHLY", "LOCKED")

    BackHandler {
        when {
            isCreatingPlan -> isCreatingPlan = false
            viewingPlan != null -> viewingPlan = null
            else -> onNavigateBack()
        }
    }

    // 1. Structured Full-Screen Plan Creator
    if (isCreatingPlan) {
        PlanEditorScreen(
            initialPlan = null,
            onSave = { plan ->
                onSavePlan(plan)
                isCreatingPlan = false
            },
            onCancel = { isCreatingPlan = false }
        )
        return
    }

    // 2. Structured Plan Detail Viewer
    if (viewingPlan != null) {
        val current = plans.find { it.id == viewingPlan!!.id } ?: viewingPlan!!
        PlanDetailScreen(
            plan = current,
            onLockClick = { lockingPlan = current },
            onUnlockClick = { unlockingPlan = current },
            onDelete = {
                onDeletePlan(current.id)
                viewingPlan = null
            },
            onBack = { viewingPlan = null }
        )
        return
    }

    // 3. Plans List
    val filteredPlans = remember(plans, selectedTypeFilter) {
        when (selectedTypeFilter) {
            "ALL" -> plans
            "LOCKED" -> plans.filter { it.isLocked }
            else -> plans.filter { it.planType.equals(selectedTypeFilter, ignoreCase = true) }
        }
    }

    Scaffold(
        topBar = {
            JlabTopBar(
                title = "Plans & Commitments",
                subtitle = "Disciplined daily, weekly & locked schedules",
                navigationIcon = Icons.AutoMirrored.Filled.ArrowBack,
                onNavigationClick = onNavigateBack,
                actions = {
                    IconButton(onClick = { isCreatingPlan = true }) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "New Plan")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Type Filter Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                typeFilters.forEach { f ->
                    val isSelected = selectedTypeFilter.equals(f, ignoreCase = true)
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedTypeFilter = f },
                        label = { Text(f, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                        shape = RoundedCornerShape(8.dp)
                    )
                }
            }

            if (filteredPlans.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    EmptyState(
                        icon = Icons.Default.EventNote,
                        title = if (selectedTypeFilter != "ALL") "No $selectedTypeFilter plans" else "No active plans",
                        message = "Create actionable daily and weekly sprint plans with top 3 priorities, schedule blocks, and commitments.",
                        actionButtonText = "Create Plan",
                        onActionClick = { isCreatingPlan = true }
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filteredPlans, key = { it.id }) { plan ->
                        PlanCard(
                            plan = plan,
                            onClick = { viewingPlan = plan },
                            onLockClick = { lockingPlan = plan },
                            onUnlockClick = { unlockingPlan = plan },
                            onDelete = { onDeletePlan(plan.id) }
                        )
                    }
                }
            }
        }
    }

    lockingPlan?.let { plan ->
        LockPlanConfirmDialog(
            planTitle = plan.title,
            onDismiss = { lockingPlan = null },
            onConfirmLock = {
                onLockPlan(plan.id, plan.title)
                lockingPlan = null
            }
        )
    }

    unlockingPlan?.let { plan ->
        UnlockPlanDialog(
            planTitle = plan.title,
            onDismiss = { unlockingPlan = null },
            onConfirmUnlock = { reason ->
                onUnlockPlan(plan.id, reason)
                unlockingPlan = null
            }
        )
    }
}

@Composable
private fun PlanCard(
    plan: PlanEntity,
    onClick: () -> Unit,
    onLockClick: () -> Unit,
    onUnlockClick: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(
            1.dp,
            if (plan.isLocked) JlabAmber.copy(alpha = 0.5f) else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header Row: Type pill + Lock status + Delete
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = when (plan.planType) {
                            "DAILY" -> JlabAmber.copy(alpha = 0.15f)
                            "WEEKLY" -> JlabIndigoPrimary.copy(alpha = 0.15f)
                            else -> MaterialTheme.colorScheme.secondaryContainer
                        }
                    ) {
                        Text(
                            text = plan.planType,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = when (plan.planType) {
                                "DAILY" -> JlabAmber
                                "WEEKLY" -> JlabIndigoPrimary
                                else -> MaterialTheme.colorScheme.onSecondaryContainer
                            },
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }

                    if (plan.isLocked) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = JlabAmber.copy(alpha = 0.15f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(Icons.Default.Lock, contentDescription = null, tint = JlabAmber, modifier = Modifier.size(12.dp))
                                Text("LOCKED", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = JlabAmber)
                            }
                        }
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { if (plan.isLocked) onUnlockClick() else onLockClick() },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = if (plan.isLocked) Icons.Default.Lock else Icons.Default.LockOpen,
                            contentDescription = if (plan.isLocked) "Unlock" else "Lock",
                            tint = if (plan.isLocked) JlabAmber else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = plan.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            if (plan.description.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = plan.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PlanDetailScreen(
    plan: PlanEntity,
    onLockClick: () -> Unit,
    onUnlockClick: () -> Unit,
    onDelete: () -> Unit,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(plan.title, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { if (plan.isLocked) onUnlockClick() else onLockClick() }) {
                        Icon(
                            imageVector = if (plan.isLocked) Icons.Default.Lock else Icons.Default.LockOpen,
                            contentDescription = "Lock",
                            tint = if (plan.isLocked) JlabAmber else MaterialTheme.colorScheme.onSurface
                        )
                    }
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Type & Lock indicator
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = MaterialTheme.colorScheme.primaryContainer
                ) {
                    Text(
                        text = "${plan.planType} PLAN",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
                if (plan.isLocked) {
                    Surface(shape = RoundedCornerShape(6.dp), color = JlabAmber.copy(alpha = 0.15f)) {
                        Text("LOCKED COMMITMENT", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = JlabAmber, modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp))
                    }
                }
            }

            if (plan.description.isNotBlank()) {
                Text(plan.description, style = MaterialTheme.typography.bodyLarge)
            }

            // Priorities & Tasks breakdown
            if (plan.goals.isNotBlank()) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("PRIORITIES & SCHEDULE", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Text(plan.goals, style = MaterialTheme.typography.bodyMedium, lineHeight = 22.sp)
                    }
                }
            }

            // Commitments & Habits
            if (plan.notes.isNotBlank()) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("COMMITMENTS & NOTES", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Text(plan.notes, style = MaterialTheme.typography.bodyMedium, lineHeight = 22.sp)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PlanEditorScreen(
    initialPlan: PlanEntity?,
    onSave: (PlanEntity) -> Unit,
    onCancel: () -> Unit
) {
    var planType by remember { mutableStateOf(initialPlan?.planType ?: "DAILY") }
    var title by remember { mutableStateOf(initialPlan?.title ?: "") }
    var objective by remember { mutableStateOf(initialPlan?.description ?: "") }

    // Structured fields for Daily / Weekly
    var priority1 by remember { mutableStateOf("") }
    var priority2 by remember { mutableStateOf("") }
    var priority3 by remember { mutableStateOf("") }

    var morningFocus by remember { mutableStateOf("") }
    var afternoonFocus by remember { mutableStateOf("") }
    var eveningFocus by remember { mutableStateOf("") }

    var commitments by remember { mutableStateOf(initialPlan?.notes ?: "") }

    val planTypes = listOf("DAILY", "WEEKLY", "MONTHLY", "CUSTOM")

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (initialPlan == null) "Create Plan" else "Edit Plan", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onCancel) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Cancel")
                    }
                },
                actions = {
                    Button(
                        onClick = {
                            if (title.isNotBlank()) {
                                val goalsBuilder = StringBuilder()
                                if (priority1.isNotBlank()) goalsBuilder.append("1. $priority1\n")
                                if (priority2.isNotBlank()) goalsBuilder.append("2. $priority2\n")
                                if (priority3.isNotBlank()) goalsBuilder.append("3. $priority3\n")
                                if (morningFocus.isNotBlank()) goalsBuilder.append("\n• Morning: $morningFocus\n")
                                if (afternoonFocus.isNotBlank()) goalsBuilder.append("• Afternoon: $afternoonFocus\n")
                                if (eveningFocus.isNotBlank()) goalsBuilder.append("• Evening: $eveningFocus\n")

                                val plan = (initialPlan ?: PlanEntity(title = title)).copy(
                                    title = title.trim(),
                                    planType = planType,
                                    description = objective.trim(),
                                    goals = goalsBuilder.toString().trim(),
                                    notes = commitments.trim(),
                                    updatedAt = System.currentTimeMillis()
                                )
                                onSave(plan)
                            }
                        },
                        enabled = title.isNotBlank()
                    ) {
                        Text("Save Plan")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Plan Type Selector
            Text("Plan Type", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                planTypes.forEach { type ->
                    FilterChip(
                        selected = planType == type,
                        onClick = {
                            planType = type
                            if (title.isBlank()) {
                                val today = SimpleDateFormat("EEEE, MMM d", Locale.getDefault()).format(Date())
                                title = when (type) {
                                    "DAILY" -> "Daily Plan - $today"
                                    "WEEKLY" -> "Weekly Sprint Plan"
                                    else -> "$type Plan"
                                }
                            }
                        },
                        label = { Text(type) }
                    )
                }
            }

            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Plan Title *") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = objective,
                onValueChange = { objective = it },
                label = { Text("Core Objective / Purpose") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            // Top 3 Priorities Section
            Text("Top 3 Priorities", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            OutlinedTextField(
                value = priority1,
                onValueChange = { priority1 = it },
                label = { Text("1. Highest Priority Outcome *") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = priority2,
                onValueChange = { priority2 = it },
                label = { Text("2. Second Priority") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = priority3,
                onValueChange = { priority3 = it },
                label = { Text("3. Third Priority") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            // Execution Schedule Blocks
            Text("Time & Execution Blocks", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
            OutlinedTextField(
                value = morningFocus,
                onValueChange = { morningFocus = it },
                label = { Text("Morning Focus / Deep Work") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = afternoonFocus,
                onValueChange = { afternoonFocus = it },
                label = { Text("Afternoon Execution / Tasks") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = eveningFocus,
                onValueChange = { eveningFocus = it },
                label = { Text("Evening Review & Shutdown") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            // Non-negotiable commitments & notes
            OutlinedTextField(
                value = commitments,
                onValueChange = { commitments = it },
                label = { Text("Non-Negotiable Commitments & Habits") },
                placeholder = { Text("e.g. No social media before noon; 30m code review") },
                modifier = Modifier
                    .fillMaxWidth()
                    .defaultMinSize(minHeight = 100.dp),
                minLines = 3
            )

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun LockPlanConfirmDialog(
    planTitle: String,
    onDismiss: () -> Unit,
    onConfirmLock: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Lock Plan?", fontWeight = FontWeight.Bold) },
        text = {
            Text("Locking \"$planTitle\" prevents casual edits. If you need to edit later, you will be required to write down a deliberate unlock reason.")
        },
        confirmButton = {
            Button(
                onClick = onConfirmLock,
                colors = ButtonDefaults.buttonColors(containerColor = JlabAmber)
            ) {
                Text("Lock Commitment")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun UnlockPlanDialog(
    planTitle: String,
    onDismiss: () -> Unit,
    onConfirmUnlock: (String) -> Unit
) {
    var reason by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Unlock Plan", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Why are you modifying locked plan \"$planTitle\"?")
                OutlinedTextField(
                    value = reason,
                    onValueChange = { reason = it },
                    label = { Text("Reason for Unlock *") },
                    placeholder = { Text("e.g. Unforeseen production bug") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { if (reason.isNotBlank()) onConfirmUnlock(reason.trim()) },
                enabled = reason.isNotBlank()
            ) {
                Text("Unlock")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

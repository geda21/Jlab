package com.example.ui.screens.projects

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import com.example.data.local.entity.FileAttachmentEntity
import com.example.data.local.entity.NoteEntity
import com.example.data.local.entity.ProjectDecisionEntity
import com.example.data.local.entity.ProjectEntity
import com.example.data.local.entity.TaskEntity
import com.example.ui.components.EmptyState
import com.example.ui.components.JlabTopBar
import com.example.ui.components.PriorityBadge
import com.example.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

data class ProjectMilestone(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val isCompleted: Boolean = false,
    val targetDate: Long? = null
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectDetailScreen(
    project: ProjectEntity,
    tasks: List<TaskEntity>,
    notes: List<NoteEntity>,
    files: List<FileAttachmentEntity> = emptyList(),
    decisions: List<ProjectDecisionEntity> = emptyList(),
    onUpdateProject: (ProjectEntity) -> Unit,
    onDuplicateProject: (String) -> Unit = {},
    onArchiveProject: (String) -> Unit = {},
    onDeleteProject: (String) -> Unit = {},
    onAddTask: (TaskEntity) -> Unit,
    onUpdateTask: (TaskEntity) -> Unit = {},
    onCompleteTask: (String, String) -> Unit,
    onReopenTask: (String, String) -> Unit = { _, _ -> },
    onDeleteTask: (String) -> Unit,
    onCreateNote: (NoteEntity) -> Unit = {},
    onDeleteNote: (String) -> Unit = {},
    onOpenNote: (String) -> Unit = {},
    onSaveFile: (FileAttachmentEntity) -> Unit = {},
    onDeleteFile: (FileAttachmentEntity) -> Unit = {},
    onSaveDecision: (ProjectDecisionEntity) -> Unit = {},
    onDeleteDecision: (String) -> Unit = {},
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var selectedTab by remember { mutableIntStateOf(0) }

    // Dialog state
    var showEditProjectDialog by remember { mutableStateOf(false) }
    var showProgressDialog by remember { mutableStateOf(false) }
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }
    var showMoreMenu by remember { mutableStateOf(false) }

    // Task state
    var showAddTaskDialog by remember { mutableStateOf(false) }
    var editingTask by remember { mutableStateOf<TaskEntity?>(null) }
    var taskToDelete by remember { mutableStateOf<TaskEntity?>(null) }
    var selectedTaskFilter by remember { mutableStateOf("ALL") }

    // Note state
    var showAddNoteDialog by remember { mutableStateOf(false) }
    var noteToDelete by remember { mutableStateOf<NoteEntity?>(null) }

    // Milestone state
    var showAddMilestoneDialog by remember { mutableStateOf(false) }

    // Decision state
    var showAddDecisionDialog by remember { mutableStateOf(false) }
    var editingDecision by remember { mutableStateOf<ProjectDecisionEntity?>(null) }
    var decisionToDelete by remember { mutableStateOf<ProjectDecisionEntity?>(null) }

    // Attachment state
    var fileToDelete by remember { mutableStateOf<FileAttachmentEntity?>(null) }
    var previewImageFile by remember { mutableStateOf<FileAttachmentEntity?>(null) }
    var previewTextFile by remember { mutableStateOf<FileAttachmentEntity?>(null) }

    // Multi-attachment pickers
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            coroutineScope.launch {
                for (uri in uris) {
                    importProjectAttachment(context, uri, project.id, "Image", onSaveFile)
                }
            }
        }
    }

    val documentPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            coroutineScope.launch {
                for (uri in uris) {
                    val mime = context.contentResolver.getType(uri) ?: ""
                    val cat = if (mime.contains("pdf", ignoreCase = true)) "PDF" else "Document"
                    importProjectAttachment(context, uri, project.id, cat, onSaveFile)
                }
            }
        }
    }

    // Task calculations for dual progress modes
    val completedTasksCount = tasks.count { it.status == "COMPLETED" }
    val totalTasksCount = tasks.size
    val autoCalculatedProgress = if (totalTasksCount > 0) {
        ((completedTasksCount.toFloat() / totalTasksCount.toFloat()) * 100).toInt().coerceIn(0, 100)
    } else {
        0
    }

    // Active progress value depends on progressMode
    val isAutoMode = project.progressMode == "AUTOMATIC"
    val displayProgress = if (isAutoMode) autoCalculatedProgress else project.manualProgressPercent.coerceIn(0, 100)

    val tabs = listOf(
        "Overview",
        "Tasks ($totalTasksCount)",
        "Notes (${notes.size})",
        "Files (${files.size})",
        "Decisions (${decisions.size})"
    )

    BackHandler {
        onNavigateBack()
    }

    Scaffold(
        topBar = {
            JlabTopBar(
                title = project.name,
                subtitle = "Status: ${project.status} · $displayProgress% Complete (${if (isAutoMode) "Auto" else "Manual"})",
                navigationIcon = Icons.AutoMirrored.Filled.ArrowBack,
                onNavigationClick = onNavigateBack,
                actions = {
                    // Quick progress edit action
                    IconButton(onClick = { showProgressDialog = true }) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = "Edit Progress",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }

                    // More Menu
                    Box {
                        IconButton(onClick = { showMoreMenu = true }) {
                            Icon(Icons.Default.MoreVert, contentDescription = "Project Actions")
                        }
                        DropdownMenu(
                            expanded = showMoreMenu,
                            onDismissRequest = { showMoreMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Edit Project") },
                                leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null) },
                                onClick = {
                                    showMoreMenu = false
                                    showEditProjectDialog = true
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Adjust Progress") },
                                leadingIcon = { Icon(Icons.Default.Tune, contentDescription = null) },
                                onClick = {
                                    showMoreMenu = false
                                    showProgressDialog = true
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Duplicate Project") },
                                leadingIcon = { Icon(Icons.Default.ContentCopy, contentDescription = null) },
                                onClick = {
                                    showMoreMenu = false
                                    onDuplicateProject(project.id)
                                    Toast.makeText(context, "Project duplicated", Toast.LENGTH_SHORT).show()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text(if (project.isArchived) "Unarchive" else "Archive") },
                                leadingIcon = { Icon(Icons.Default.Archive, contentDescription = null) },
                                onClick = {
                                    showMoreMenu = false
                                    onArchiveProject(project.id)
                                    Toast.makeText(context, if (project.isArchived) "Unarchived" else "Archived", Toast.LENGTH_SHORT).show()
                                }
                            )
                            HorizontalDivider()
                            DropdownMenuItem(
                                text = { Text("Delete Project", color = MaterialTheme.colorScheme.error) },
                                leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                                onClick = {
                                    showMoreMenu = false
                                    showDeleteConfirmDialog = true
                                }
                            )
                        }
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Scrollable Tab Row
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                edgePadding = 16.dp,
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = { Text(title, fontWeight = FontWeight.SemiBold) }
                    )
                }
            }

            when (selectedTab) {
                0 -> {
                    // ==========================================
                    // 1. OVERVIEW TAB
                    // ==========================================
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // 100% Celebration Prompt Banner
                        if (displayProgress >= 100 && project.status != "COMPLETED") {
                            item {
                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = JlabEmerald.copy(alpha = 0.12f),
                                    border = BorderStroke(1.dp, JlabEmerald.copy(alpha = 0.4f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(14.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "🎉 Project Reached 100%!",
                                                style = MaterialTheme.typography.titleSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = JlabEmerald
                                            )
                                            Text(
                                                text = "All milestones achieved. Would you like to mark this project Completed?",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Button(
                                            onClick = {
                                                onUpdateProject(project.copy(status = "COMPLETED", progressPercent = 100, updatedAt = System.currentTimeMillis()))
                                                Toast.makeText(context, "Marked project as Completed!", Toast.LENGTH_SHORT).show()
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = JlabEmerald),
                                            shape = RoundedCornerShape(10.dp),
                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                        ) {
                                            Text("Mark Done", color = Color.White, style = MaterialTheme.typography.labelSmall)
                                        }
                                    }
                                }
                            }
                        }

                        // Progress Command Card
                        item {
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                "PROJECT PROGRESS",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.primary,
                                                letterSpacing = 0.8.sp
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = if (isAutoMode) JlabCyan.copy(alpha = 0.15f) else JlabAmber.copy(alpha = 0.15f)
                                            ) {
                                                Text(
                                                    text = if (isAutoMode) "AUTO (Tasks)" else "MANUAL",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (isAutoMode) JlabCyan else JlabAmber,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                                    fontSize = 10.sp
                                                )
                                            }
                                        }

                                        TextButton(
                                            onClick = { showProgressDialog = true },
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                                        ) {
                                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Adjust", style = MaterialTheme.typography.labelSmall)
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = if (isAutoMode) "$completedTasksCount of $totalTasksCount tasks complete" else "Manual progress set",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(
                                            text = "$displayProgress%",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))

                                    LinearProgressIndicator(
                                        progress = { displayProgress / 100f },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(10.dp)
                                            .clip(RoundedCornerShape(5.dp))
                                            .clickable { showProgressDialog = true },
                                        color = if (displayProgress >= 100) JlabEmerald else MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }

                        // Project Objective & Goal Card (Distinct from Description!)
                        item {
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            "PROJECT OBJECTIVE / TARGET",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary,
                                            letterSpacing = 0.8.sp
                                        )
                                        IconButton(
                                            onClick = { showEditProjectDialog = true },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(Icons.Default.Edit, contentDescription = "Edit Objective", modifier = Modifier.size(16.dp))
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = project.objective.ifBlank { "No specific objective specified yet. Tap edit to define targets." },
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }

                        // Project Description Card (Distinct from Objective!)
                        item {
                            var isExpanded by remember { mutableStateOf(false) }
                            val desc = project.description.trim()

                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            "DESCRIPTION & CONTEXT",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary,
                                            letterSpacing = 0.8.sp
                                        )
                                        IconButton(
                                            onClick = { showEditProjectDialog = true },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(Icons.Default.Edit, contentDescription = "Edit Description", modifier = Modifier.size(16.dp))
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    if (desc.isBlank()) {
                                        Text(
                                            "No description provided for this project.",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    } else {
                                        Text(
                                            text = desc,
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            maxLines = if (isExpanded) Int.MAX_VALUE else 4,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        if (desc.length > 180) {
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = if (isExpanded) "Show Less ↑" else "Read More ↓",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.clickable { isExpanded = !isExpanded }
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Operational Stats Grid
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                ProjectStatCard(label = "Open Tasks", value = "${totalTasksCount - completedTasksCount}", color = JlabAmber, modifier = Modifier.weight(1f))
                                ProjectStatCard(label = "Done Tasks", value = "$completedTasksCount", color = JlabEmerald, modifier = Modifier.weight(1f))
                                ProjectStatCard(label = "Notes", value = "${notes.size}", color = JlabCyan, modifier = Modifier.weight(1f))
                                ProjectStatCard(label = "Files", value = "${files.size}", color = JlabIndigoPrimary, modifier = Modifier.weight(1f))
                            }
                        }

                        // Metadata Card (Category, Priority, Status, Target Date)
                        item {
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))
                            ) {
                                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            "PROJECT PARAMETERS",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        IconButton(
                                            onClick = { showEditProjectDialog = true },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(Icons.Default.Edit, contentDescription = "Edit Parameters", modifier = Modifier.size(16.dp))
                                        }
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column {
                                            Text("Category", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            Text(project.category, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                        }
                                        Column {
                                            Text("Priority", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            PriorityBadge(priority = project.priority)
                                        }
                                        Column {
                                            Text("Status", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = when (project.status) {
                                                    "ACTIVE" -> JlabEmerald.copy(alpha = 0.15f)
                                                    "PLANNING" -> JlabCyan.copy(alpha = 0.15f)
                                                    "COMPLETED" -> JlabIndigoPrimary.copy(alpha = 0.15f)
                                                    "PAUSED" -> JlabAmber.copy(alpha = 0.15f)
                                                    else -> MaterialTheme.colorScheme.surfaceVariant
                                                }
                                            ) {
                                                Text(
                                                    text = project.status,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    fontWeight = FontWeight.Bold,
                                                    color = when (project.status) {
                                                        "ACTIVE" -> JlabEmerald
                                                        "PLANNING" -> JlabCyan
                                                        "COMPLETED" -> JlabIndigoPrimary
                                                        "PAUSED" -> JlabAmber
                                                        else -> MaterialTheme.colorScheme.onSurface
                                                    },
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                    }

                                    HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column {
                                            Text("Start Date", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            val startStr = if (project.startDate != null) {
                                                SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date(project.startDate))
                                            } else {
                                                SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date(project.createdAt))
                                            }
                                            Text(startStr, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
                                        }
                                        Column {
                                            Text("Target Deadline", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            val targetStr = if (project.targetDate != null) {
                                                SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date(project.targetDate))
                                            } else {
                                                "No deadline set"
                                            }
                                            Text(targetStr, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
                                        }
                                    }
                                }
                            }
                        }

                        // Project Milestones Card
                        item {
                            val milestones = remember(project.milestonesJson) {
                                parseMilestones(project.milestonesJson)
                            }

                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            "PROJECT MILESTONES (${milestones.count { it.isCompleted }}/${milestones.size})",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary,
                                            letterSpacing = 0.8.sp
                                        )
                                        TextButton(
                                            onClick = { showAddMilestoneDialog = true },
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                        ) {
                                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Add", style = MaterialTheme.typography.labelSmall)
                                        }
                                    }

                                    if (milestones.isEmpty()) {
                                        Text(
                                            "No milestones defined yet. Break this project down into major phases.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.padding(vertical = 4.dp)
                                        )
                                    } else {
                                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                            milestones.forEach { m ->
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .clip(RoundedCornerShape(8.dp))
                                                        .clickable {
                                                            val updated = milestones.map {
                                                                if (it.id == m.id) it.copy(isCompleted = !it.isCompleted) else it
                                                            }
                                                            onUpdateProject(project.copy(milestonesJson = serializeMilestones(updated), updatedAt = System.currentTimeMillis()))
                                                        }
                                                        .padding(vertical = 4.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Icon(
                                                        imageVector = if (m.isCompleted) Icons.Default.CheckCircle else Icons.Outlined.RadioButtonUnchecked,
                                                        contentDescription = null,
                                                        tint = if (m.isCompleted) JlabEmerald else MaterialTheme.colorScheme.onSurfaceVariant,
                                                        modifier = Modifier.size(20.dp)
                                                    )
                                                    Spacer(modifier = Modifier.width(10.dp))
                                                    Text(
                                                        text = m.title,
                                                        style = MaterialTheme.typography.bodyMedium,
                                                        textDecoration = if (m.isCompleted) TextDecoration.LineThrough else null,
                                                        color = if (m.isCompleted) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
                                                        modifier = Modifier.weight(1f)
                                                    )
                                                    IconButton(
                                                        onClick = {
                                                            val updated = milestones.filter { it.id != m.id }
                                                            onUpdateProject(project.copy(milestonesJson = serializeMilestones(updated), updatedAt = System.currentTimeMillis()))
                                                        },
                                                        modifier = Modifier.size(24.dp)
                                                    ) {
                                                        Icon(Icons.Default.Close, contentDescription = "Delete Milestone", modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                1 -> {
                    // ==========================================
                    // 2. TASKS TAB (Fully Interactive)
                    // ==========================================
                    val filteredProjectTasks = remember(tasks, selectedTaskFilter) {
                        when (selectedTaskFilter) {
                            "PENDING" -> tasks.filter { it.status != "COMPLETED" }
                            "COMPLETED" -> tasks.filter { it.status == "COMPLETED" }
                            else -> tasks
                        }
                    }

                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Button(
                                    onClick = { showAddTaskDialog = true },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Add Project Task")
                                }

                                FilterChip(
                                    selected = selectedTaskFilter == "ALL",
                                    onClick = { selectedTaskFilter = "ALL" },
                                    label = { Text("All (${tasks.size})") }
                                )
                                FilterChip(
                                    selected = selectedTaskFilter == "PENDING",
                                    onClick = { selectedTaskFilter = "PENDING" },
                                    label = { Text("Open (${totalTasksCount - completedTasksCount})") }
                                )
                                FilterChip(
                                    selected = selectedTaskFilter == "COMPLETED",
                                    onClick = { selectedTaskFilter = "COMPLETED" },
                                    label = { Text("Done ($completedTasksCount)") }
                                )
                            }
                        }

                        if (filteredProjectTasks.isEmpty()) {
                            item {
                                EmptyState(
                                    icon = Icons.Outlined.CheckCircle,
                                    title = if (selectedTaskFilter == "COMPLETED") "No completed tasks yet" else "No project tasks found",
                                    message = "Tasks created here will automatically link to ${project.name} and count towards automatic progress.",
                                    actionButtonText = if (selectedTaskFilter != "COMPLETED") "Create Task" else null,
                                    onActionClick = { showAddTaskDialog = true }
                                )
                            }
                        } else {
                            items(filteredProjectTasks, key = { it.id }) { task ->
                                val isDone = task.status == "COMPLETED"
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { editingTask = task },
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        IconButton(
                                            onClick = {
                                                if (isDone) {
                                                    onReopenTask(task.id, task.title)
                                                    Toast.makeText(context, "Task reopened", Toast.LENGTH_SHORT).show()
                                                } else {
                                                    onCompleteTask(task.id, task.title)
                                                    Toast.makeText(context, "Task completed!", Toast.LENGTH_SHORT).show()
                                                }
                                            }
                                        ) {
                                            Icon(
                                                imageVector = if (isDone) Icons.Default.CheckCircle else Icons.Outlined.RadioButtonUnchecked,
                                                contentDescription = "Toggle Complete",
                                                tint = if (isDone) JlabEmerald else MaterialTheme.colorScheme.primary
                                            )
                                        }

                                        Spacer(modifier = Modifier.width(6.dp))

                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = task.title,
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.SemiBold,
                                                textDecoration = if (isDone) TextDecoration.LineThrough else null,
                                                color = if (isDone) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
                                            )
                                            if (task.description.isNotBlank()) {
                                                Text(
                                                    text = task.description,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                            if (task.dueDate != null) {
                                                val dateStr = SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date(task.dueDate))
                                                Text(
                                                    text = "Due: $dateStr",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    fontSize = 11.sp
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.width(8.dp))

                                        PriorityBadge(priority = task.priority)

                                        Spacer(modifier = Modifier.width(4.dp))

                                        IconButton(
                                            onClick = { taskToDelete = task },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                2 -> {
                    // ==========================================
                    // 3. NOTES TAB (Create & Manage Inside Project!)
                    // ==========================================
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        item {
                            Button(
                                onClick = { showAddNoteDialog = true },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("New Note for ${project.name}")
                            }
                        }

                        if (notes.isEmpty()) {
                            item {
                                EmptyState(
                                    icon = Icons.Outlined.NoteAlt,
                                    title = "No project notes yet",
                                    message = "Capture meeting notes, architectural thoughts, or specifications directly linked to this project.",
                                    actionButtonText = "Create Note",
                                    onActionClick = { showAddNoteDialog = true }
                                )
                            }
                        } else {
                            items(notes, key = { it.id }) { note ->
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { onOpenNote(note.id) },
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))
                                ) {
                                    Column(modifier = Modifier.padding(14.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                note.title.ifBlank { "Untitled Note" },
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.weight(1f)
                                            )
                                            IconButton(
                                                onClick = { noteToDelete = note },
                                                modifier = Modifier.size(28.dp)
                                            ) {
                                                Icon(Icons.Default.DeleteOutline, contentDescription = "Delete Note", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                                            }
                                        }

                                        if (note.content.isNotBlank()) {
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                note.content.take(150),
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                maxLines = 3,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(8.dp))
                                        val dateStr = SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date(note.updatedAt))
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text("Category: ${note.category}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                            Text(dateStr, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                3 -> {
                    // ==========================================
                    // 4. ATTACHMENTS TAB (Full Local Storage Support!)
                    // ==========================================
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = {
                                        photoPickerLauncher.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Add Image")
                                }

                                OutlinedButton(
                                    onClick = {
                                        documentPickerLauncher.launch(arrayOf("*/*"))
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.Default.AttachFile, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Add Document")
                                }
                            }
                        }

                        if (files.isEmpty()) {
                            item {
                                EmptyState(
                                    icon = Icons.Outlined.FolderZip,
                                    title = "No attachments in project",
                                    message = "Attach screenshots, wireframes, PDF specifications, and documents stored securely in private app storage for offline access.",
                                    actionButtonText = "Attach File",
                                    onActionClick = {
                                        documentPickerLauncher.launch(arrayOf("*/*"))
                                    }
                                )
                            }
                        } else {
                            items(files, key = { it.id }) { file ->
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            openProjectFile(
                                                file = file,
                                                context = context,
                                                onPreviewImage = { previewImageFile = it },
                                                onPreviewText = { previewTextFile = it }
                                            )
                                        },
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        val isImg = file.mimeType.startsWith("image") || file.name.endsWith(".jpg", true) || file.name.endsWith(".png", true)
                                        val isPdf = file.category.equals("PDF", true) || file.name.endsWith(".pdf", true)

                                        Box(
                                            modifier = Modifier
                                                .size(44.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(
                                                    when {
                                                        isImg -> JlabIndigoPrimary.copy(alpha = 0.15f)
                                                        isPdf -> JlabRuby.copy(alpha = 0.15f)
                                                        else -> JlabCyan.copy(alpha = 0.15f)
                                                    }
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = when {
                                                    isImg -> Icons.Default.Image
                                                    isPdf -> Icons.Default.PictureAsPdf
                                                    else -> Icons.Default.InsertDriveFile
                                                },
                                                contentDescription = null,
                                                tint = when {
                                                    isImg -> JlabIndigoPrimary
                                                    isPdf -> JlabRuby
                                                    else -> JlabCyan
                                                }
                                            )
                                        }

                                        Spacer(modifier = Modifier.width(12.dp))

                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                file.name,
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.SemiBold,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            val sizeKb = (file.sizeBytes / 1024).coerceAtLeast(1)
                                            val dateStr = SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date(file.createdAt))
                                            Text(
                                                "$sizeKb KB · ${file.category} · $dateStr",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }

                                        IconButton(
                                            onClick = { fileToDelete = file },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(Icons.Default.DeleteOutline, contentDescription = "Delete File", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                4 -> {
                    // ==========================================
                    // 5. DECISIONS TAB
                    // ==========================================
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item {
                            Button(
                                onClick = {
                                    editingDecision = null
                                    showAddDecisionDialog = true
                                },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Add Decision Record")
                            }
                        }

                        if (decisions.isEmpty()) {
                            item {
                                EmptyState(
                                    icon = Icons.Outlined.Gavel,
                                    title = "No decisions logged yet",
                                    message = "Record key architecture decisions, pivots, reasons, and intended outcomes as structured milestones.",
                                    actionButtonText = "Log First Decision",
                                    onActionClick = {
                                        editingDecision = null
                                        showAddDecisionDialog = true
                                    }
                                )
                            }
                        } else {
                            items(decisions, key = { it.id }) { decision ->
                                DecisionRecordCard(
                                    decision = decision,
                                    onEdit = {
                                        editingDecision = decision
                                        showAddDecisionDialog = true
                                    },
                                    onDelete = { decisionToDelete = decision }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // ==========================================
    // DIALOGS & ACTION HANDLERS
    // ==========================================

    // 1. Dual Progress Mode Adjustment Dialog
    if (showProgressDialog) {
        ProjectProgressDialog(
            currentMode = project.progressMode,
            currentManualProgress = project.manualProgressPercent,
            autoCalculatedProgress = autoCalculatedProgress,
            onSave = { newMode, newManualProg ->
                val newProg = if (newMode == "AUTOMATIC") autoCalculatedProgress else newManualProg
                onUpdateProject(
                    project.copy(
                        progressMode = newMode,
                        manualProgressPercent = newManualProg,
                        progressPercent = newProg,
                        updatedAt = System.currentTimeMillis()
                    )
                )
                showProgressDialog = false
                Toast.makeText(context, "Progress updated to $newProg% ($newMode)", Toast.LENGTH_SHORT).show()
            },
            onDismiss = { showProgressDialog = false }
        )
    }

    // 2. Full Project Edit Dialog
    if (showEditProjectDialog) {
        ProjectEditFullDialog(
            project = project,
            onSave = { updated ->
                onUpdateProject(updated)
                showEditProjectDialog = false
                Toast.makeText(context, "Project details updated", Toast.LENGTH_SHORT).show()
            },
            onDismiss = { showEditProjectDialog = false }
        )
    }

    // 3. Delete Project Confirmation Dialog
    if (showDeleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            title = { Text("Delete Project?", fontWeight = FontWeight.Bold) },
            text = { Text("Are you sure you want to permanently delete \"${project.name}\"? All project details will be removed.") },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteProject(project.id)
                        showDeleteConfirmDialog = false
                        onNavigateBack()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = false }) { Text("Cancel") }
            }
        )
    }

    // 4. Add/Edit Task Dialog
    if (showAddTaskDialog || editingTask != null) {
        ProjectTaskDialog(
            initialTask = editingTask,
            projectId = project.id,
            onSave = { task ->
                if (editingTask != null) {
                    onUpdateTask(task)
                } else {
                    onAddTask(task)
                }
                showAddTaskDialog = false
                editingTask = null
            },
            onDismiss = {
                showAddTaskDialog = false
                editingTask = null
            }
        )
    }

    // 5. Delete Task Confirmation Dialog
    if (taskToDelete != null) {
        AlertDialog(
            onDismissRequest = { taskToDelete = null },
            title = { Text("Delete Task?", fontWeight = FontWeight.Bold) },
            text = { Text("Are you sure you want to delete \"${taskToDelete?.title}\"?") },
            confirmButton = {
                Button(
                    onClick = {
                        taskToDelete?.let { onDeleteTask(it.id) }
                        taskToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { taskToDelete = null }) { Text("Cancel") }
            }
        )
    }

    // 6. Add Project Note Dialog
    if (showAddNoteDialog) {
        ProjectNoteCreateDialog(
            projectId = project.id,
            onSave = { note ->
                onCreateNote(note)
                showAddNoteDialog = false
                Toast.makeText(context, "Project note created!", Toast.LENGTH_SHORT).show()
            },
            onDismiss = { showAddNoteDialog = false }
        )
    }

    // 7. Delete Note Confirmation Dialog
    if (noteToDelete != null) {
        AlertDialog(
            onDismissRequest = { noteToDelete = null },
            title = { Text("Delete Note?", fontWeight = FontWeight.Bold) },
            text = { Text("Are you sure you want to delete note \"${noteToDelete?.title}\"?") },
            confirmButton = {
                Button(
                    onClick = {
                        noteToDelete?.let { onDeleteNote(it.id) }
                        noteToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { noteToDelete = null }) { Text("Cancel") }
            }
        )
    }

    // 8. Delete File Confirmation Dialog
    if (fileToDelete != null) {
        AlertDialog(
            onDismissRequest = { fileToDelete = null },
            title = { Text("Remove Attachment?", fontWeight = FontWeight.Bold) },
            text = { Text("Are you sure you want to delete \"${fileToDelete?.name}\" from this project?") },
            confirmButton = {
                Button(
                    onClick = {
                        fileToDelete?.let { onDeleteFile(it) }
                        fileToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Remove")
                }
            },
            dismissButton = {
                TextButton(onClick = { fileToDelete = null }) { Text("Cancel") }
            }
        )
    }

    // 9. Add Milestone Dialog
    if (showAddMilestoneDialog) {
        var milestoneTitle by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAddMilestoneDialog = false },
            title = { Text("Add Project Milestone", fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = milestoneTitle,
                    onValueChange = { milestoneTitle = it },
                    label = { Text("Milestone Phase / Goal *") },
                    placeholder = { Text("e.g. Beta release launched") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (milestoneTitle.isNotBlank()) {
                            val currentList = parseMilestones(project.milestonesJson).toMutableList()
                            currentList.add(ProjectMilestone(title = milestoneTitle.trim()))
                            onUpdateProject(project.copy(milestonesJson = serializeMilestones(currentList), updatedAt = System.currentTimeMillis()))
                            showAddMilestoneDialog = false
                        }
                    },
                    enabled = milestoneTitle.isNotBlank()
                ) {
                    Text("Add Milestone")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddMilestoneDialog = false }) { Text("Cancel") }
            }
        )
    }

    // 10. Add/Edit Decision Dialog
    if (showAddDecisionDialog) {
        DecisionDialog(
            initialDecision = editingDecision,
            projectId = project.id,
            onSave = { saved ->
                onSaveDecision(saved)
                showAddDecisionDialog = false
                editingDecision = null
            },
            onDismiss = {
                showAddDecisionDialog = false
                editingDecision = null
            }
        )
    }

    // 11. Delete Decision Confirmation Dialog
    if (decisionToDelete != null) {
        AlertDialog(
            onDismissRequest = { decisionToDelete = null },
            title = { Text("Delete Decision Record?", fontWeight = FontWeight.Bold) },
            text = { Text("Delete decision record \"${decisionToDelete?.title}\"?") },
            confirmButton = {
                Button(
                    onClick = {
                        decisionToDelete?.let { onDeleteDecision(it.id) }
                        decisionToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { decisionToDelete = null }) { Text("Cancel") }
            }
        )
    }

    // 12. Full-screen Image Previewer with Pan & Zoom
    previewImageFile?.let { file ->
        Dialog(
            onDismissRequest = { previewImageFile = null },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black)
            ) {
                var scale by remember { mutableFloatStateOf(1f) }
                var offset by remember { mutableStateOf(androidx.compose.ui.geometry.Offset.Zero) }

                AsyncImage(
                    model = File(file.localFilePath),
                    contentDescription = file.name,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer(
                            scaleX = scale,
                            scaleY = scale,
                            translationX = offset.x,
                            translationY = offset.y
                        )
                        .pointerInput(Unit) {
                            detectTransformGestures { _, pan, zoom, _ ->
                                scale = (scale * zoom).coerceIn(1f, 5f)
                                offset += pan
                            }
                        }
                )

                IconButton(
                    onClick = { previewImageFile = null },
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(16.dp)
                        .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                ) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                }
            }
        }
    }

    // 13. Text Document In-App Previewer
    previewTextFile?.let { file ->
        val textContent = remember(file.localFilePath) {
            try {
                File(file.localFilePath).readText().take(5000)
            } catch (e: Exception) {
                "Unable to read file contents: ${e.message}"
            }
        }

        AlertDialog(
            onDismissRequest = { previewTextFile = null },
            title = { Text(file.name, fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 400.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(textContent, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = { previewTextFile = null }) { Text("Close") }
            }
        )
    }
}

// ----------------------------------------------------------------------------
// Auxiliary Dialogs
// ----------------------------------------------------------------------------

@Composable
private fun ProjectProgressDialog(
    currentMode: String,
    currentManualProgress: Int,
    autoCalculatedProgress: Int,
    onSave: (String, Int) -> Unit,
    onDismiss: () -> Unit
) {
    var mode by remember { mutableStateOf(currentMode) }
    var sliderValue by remember { mutableFloatStateOf(currentManualProgress.toFloat()) }
    var textInput by remember { mutableStateOf(currentManualProgress.toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Interactive Progress Control", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("Select how project progress should be computed:", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = mode == "MANUAL",
                        onClick = { mode = "MANUAL" },
                        label = { Text("Manual Slider") },
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = mode == "AUTOMATIC",
                        onClick = { mode = "AUTOMATIC" },
                        label = { Text("Auto (Tasks)") },
                        modifier = Modifier.weight(1f)
                    )
                }

                if (mode == "MANUAL") {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Completion: ${sliderValue.toInt()}%", fontWeight = FontWeight.Bold)
                            OutlinedTextField(
                                value = textInput,
                                onValueChange = { str ->
                                    textInput = str
                                    val parsed = str.toIntOrNull()
                                    if (parsed != null && parsed in 0..100) {
                                        sliderValue = parsed.toFloat()
                                    }
                                },
                                modifier = Modifier.width(80.dp),
                                singleLine = true,
                                textStyle = MaterialTheme.typography.bodySmall
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Slider(
                            value = sliderValue,
                            onValueChange = {
                                sliderValue = it
                                textInput = it.toInt().toString()
                            },
                            valueRange = 0f..100f
                        )
                    }
                } else {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = JlabCyan.copy(alpha = 0.12f),
                        border = BorderStroke(1.dp, JlabCyan.copy(alpha = 0.35f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text("Automatic Mode Active", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = JlabCyan)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                "Calculated automatically from completed tasks:\nProgress = $autoCalculatedProgress%",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                "Your manual progress ($currentManualProgress%) is preserved safely and will not be overwritten.",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(mode, sliderValue.toInt().coerceIn(0, 100))
                }
            ) {
                Text("Confirm")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun ProjectEditFullDialog(
    project: ProjectEntity,
    onSave: (ProjectEntity) -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf(project.name) }
    var objective by remember { mutableStateOf(project.objective) }
    var description by remember { mutableStateOf(project.description) }
    var category by remember { mutableStateOf(project.category) }
    var priority by remember { mutableStateOf(project.priority) }
    var status by remember { mutableStateOf(project.status) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit Project Details", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Project Title *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = objective,
                    onValueChange = { objective = it },
                    label = { Text("Objective / Target") },
                    placeholder = { Text("Main goal this project achieves") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description & Notes") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3
                )

                Text("Status:", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("PLANNING", "ACTIVE", "PAUSED", "COMPLETED").forEach { s ->
                        FilterChip(
                            selected = status == s,
                            onClick = { status = s },
                            label = { Text(s, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                Text("Priority:", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("LOW", "MEDIUM", "HIGH", "CRITICAL").forEach { p ->
                        FilterChip(
                            selected = priority == p,
                            onClick = { priority = p },
                            label = { Text(p, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                OutlinedTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = { Text("Category") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        val updated = project.copy(
                            name = name.trim(),
                            objective = objective.trim(),
                            description = description.trim(),
                            category = category.trim(),
                            priority = priority,
                            status = status,
                            updatedAt = System.currentTimeMillis()
                        )
                        onSave(updated)
                    }
                },
                enabled = name.isNotBlank()
            ) {
                Text("Save Changes")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun ProjectTaskDialog(
    initialTask: TaskEntity?,
    projectId: String,
    onSave: (TaskEntity) -> Unit,
    onDismiss: () -> Unit
) {
    var title by remember { mutableStateOf(initialTask?.title ?: "") }
    var description by remember { mutableStateOf(initialTask?.description ?: "") }
    var priority by remember { mutableStateOf(initialTask?.priority ?: "MEDIUM") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initialTask == null) "New Project Task" else "Edit Task", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Task Title *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description (optional)") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )

                Text("Priority:", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("LOW", "MEDIUM", "HIGH", "CRITICAL").forEach { p ->
                        FilterChip(
                            selected = priority == p,
                            onClick = { priority = p },
                            label = { Text(p, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        val task = (initialTask ?: TaskEntity(projectId = projectId, title = title)).copy(
                            title = title.trim(),
                            description = description.trim(),
                            priority = priority,
                            projectId = projectId,
                            updatedAt = System.currentTimeMillis()
                        )
                        onSave(task)
                    }
                },
                enabled = title.isNotBlank()
            ) {
                Text("Save Task")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun ProjectNoteCreateDialog(
    projectId: String,
    onSave: (NoteEntity) -> Unit,
    onDismiss: () -> Unit
) {
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Project") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New Project Note", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Note Title *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = content,
                    onValueChange = { content = it },
                    label = { Text("Content *") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 4
                )

                OutlinedTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = { Text("Category") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank() || content.isNotBlank()) {
                        val note = NoteEntity(
                            title = title.trim().ifBlank { "Project Note" },
                            content = content.trim(),
                            projectId = projectId,
                            category = category.trim()
                        )
                        onSave(note)
                    }
                },
                enabled = title.isNotBlank() || content.isNotBlank()
            ) {
                Text("Create Note")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun DecisionRecordCard(
    decision: ProjectDecisionEntity,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val dateStr = remember(decision.createdAt) {
        SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date(decision.createdAt))
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)
                ) {
                    Text(
                        text = dateStr,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(onClick = onEdit, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit", modifier = Modifier.size(16.dp))
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.error)
                    }
                }
            }

            Text(
                text = decision.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            if (decision.description.isNotBlank()) {
                Text(
                    text = decision.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (decision.reason.isNotBlank()) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("Reason / Context:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(decision.reason, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            if (decision.outcome.isNotBlank()) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = JlabEmerald.copy(alpha = 0.1f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("Expected Outcome / Resolution:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = JlabEmerald)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(decision.outcome, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun DecisionDialog(
    initialDecision: ProjectDecisionEntity?,
    projectId: String,
    onSave: (ProjectDecisionEntity) -> Unit,
    onDismiss: () -> Unit
) {
    var title by remember { mutableStateOf(initialDecision?.title ?: "") }
    var description by remember { mutableStateOf(initialDecision?.description ?: "") }
    var reason by remember { mutableStateOf(initialDecision?.reason ?: "") }
    var outcome by remember { mutableStateOf(initialDecision?.outcome ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initialDecision == null) "Log Project Decision" else "Edit Decision", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Decision Title *") },
                    placeholder = { Text("e.g. Changed architecture to Room") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = reason,
                    onValueChange = { reason = it },
                    label = { Text("Reason / Problem *") },
                    placeholder = { Text("e.g. Need durable offline persistence") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )

                OutlinedTextField(
                    value = outcome,
                    onValueChange = { outcome = it },
                    label = { Text("Outcome / Resolution") },
                    placeholder = { Text("e.g. Implemented Room MIGRATION_4_5") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Additional Context (optional)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        val decision = (initialDecision ?: ProjectDecisionEntity(projectId = projectId, title = title)).copy(
                            title = title.trim(),
                            description = description.trim(),
                            reason = reason.trim(),
                            outcome = outcome.trim(),
                            updatedAt = System.currentTimeMillis()
                        )
                        onSave(decision)
                    }
                },
                enabled = title.isNotBlank()
            ) {
                Text("Save Decision")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun ProjectStatCard(
    label: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = color)
            Spacer(modifier = Modifier.height(2.dp))
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// ----------------------------------------------------------------------------
// Utilities & Storage Helpers
// ----------------------------------------------------------------------------

private fun openProjectFile(
    file: FileAttachmentEntity,
    context: Context,
    onPreviewImage: (FileAttachmentEntity) -> Unit,
    onPreviewText: (FileAttachmentEntity) -> Unit
) {
    val name = file.name.lowercase()
    val mime = file.mimeType.lowercase()

    when {
        mime.startsWith("image") || name.endsWith(".jpg") || name.endsWith(".png") || name.endsWith(".webp") || name.endsWith(".jpeg") -> {
            onPreviewImage(file)
        }
        mime.startsWith("text") || name.endsWith(".txt") || name.endsWith(".md") || name.endsWith(".json") || name.endsWith(".csv") -> {
            onPreviewText(file)
        }
        else -> {
            // Open via external intent with FileProvider
            val localFile = File(file.localFilePath)
            if (localFile.exists()) {
                try {
                    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", localFile)
                    val intent = Intent(Intent.ACTION_VIEW).apply {
                        setDataAndType(uri, mime.ifBlank { "*/*" })
                        flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
                    }
                    context.startActivity(Intent.createChooser(intent, "Open file with"))
                } catch (e: Exception) {
                    Toast.makeText(context, "No app available to open this file", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(context, "File does not exist on disk", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

private suspend fun importProjectAttachment(
    context: Context,
    uri: Uri,
    projectId: String,
    category: String,
    onSaveFile: (FileAttachmentEntity) -> Unit
) = withContext(Dispatchers.IO) {
    try {
        val vaultDir = File(context.filesDir, "vault")
        vaultDir.mkdirs()

        val time = System.currentTimeMillis()
        val originalName = uri.lastPathSegment?.substringAfterLast('/') ?: "file"
        val fileName = if (originalName.contains(".")) originalName else "file_$time"
        val destFile = File(vaultDir, "proj_${projectId}_${time}_$fileName")

        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(destFile).use { output ->
                input.copyTo(output)
            }
        }

        val mimeType = context.contentResolver.getType(uri) ?: "application/octet-stream"
        val friendlyName = fileName.removePrefix("proj_${projectId}_${time}_")

        val entity = FileAttachmentEntity(
            name = friendlyName,
            localFilePath = destFile.absolutePath,
            mimeType = mimeType,
            sizeBytes = destFile.length(),
            category = category,
            projectId = projectId
        )
        onSaveFile(entity)

        withContext(Dispatchers.Main) {
            Toast.makeText(context, "Attached $friendlyName to project!", Toast.LENGTH_SHORT).show()
        }
    } catch (e: Exception) {
        withContext(Dispatchers.Main) {
            Toast.makeText(context, "Failed to attach: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}

private fun parseMilestones(json: String): List<ProjectMilestone> {
    if (json.isBlank() || json == "[]") return emptyList()
    return try {
        val array = JSONArray(json)
        val list = mutableListOf<ProjectMilestone>()
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            list.add(
                ProjectMilestone(
                    id = obj.optString("id", UUID.randomUUID().toString()),
                    title = obj.optString("title", ""),
                    isCompleted = obj.optBoolean("isCompleted", false),
                    targetDate = if (obj.has("targetDate")) obj.optLong("targetDate") else null
                )
            )
        }
        list
    } catch (e: Exception) {
        emptyList()
    }
}

private fun serializeMilestones(milestones: List<ProjectMilestone>): String {
    val array = JSONArray()
    for (m in milestones) {
        val obj = JSONObject()
        obj.put("id", m.id)
        obj.put("title", m.title)
        obj.put("isCompleted", m.isCompleted)
        m.targetDate?.let { obj.put("targetDate", it) }
        array.put(obj)
    }
    return array.toString()
}

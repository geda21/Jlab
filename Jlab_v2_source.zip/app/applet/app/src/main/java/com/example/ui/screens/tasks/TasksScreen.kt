package com.example.ui.screens.tasks

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.ProjectEntity
import com.example.data.local.entity.TaskEntity
import com.example.ui.components.EmptyState
import com.example.ui.components.JlabTopBar
import com.example.ui.components.PriorityBadge
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

enum class TaskFilterTab(val label: String) {
    TODAY("Today"),
    UPCOMING("Upcoming"),
    OVERDUE("Overdue"),
    ALL("All Active"),
    COMPLETED("Completed"),
    INBOX("Inbox")
}

enum class TaskSortOrder(val label: String) {
    DUE_DATE("Due Date"),
    PRIORITY("Priority"),
    TITLE("Title (A-Z)"),
    NEWEST("Newest First")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TasksScreen(
    tasks: List<TaskEntity>,
    projects: List<ProjectEntity> = emptyList(),
    onSaveTask: (TaskEntity) -> Unit,
    onCompleteTask: (String, String) -> Unit,
    onReopenTask: (String, String) -> Unit = { _, _ -> },
    onSnoozeTask: (String) -> Unit,
    onDeleteTask: (String) -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableStateOf(TaskFilterTab.TODAY) }
    var sortOrder by remember { mutableStateOf(TaskSortOrder.DUE_DATE) }
    var searchQuery by remember { mutableStateOf("") }
    var isSearchActive by remember { mutableStateOf(false) }

    var quickTodoText by remember { mutableStateOf("") }
    var showAddDialog by remember { mutableStateOf(false) }
    var editingTask by remember { mutableStateOf<TaskEntity?>(null) }
    var taskToDelete by remember { mutableStateOf<TaskEntity?>(null) }
    var showSortMenu by remember { mutableStateOf(false) }

    val cal = Calendar.getInstance()
    cal.set(Calendar.HOUR_OF_DAY, 23)
    cal.set(Calendar.MINUTE, 59)
    cal.set(Calendar.SECOND, 59)
    val endOfToday = cal.timeInMillis

    cal.set(Calendar.HOUR_OF_DAY, 0)
    cal.set(Calendar.MINUTE, 0)
    cal.set(Calendar.SECOND, 0)
    val startOfToday = cal.timeInMillis

    // 1. Tab filtering
    val tabFiltered = remember(tasks, selectedTab, endOfToday, startOfToday) {
        when (selectedTab) {
            TaskFilterTab.TODAY -> tasks.filter {
                it.status != "COMPLETED" && ((it.dueDate != null && it.dueDate <= endOfToday) || it.dueDate == null)
            }
            TaskFilterTab.UPCOMING -> tasks.filter {
                it.status != "COMPLETED" && it.dueDate != null && it.dueDate > endOfToday
            }
            TaskFilterTab.OVERDUE -> tasks.filter {
                it.status != "COMPLETED" && it.dueDate != null && it.dueDate < startOfToday
            }
            TaskFilterTab.ALL -> tasks.filter { it.status != "COMPLETED" }
            TaskFilterTab.COMPLETED -> tasks.filter { it.status == "COMPLETED" }
            TaskFilterTab.INBOX -> tasks.filter { it.isQuickTodo || it.status == "INBOX" }
        }
    }

    // 2. Search query filtering
    val searchFiltered = remember(tabFiltered, searchQuery) {
        if (searchQuery.isBlank()) tabFiltered
        else {
            val q = searchQuery.trim().lowercase()
            tabFiltered.filter {
                it.title.lowercase().contains(q) || it.description.lowercase().contains(q) || it.category.lowercase().contains(q)
            }
        }
    }

    // 3. Sorting
    val sortedTasks = remember(searchFiltered, sortOrder) {
        when (sortOrder) {
            TaskSortOrder.DUE_DATE -> searchFiltered.sortedWith(
                compareBy<TaskEntity> { it.dueDate ?: Long.MAX_VALUE }
                    .thenBy { it.priorityRank() }
            )
            TaskSortOrder.PRIORITY -> searchFiltered.sortedBy { it.priorityRank() }
            TaskSortOrder.TITLE -> searchFiltered.sortedBy { it.title.lowercase() }
            TaskSortOrder.NEWEST -> searchFiltered.sortedByDescending { it.createdAt }
        }
    }

    val pendingCount = remember(tasks) { tasks.count { it.status != "COMPLETED" } }

    Scaffold(
        topBar = {
            if (isSearchActive) {
                TopAppBar(
                    title = {
                        TextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Search tasks...") },
                            singleLine = true,
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = {
                            isSearchActive = false
                            searchQuery = ""
                        }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Exit search")
                        }
                    },
                    actions = {
                        if (searchQuery.isNotBlank()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear")
                            }
                        }
                    }
                )
            } else {
                JlabTopBar(
                    title = "Task Management",
                    subtitle = "$pendingCount pending · ${tasks.size} total tasks",
                    navigationIcon = Icons.AutoMirrored.Filled.ArrowBack,
                    onNavigationClick = onNavigateBack,
                    actions = {
                        IconButton(onClick = { isSearchActive = true }) {
                            Icon(Icons.Default.Search, contentDescription = "Search")
                        }

                        Box {
                            IconButton(onClick = { showSortMenu = true }) {
                                Icon(Icons.Default.Sort, contentDescription = "Sort")
                            }
                            DropdownMenu(
                                expanded = showSortMenu,
                                onDismissRequest = { showSortMenu = false }
                            ) {
                                TaskSortOrder.values().forEach { order ->
                                    DropdownMenuItem(
                                        text = {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                if (sortOrder == order) {
                                                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                }
                                                Text(order.label)
                                            }
                                        },
                                        onClick = {
                                            sortOrder = order
                                            showSortMenu = false
                                        }
                                    )
                                }
                            }
                        }

                        IconButton(onClick = { showAddDialog = true }) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = "Add Task")
                        }
                    }
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Quick Todo Creation Bar
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.FlashOn,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    TextField(
                        value = quickTodoText,
                        onValueChange = { quickTodoText = it },
                        placeholder = { Text("Quick todo (press send to create)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent
                        )
                    )
                    IconButton(
                        onClick = {
                            if (quickTodoText.isNotBlank()) {
                                onSaveTask(
                                    TaskEntity(
                                        title = quickTodoText.trim(),
                                        isQuickTodo = true,
                                        status = "INBOX",
                                        dueDate = System.currentTimeMillis()
                                    )
                                )
                                quickTodoText = ""
                                Toast.makeText(context, "Quick todo added!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        enabled = quickTodoText.isNotBlank()
                    ) {
                        Icon(imageVector = Icons.Default.Send, contentDescription = "Quick Add")
                    }
                }
            }

            // Status Filter Tabs
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(TaskFilterTab.values()) { tab ->
                    val count = when (tab) {
                        TaskFilterTab.TODAY -> tasks.count { it.status != "COMPLETED" && ((it.dueDate != null && it.dueDate <= endOfToday) || it.dueDate == null) }
                        TaskFilterTab.UPCOMING -> tasks.count { it.status != "COMPLETED" && it.dueDate != null && it.dueDate > endOfToday }
                        TaskFilterTab.OVERDUE -> tasks.count { it.status != "COMPLETED" && it.dueDate != null && it.dueDate < startOfToday }
                        TaskFilterTab.ALL -> pendingCount
                        TaskFilterTab.COMPLETED -> tasks.count { it.status == "COMPLETED" }
                        TaskFilterTab.INBOX -> tasks.count { it.isQuickTodo || it.status == "INBOX" }
                    }

                    FilterChip(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab },
                        label = { Text("${tab.label} ($count)") }
                    )
                }
            }

            // Task List
            if (sortedTasks.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(bottom = 50.dp),
                    contentAlignment = Alignment.Center
                ) {
                    EmptyState(
                        icon = if (selectedTab == TaskFilterTab.COMPLETED) Icons.Default.CheckCircleOutline else Icons.Outlined.AssignmentTurnedIn,
                        title = if (searchQuery.isNotBlank()) "No matching tasks found" else "No ${selectedTab.label.lowercase()} tasks",
                        message = if (searchQuery.isNotBlank()) "Try searching for a different keyword or filter." else "All tasks caught up for this view.",
                        actionButtonText = if (selectedTab != TaskFilterTab.COMPLETED) "Create Task" else null,
                        onActionClick = { showAddDialog = true }
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(sortedTasks, key = { it.id }) { task ->
                        val project = remember(task.projectId, projects) {
                            projects.find { it.id == task.projectId }
                        }

                        TaskItemRow(
                            task = task,
                            projectName = project?.name,
                            onComplete = {
                                onCompleteTask(task.id, task.title)
                                Toast.makeText(context, "Completed!", Toast.LENGTH_SHORT).show()
                            },
                            onReopen = {
                                onReopenTask(task.id, task.title)
                                Toast.makeText(context, "Reopened task", Toast.LENGTH_SHORT).show()
                            },
                            onSnooze = { onSnoozeTask(task.id) },
                            onEdit = { editingTask = task },
                            onDelete = { taskToDelete = task }
                        )
                    }
                }
            }
        }
    }

    // Add / Edit Task Dialog
    if (showAddDialog || editingTask != null) {
        TaskEditDialog(
            existingTask = editingTask,
            projects = projects,
            onDismiss = {
                showAddDialog = false
                editingTask = null
            },
            onSave = { task ->
                onSaveTask(task)
                showAddDialog = false
                editingTask = null
                Toast.makeText(context, "Task saved successfully", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // Delete Confirmation Dialog
    if (taskToDelete != null) {
        AlertDialog(
            onDismissRequest = { taskToDelete = null },
            title = { Text("Delete Task?", fontWeight = FontWeight.Bold) },
            text = { Text("Are you sure you want to delete task \"${taskToDelete?.title}\"? This action cannot be undone.") },
            confirmButton = {
                Button(
                    onClick = {
                        taskToDelete?.let { onDeleteTask(it.id) }
                        taskToDelete = null
                        Toast.makeText(context, "Task deleted", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { taskToDelete = null }) { Text("Cancel") }
            }
        )
    }
}

@Composable
fun TaskItemRow(
    task: TaskEntity,
    projectName: String? = null,
    onComplete: () -> Unit,
    onReopen: () -> Unit = onComplete,
    onSnooze: () -> Unit = {},
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val isCompleted = task.status == "COMPLETED"
    val dateStr = task.dueDate?.let {
        SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date(it))
    }
    val isOverdue = !isCompleted && task.dueDate != null && task.dueDate < System.currentTimeMillis() - 86400000L

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onEdit() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = {
                    if (isCompleted) onReopen() else onComplete()
                }
            ) {
                Icon(
                    imageVector = if (isCompleted) Icons.Default.CheckCircle else Icons.Outlined.RadioButtonUnchecked,
                    contentDescription = if (isCompleted) "Reopen Task" else "Complete Task",
                    tint = if (isCompleted) JlabEmerald else MaterialTheme.colorScheme.primary
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = task.title,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    textDecoration = if (isCompleted) TextDecoration.LineThrough else null,
                    color = if (isCompleted) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
                )

                if (task.description.isNotBlank()) {
                    Text(
                        text = task.description,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Row(
                    modifier = Modifier.padding(top = 2.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (dateStr != null) {
                        Text(
                            text = if (isOverdue) "Overdue · $dateStr" else "Due: $dateStr",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isOverdue) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = if (isOverdue) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 11.sp
                        )
                    }

                    if (!projectName.isNullOrBlank()) {
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                        ) {
                            Text(
                                text = projectName,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp),
                                fontSize = 10.sp
                            )
                        }
                    } else if (task.category.isNotBlank() && task.category != "General") {
                        Text(
                            text = "• ${task.category}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            PriorityBadge(priority = task.priority)

            Spacer(modifier = Modifier.width(4.dp))

            IconButton(
                onClick = onDelete,
                modifier = Modifier.size(30.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.DeleteOutline,
                    contentDescription = "Delete",
                    modifier = Modifier.size(18.dp),
                    tint = MaterialTheme.colorScheme.error
                )
            }
        }
    }
}

@Composable
fun TaskEditDialog(
    existingTask: TaskEntity?,
    projects: List<ProjectEntity> = emptyList(),
    onDismiss: () -> Unit,
    onSave: (TaskEntity) -> Unit
) {
    var title by remember { mutableStateOf(existingTask?.title ?: "") }
    var description by remember { mutableStateOf(existingTask?.description ?: "") }
    var priority by remember { mutableStateOf(existingTask?.priority ?: "MEDIUM") }
    var category by remember { mutableStateOf(existingTask?.category ?: "General") }
    var selectedProjectId by remember { mutableStateOf(existingTask?.projectId) }
    var dueDateSelection by remember {
        mutableStateOf(
            when {
                existingTask?.dueDate == null -> "NONE"
                else -> "SET"
            }
        )
    }

    var isSaving by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(if (existingTask != null) "Edit Task Details" else "New Actionable Task", fontWeight = FontWeight.Bold)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Task Title *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description & Notes") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )

                // Project Association
                if (projects.isNotEmpty()) {
                    Text("Link to Project:", style = MaterialTheme.typography.labelMedium)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        item {
                            FilterChip(
                                selected = selectedProjectId == null,
                                onClick = { selectedProjectId = null },
                                label = { Text("Standalone") }
                            )
                        }
                        items(projects) { p ->
                            FilterChip(
                                selected = selectedProjectId == p.id,
                                onClick = { selectedProjectId = p.id },
                                label = { Text(p.name) }
                            )
                        }
                    }
                }

                // Priority Selection
                Text("Priority Level:", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("LOW", "MEDIUM", "HIGH", "CRITICAL").forEach { p ->
                        FilterChip(
                            selected = priority == p,
                            onClick = { priority = p },
                            label = { Text(p, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                // Due Date Options
                Text("Schedule / Due Date:", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(
                        selected = dueDateSelection == "TODAY",
                        onClick = { dueDateSelection = "TODAY" },
                        label = { Text("Today") }
                    )
                    FilterChip(
                        selected = dueDateSelection == "TOMORROW",
                        onClick = { dueDateSelection = "TOMORROW" },
                        label = { Text("Tomorrow") }
                    )
                    FilterChip(
                        selected = dueDateSelection == "NONE",
                        onClick = { dueDateSelection = "NONE" },
                        label = { Text("No Date") }
                    )
                }

                OutlinedTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = { Text("Category") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank() && !isSaving) {
                        isSaving = true
                        val computedDueDate: Long? = when (dueDateSelection) {
                            "TODAY" -> System.currentTimeMillis()
                            "TOMORROW" -> System.currentTimeMillis() + 86400000L
                            "NONE" -> null
                            else -> existingTask?.dueDate ?: System.currentTimeMillis()
                        }

                        val task = existingTask?.copy(
                            title = title.trim(),
                            description = description.trim(),
                            priority = priority,
                            category = category.trim(),
                            projectId = selectedProjectId,
                            dueDate = computedDueDate,
                            updatedAt = System.currentTimeMillis()
                        ) ?: TaskEntity(
                            title = title.trim(),
                            description = description.trim(),
                            priority = priority,
                            category = category.trim(),
                            projectId = selectedProjectId,
                            dueDate = computedDueDate
                        )
                        onSave(task)
                    }
                },
                enabled = title.isNotBlank() && !isSaving
            ) {
                Text("Save Task")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

private fun TaskEntity.priorityRank(): Int {
    return when (this.priority) {
        "CRITICAL" -> 1
        "HIGH" -> 2
        "MEDIUM" -> 3
        else -> 4
    }
}

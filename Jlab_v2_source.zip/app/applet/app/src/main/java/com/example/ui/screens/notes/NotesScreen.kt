package com.example.ui.screens.notes

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.NoteEntity
import com.example.ui.components.EmptyState
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotesScreen(
    notes: List<NoteEntity>,
    deletedNotes: List<NoteEntity> = emptyList(),
    onCreateNote: (NoteEntity) -> Unit,
    onUpdateNote: (NoteEntity) -> Unit,
    onMoveNoteToTrash: (String) -> Unit,
    onMoveNotesToTrash: (List<String>) -> Unit,
    onArchiveNotes: (List<String>) -> Unit,
    onUpdateNotesCategory: (List<String>, String) -> Unit,
    onSetNotesPinned: (List<String>, Boolean) -> Unit,
    onRestoreNote: (String) -> Unit,
    onRestoreNotes: (List<String>) -> Unit,
    onDeleteNotePermanently: (String) -> Unit,
    onDeleteNotesPermanently: (List<String>) -> Unit,
    onEmptyTrash: () -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current

    // Screen navigation state
    var isEditing by remember { mutableStateOf(false) }
    var editingNote by remember { mutableStateOf<NoteEntity?>(null) }
    var isTrashView by remember { mutableStateOf(false) }

    // Multi-selection state
    val selectedIds = remember { mutableStateListOf<String>() }
    val isSelectionMode = selectedIds.isNotEmpty()

    // Filter & search state
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }

    // Confirmation dialogs
    var showBulkTrashDialog by remember { mutableStateOf(false) }
    var showBulkCategoryDialog by remember { mutableStateOf(false) }

    // Back handling
    BackHandler {
        when {
            isTrashView -> isTrashView = false
            isSelectionMode -> selectedIds.clear()
            else -> onNavigateBack()
        }
    }

    // Dynamic Categories list
    val categories = remember(notes) {
        listOf("All") + (listOf("Personal", "Learning", "Business", "Development", "Ideas", "Reference") + notes.map { it.category.trim() }.filter { it.isNotBlank() }).distinct()
    }

    // Filtered Notes
    val filteredNotes = remember(notes, selectedCategory, searchQuery) {
        var list = notes
        if (selectedCategory != "All") {
            list = list.filter { it.category.equals(selectedCategory, ignoreCase = true) }
        }
        if (searchQuery.isNotBlank()) {
            val q = searchQuery.trim().lowercase()
            list = list.filter {
                it.title.lowercase().contains(q) ||
                it.content.lowercase().contains(q) ||
                it.category.lowercase().contains(q) ||
                it.tags.lowercase().contains(q)
            }
        }
        list
    }

    // 1. Note Editor Subscreen
    if (isEditing) {
        NoteEditorScreen(
            initialNote = editingNote,
            existingCategories = categories.filter { it != "All" },
            onSaveNote = { note, isNew ->
                if (isNew) {
                    onCreateNote(note)
                } else {
                    onUpdateNote(note)
                }
                editingNote = note
            },
            onMoveToTrash = {
                editingNote?.let {
                    onMoveNoteToTrash(it.id)
                    Toast.makeText(context, "Moved to Trash", Toast.LENGTH_SHORT).show()
                }
                isEditing = false
                editingNote = null
            },
            onBack = {
                isEditing = false
                editingNote = null
            }
        )
        return
    }

    // 2. Trash Subscreen
    if (isTrashView) {
        TrashNotesScreen(
            deletedNotes = deletedNotes,
            onRestoreNote = onRestoreNote,
            onRestoreNotes = onRestoreNotes,
            onDeletePermanently = onDeleteNotePermanently,
            onDeleteNotesPermanently = onDeleteNotesPermanently,
            onEmptyTrash = onEmptyTrash,
            onBack = { isTrashView = false }
        )
        return
    }

    // 3. Notes List Screen
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    if (isSelectionMode) {
                        Text(
                            text = "${selectedIds.size} selected",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )
                    } else {
                        Column {
                            Text(
                                text = "Notes",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleLarge
                            )
                            Text(
                                text = "${notes.size} notes",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = {
                            if (isSelectionMode) {
                                selectedIds.clear()
                            } else {
                                onNavigateBack()
                            }
                        }
                    ) {
                        Icon(
                            imageVector = if (isSelectionMode) Icons.Default.Close else Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = if (isSelectionMode) "Clear selection" else "Back"
                        )
                    }
                },
                actions = {
                    if (isSelectionMode) {
                        TextButton(
                            onClick = {
                                if (selectedIds.size == filteredNotes.size) {
                                    selectedIds.clear()
                                } else {
                                    selectedIds.clear()
                                    selectedIds.addAll(filteredNotes.map { it.id })
                                }
                            }
                        ) {
                            Text(
                                text = if (selectedIds.size == filteredNotes.size) "Deselect" else "Select all",
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    } else {
                        // Trash Shortcut Button
                        IconButton(onClick = { isTrashView = true }) {
                            BadgedBox(
                                badge = {
                                    if (deletedNotes.isNotEmpty()) {
                                        Badge { Text("${deletedNotes.size}") }
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.Delete,
                                    contentDescription = "Trash",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        // Add Note Button
                        IconButton(
                            onClick = {
                                editingNote = null
                                isEditing = true
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "New Note",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            )
        },
        bottomBar = {
            if (isSelectionMode) {
                // Multi-select Contextual Action Bar
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding(),
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 6.dp,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Pin / Unpin
                        val anyUnpinned = selectedIds.any { id -> notes.find { it.id == id }?.isPinned == false }
                        IconButton(
                            onClick = {
                                onSetNotesPinned(selectedIds.toList(), anyUnpinned)
                                Toast.makeText(context, if (anyUnpinned) "Pinned ${selectedIds.size} notes" else "Unpinned ${selectedIds.size} notes", Toast.LENGTH_SHORT).show()
                                selectedIds.clear()
                            }
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = if (anyUnpinned) Icons.Default.PushPin else Icons.Outlined.PushPin,
                                    contentDescription = "Pin",
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(if (anyUnpinned) "Pin" else "Unpin", style = MaterialTheme.typography.labelSmall)
                            }
                        }

                        // Move Category
                        IconButton(onClick = { showBulkCategoryDialog = true }) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.Folder, contentDescription = "Category", modifier = Modifier.size(20.dp))
                                Text("Category", style = MaterialTheme.typography.labelSmall)
                            }
                        }

                        // Archive
                        IconButton(
                            onClick = {
                                onArchiveNotes(selectedIds.toList())
                                Toast.makeText(context, "Archived ${selectedIds.size} notes", Toast.LENGTH_SHORT).show()
                                selectedIds.clear()
                            }
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.Archive, contentDescription = "Archive", modifier = Modifier.size(20.dp))
                                Text("Archive", style = MaterialTheme.typography.labelSmall)
                            }
                        }

                        // Move to Trash
                        IconButton(
                            onClick = { showBulkTrashDialog = true }
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.Delete, contentDescription = "Trash", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(20.dp))
                                Text("Trash", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }
        },
        floatingActionButton = {
            if (!isSelectionMode) {
                FloatingActionButton(
                    onClick = {
                        editingNote = null
                        isEditing = true
                    },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "New Note")
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Search Input
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    TextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Search title, content, tags…", style = MaterialTheme.typography.bodyMedium) },
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            disabledContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent
                        ),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    if (searchQuery.isNotEmpty()) {
                        IconButton(
                            onClick = { searchQuery = "" },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear", modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }

            // Compact Category Filter Chips Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                categories.forEach { cat ->
                    val isSelected = selectedCategory.equals(cat, ignoreCase = true)
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedCategory = cat },
                        label = {
                            Text(
                                text = cat,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary,
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        border = BorderStroke(
                            1.dp,
                            if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)
                        ),
                        shape = RoundedCornerShape(8.dp)
                    )
                }
            }

            // Notes List
            if (filteredNotes.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    EmptyState(
                        icon = Icons.Outlined.NoteAlt,
                        title = if (searchQuery.isNotEmpty()) "No matching notes" else "No notes yet",
                        message = if (searchQuery.isNotEmpty()) "Try adjusting your search query or category filter." else "Tap + to capture your first note. Notes are saved only when you choose to save."
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 80.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredNotes, key = { it.id }) { note ->
                        val isSelected = selectedIds.contains(note.id)
                        NoteCardItem(
                            note = note,
                            isSelected = isSelected,
                            isSelectionMode = isSelectionMode,
                            onClick = {
                                if (isSelectionMode) {
                                    if (isSelected) selectedIds.remove(note.id) else selectedIds.add(note.id)
                                } else {
                                    editingNote = note
                                    isEditing = true
                                }
                            },
                            onLongClick = {
                                if (!isSelectionMode) {
                                    selectedIds.add(note.id)
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    // Confirmation: Move selected notes to Trash
    if (showBulkTrashDialog) {
        AlertDialog(
            onDismissRequest = { showBulkTrashDialog = false },
            title = { Text("Move ${selectedIds.size} notes to Trash?") },
            text = { Text("Selected notes will be moved to the Trash. You can restore them at any time.") },
            confirmButton = {
                Button(
                    onClick = {
                        val ids = selectedIds.toList()
                        selectedIds.clear()
                        showBulkTrashDialog = false
                        onMoveNotesToTrash(ids)
                        Toast.makeText(context, "Moved ${ids.size} notes to Trash", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Move to Trash")
                }
            },
            dismissButton = {
                TextButton(onClick = { showBulkTrashDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Category Selector Dialog for Bulk Action
    if (showBulkCategoryDialog) {
        val targetCategories = remember(categories) { categories.filter { it != "All" } }
        AlertDialog(
            onDismissRequest = { showBulkCategoryDialog = false },
            title = { Text("Move to Category") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    targetCategories.forEach { cat ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    val ids = selectedIds.toList()
                                    selectedIds.clear()
                                    showBulkCategoryDialog = false
                                    onUpdateNotesCategory(ids, cat)
                                    Toast.makeText(context, "Moved ${ids.size} notes to $cat", Toast.LENGTH_SHORT).show()
                                }
                        ) {
                            Text(
                                text = cat,
                                style = MaterialTheme.typography.bodyLarge,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                            )
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showBulkCategoryDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun NoteCardItem(
    note: NoteEntity,
    isSelected: Boolean,
    isSelectionMode: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val relativeTime = remember(note.updatedAt) {
        val diff = System.currentTimeMillis() - note.updatedAt
        val minutes = diff / (60 * 1000)
        val hours = minutes / 60
        val days = hours / 24
        when {
            minutes < 1 -> "Just now"
            minutes < 60 -> "${minutes}m ago"
            hours < 24 -> "${hours}h ago"
            days < 7 -> "${days}d ago"
            else -> SimpleDateFormat("MMM d", Locale.getDefault()).format(Date(note.updatedAt))
        }
    }

    val plainSnippet = remember(note.content) {
        RichTextParser.toPlainText(note.content).trim().lines().joinToString(" ")
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            ),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.28f) else MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(
            if (isSelected) 1.5.dp else 1.dp,
            if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header: Category Pill & Pin indicator
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.6f)
                ) {
                    Text(
                        text = note.category,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (note.isPinned) {
                        Icon(
                            imageVector = Icons.Default.PushPin,
                            contentDescription = "Pinned",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(14.dp)
                        )
                    }

                    if (isSelectionMode) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .size(22.dp)
                                .clip(CircleShape)
                                .background(if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isSelected) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(15.dp))
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Title
            Text(
                text = if (note.title.isBlank()) "Untitled Note" else note.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            // Content snippet
            if (plainSnippet.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = plainSnippet,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    lineHeight = 18.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Footer metadata: Updated time + Word count
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Updated $relativeTime",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )

                if (note.wordCount > 0) {
                    Text(
                        text = "${note.wordCount} words",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                    )
                }
            }
        }
    }
}

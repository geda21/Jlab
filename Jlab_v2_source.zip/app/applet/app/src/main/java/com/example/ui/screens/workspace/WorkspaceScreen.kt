package com.example.ui.screens.workspace

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.JlabTopBar
import com.example.ui.theme.*

data class WorkspaceModule(
    val id: String,
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val accentColor: Color,
    val count: Int? = null
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorkspaceScreen(
    tasksCount: Int = 0,
    projectsCount: Int = 0,
    notesCount: Int = 0,
    plansCount: Int = 0,
    promptsCount: Int = 0,
    learningCount: Int = 0,
    businessCount: Int = 0,
    socialCount: Int = 0,
    filesCount: Int = 0,
    habitsCount: Int = 0,
    goalsCount: Int = 0,
    infoCount: Int = 0,
    knowledgeCount: Int = 0,
    deletedNotesCount: Int = 0,
    favoriteModuleIds: Set<String> = emptySet(),
    recentModuleIds: List<String> = emptyList(),
    workspaceViewMode: String = "LIST",
    onSetViewMode: (String) -> Unit = {},
    onToggleFavorite: (String) -> Unit = {},
    isDarkTheme: Boolean = false,
    onToggleTheme: () -> Unit = {},
    onNavigate: (String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var isSearchActive by remember { mutableStateOf(false) }

    // Group expanded states
    var coreExpanded by remember { mutableStateOf(true) }
    var knowledgeExpanded by remember { mutableStateOf(true) }
    var planningExpanded by remember { mutableStateOf(true) }
    var filesExpanded by remember { mutableStateOf(true) }
    var systemExpanded by remember { mutableStateOf(true) }

    val isGridView = workspaceViewMode == "GRID"

    // Section 1: Core Workspace
    val coreModules = listOf(
        WorkspaceModule("projects", "Projects", "Milestones, tasks, attachments & progress", Icons.Default.Folder, JlabIndigoPrimary, if (projectsCount > 0) projectsCount else null),
        WorkspaceModule("tasks", "Tasks", "Priority scheduling, deadlines & checklists", Icons.Default.CheckCircleOutline, JlabAmber, if (tasksCount > 0) tasksCount else null),
        WorkspaceModule("notes", "Notes", "Rich-text formatting, search & categories", Icons.Default.Description, JlabEmerald, if (notesCount > 0) notesCount else null),
        WorkspaceModule("plans", "Plans & Commitments", "Daily & weekly execution schedules", Icons.Default.EventNote, JlabCyan, if (plansCount > 0) plansCount else null)
    )

    // Section 2: Knowledge & Learning
    val knowledgeModules = listOf(
        WorkspaceModule("knowledge", "Knowledge Vault", "Durable knowledge & structured takeaways", Icons.Default.MenuBook, JlabEmerald, if (knowledgeCount > 0) knowledgeCount else null),
        WorkspaceModule("learning", "Learning System", "Structured curriculums, lessons & skills", Icons.Default.School, JlabCyan, if (learningCount > 0) learningCount else null),
        WorkspaceModule("prompts", "Prompt Library", "Reusable prompts, templates & parameters", Icons.Default.AutoAwesome, Color(0xFF8B5CF6), if (promptsCount > 0) promptsCount else null)
    )

    // Section 3: Planning & Management
    val planningModules = listOf(
        WorkspaceModule("business", "Business Workspace", "Enterprises, goals & client pipelines", Icons.Default.BusinessCenter, Color(0xFFEC4899), if (businessCount > 0) businessCount else null),
        WorkspaceModule("social", "Social Content", "Content pipeline from idea to publish", Icons.Default.Share, JlabCyan, if (socialCount > 0) socialCount else null),
        WorkspaceModule("reviews", "Daily Review", "Daily reflections, scores & milestones", Icons.Default.RateReview, Color(0xFF6366F1)),
        WorkspaceModule("goals", "Goals", "Life, quarterly & business objectives", Icons.Default.Flag, JlabRuby, if (goalsCount > 0) goalsCount else null),
        WorkspaceModule("habits", "Habits & Routines", "Consistency streaks & daily triggers", Icons.Default.Repeat, JlabEmerald, if (habitsCount > 0) habitsCount else null)
    )

    // Section 4: Files & Resources
    val filesModules = listOf(
        WorkspaceModule("files", "File & Screenshot Vault", "Imported screenshots, documents & PDFs", Icons.Default.AttachFile, JlabIndigoPrimary, if (filesCount > 0) filesCount else null),
        WorkspaceModule("information", "Information Vault", "Permanent facts, credentials & configurations", Icons.Default.LibraryBooks, Color(0xFF0284C7), if (infoCount > 0) infoCount else null)
    )

    // Section 5: System
    val systemModules = listOf(
        WorkspaceModule("insights", "Activity & Insights", "Audit history & weekly productivity trends", Icons.Default.Insights, JlabIndigoPrimary),
        WorkspaceModule("calendar", "Calendar", "Integrated schedule & time commitments", Icons.Default.CalendarMonth, JlabAmber),
        WorkspaceModule("trash", "Trash & Recovery", "Restore or permanently remove records", Icons.Default.DeleteOutline, JlabRuby, if (deletedNotesCount > 0) deletedNotesCount else null),
        WorkspaceModule("settings", "Settings", "Theme preferences, security & data backup", Icons.Default.Settings, JlabSlate)
    )

    val allModulesMap = remember(coreModules, knowledgeModules, planningModules, filesModules, systemModules) {
        (coreModules + knowledgeModules + planningModules + filesModules + systemModules).associateBy { it.id }
    }

    // Dynamic Favorites: ONLY modules user explicitly favorited (Starts strictly empty!)
    val favoriteModules = remember(favoriteModuleIds, allModulesMap) {
        favoriteModuleIds.mapNotNull { allModulesMap[it] }
    }

    // Dynamic Recently Used (modules accessed recently)
    val recentModules = remember(recentModuleIds, allModulesMap) {
        recentModuleIds.mapNotNull { allModulesMap[it] }.take(4)
    }

    // Search filter
    val query = searchQuery.trim().lowercase()
    val matchesSearch: (WorkspaceModule) -> Boolean = { mod ->
        if (query.isBlank()) true
        else mod.title.lowercase().contains(query) || mod.subtitle.lowercase().contains(query)
    }

    Scaffold(
        topBar = {
            if (isSearchActive) {
                TopAppBar(
                    title = {
                        TextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Search modules...") },
                            singleLine = true,
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = {
                            isSearchActive = false
                            searchQuery = ""
                        }) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Close search")
                        }
                    },
                    actions = {
                        if (searchQuery.isNotBlank()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear")
                            }
                        }
                    }
                )
            } else {
                JlabTopBar(
                    title = "Workspace",
                    subtitle = "Personal productivity & system modules",
                    isDarkTheme = isDarkTheme,
                    onToggleTheme = onToggleTheme,
                    actions = {
                        IconButton(onClick = { isSearchActive = true }) {
                            Icon(Icons.Default.Search, contentDescription = "Search modules")
                        }
                        IconButton(
                            onClick = {
                                val nextMode = if (isGridView) "LIST" else "GRID"
                                onSetViewMode(nextMode)
                            }
                        ) {
                            Icon(
                                imageVector = if (isGridView) Icons.Default.ViewList else Icons.Default.GridView,
                                contentDescription = if (isGridView) "Switch to List View" else "Switch to Grid View"
                            )
                        }
                    }
                )
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Search Results Mode
            if (query.isNotBlank()) {
                val searchResults = allModulesMap.values.filter(matchesSearch)
                item {
                    Text(
                        text = "SEARCH RESULTS (${searchResults.size})",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                }

                if (searchResults.isEmpty()) {
                    item {
                        Text(
                            text = "No modules matched \"$searchQuery\"",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(vertical = 12.dp)
                        )
                    }
                } else {
                    items(searchResults, key = { "search_${it.id}" }) { mod ->
                        WorkspaceModuleRow(
                            module = mod,
                            isFavorite = mod.id in favoriteModuleIds,
                            onToggleFavorite = { onToggleFavorite(mod.id) },
                            onClick = { onNavigate(mod.id) }
                        )
                    }
                }
            } else {
                // ==========================================
                // 1. FAVORITES (Only if starred by user!)
                // ==========================================
                if (favoriteModules.isNotEmpty()) {
                    item {
                        WorkspaceGroupHeader(
                            title = "FAVORITES (${favoriteModules.size})",
                            icon = Icons.Default.Star,
                            isCollapsible = false
                        )
                    }
                    if (isGridView) {
                        item {
                            ModuleGridRow(
                                modules = favoriteModules,
                                favoriteModuleIds = favoriteModuleIds,
                                onToggleFavorite = onToggleFavorite,
                                onNavigate = onNavigate
                            )
                        }
                    } else {
                        items(favoriteModules, key = { "fav_${it.id}" }) { mod ->
                            WorkspaceModuleRow(
                                module = mod,
                                isFavorite = true,
                                onToggleFavorite = { onToggleFavorite(mod.id) },
                                onClick = { onNavigate(mod.id) }
                            )
                        }
                    }
                    item { Spacer(modifier = Modifier.height(4.dp)) }
                }

                // ==========================================
                // 2. RECENTLY ACCESSED (Dynamic tracking!)
                // ==========================================
                if (recentModules.isNotEmpty()) {
                    item {
                        WorkspaceGroupHeader(
                            title = "RECENTLY ACCESSED",
                            icon = Icons.Default.History,
                            isCollapsible = false
                        )
                    }
                    if (isGridView) {
                        item {
                            ModuleGridRow(
                                modules = recentModules,
                                favoriteModuleIds = favoriteModuleIds,
                                onToggleFavorite = onToggleFavorite,
                                onNavigate = onNavigate
                            )
                        }
                    } else {
                        items(recentModules, key = { "recent_${it.id}" }) { mod ->
                            WorkspaceModuleRow(
                                module = mod,
                                isFavorite = mod.id in favoriteModuleIds,
                                onToggleFavorite = { onToggleFavorite(mod.id) },
                                onClick = { onNavigate(mod.id) }
                            )
                        }
                    }
                    item { Spacer(modifier = Modifier.height(4.dp)) }
                }

                // ==========================================
                // 3. CORE WORKSPACE
                // ==========================================
                item {
                    WorkspaceGroupHeader(
                        title = "CORE WORKSPACE",
                        icon = Icons.Default.Dashboard,
                        isExpanded = coreExpanded,
                        onToggleExpand = { coreExpanded = !coreExpanded }
                    )
                }
                if (coreExpanded) {
                    if (isGridView) {
                        item {
                            ModuleGridRow(
                                modules = coreModules,
                                favoriteModuleIds = favoriteModuleIds,
                                onToggleFavorite = onToggleFavorite,
                                onNavigate = onNavigate
                            )
                        }
                    } else {
                        items(coreModules, key = { it.id }) { mod ->
                            WorkspaceModuleRow(
                                module = mod,
                                isFavorite = mod.id in favoriteModuleIds,
                                onToggleFavorite = { onToggleFavorite(mod.id) },
                                onClick = { onNavigate(mod.id) }
                            )
                        }
                    }
                    item { Spacer(modifier = Modifier.height(4.dp)) }
                }

                // ==========================================
                // 4. KNOWLEDGE & LEARNING
                // ==========================================
                item {
                    WorkspaceGroupHeader(
                        title = "KNOWLEDGE & LEARNING",
                        icon = Icons.Default.School,
                        isExpanded = knowledgeExpanded,
                        onToggleExpand = { knowledgeExpanded = !knowledgeExpanded }
                    )
                }
                if (knowledgeExpanded) {
                    if (isGridView) {
                        item {
                            ModuleGridRow(
                                modules = knowledgeModules,
                                favoriteModuleIds = favoriteModuleIds,
                                onToggleFavorite = onToggleFavorite,
                                onNavigate = onNavigate
                            )
                        }
                    } else {
                        items(knowledgeModules, key = { it.id }) { mod ->
                            WorkspaceModuleRow(
                                module = mod,
                                isFavorite = mod.id in favoriteModuleIds,
                                onToggleFavorite = { onToggleFavorite(mod.id) },
                                onClick = { onNavigate(mod.id) }
                            )
                        }
                    }
                    item { Spacer(modifier = Modifier.height(4.dp)) }
                }

                // ==========================================
                // 5. PLANNING & MANAGEMENT
                // ==========================================
                item {
                    WorkspaceGroupHeader(
                        title = "PLANNING & MANAGEMENT",
                        icon = Icons.Default.EventNote,
                        isExpanded = planningExpanded,
                        onToggleExpand = { planningExpanded = !planningExpanded }
                    )
                }
                if (planningExpanded) {
                    if (isGridView) {
                        item {
                            ModuleGridRow(
                                modules = planningModules,
                                favoriteModuleIds = favoriteModuleIds,
                                onToggleFavorite = onToggleFavorite,
                                onNavigate = onNavigate
                            )
                        }
                    } else {
                        items(planningModules, key = { it.id }) { mod ->
                            WorkspaceModuleRow(
                                module = mod,
                                isFavorite = mod.id in favoriteModuleIds,
                                onToggleFavorite = { onToggleFavorite(mod.id) },
                                onClick = { onNavigate(mod.id) }
                            )
                        }
                    }
                    item { Spacer(modifier = Modifier.height(4.dp)) }
                }

                // ==========================================
                // 6. FILES & RESOURCES
                // ==========================================
                item {
                    WorkspaceGroupHeader(
                        title = "FILES & RESOURCES",
                        icon = Icons.Default.AttachFile,
                        isExpanded = filesExpanded,
                        onToggleExpand = { filesExpanded = !filesExpanded }
                    )
                }
                if (filesExpanded) {
                    if (isGridView) {
                        item {
                            ModuleGridRow(
                                modules = filesModules,
                                favoriteModuleIds = favoriteModuleIds,
                                onToggleFavorite = onToggleFavorite,
                                onNavigate = onNavigate
                            )
                        }
                    } else {
                        items(filesModules, key = { it.id }) { mod ->
                            WorkspaceModuleRow(
                                module = mod,
                                isFavorite = mod.id in favoriteModuleIds,
                                onToggleFavorite = { onToggleFavorite(mod.id) },
                                onClick = { onNavigate(mod.id) }
                            )
                        }
                    }
                    item { Spacer(modifier = Modifier.height(4.dp)) }
                }

                // ==========================================
                // 7. SYSTEM
                // ==========================================
                item {
                    WorkspaceGroupHeader(
                        title = "SYSTEM & UTILITIES",
                        icon = Icons.Default.Settings,
                        isExpanded = systemExpanded,
                        onToggleExpand = { systemExpanded = !systemExpanded }
                    )
                }
                if (systemExpanded) {
                    if (isGridView) {
                        item {
                            ModuleGridRow(
                                modules = systemModules,
                                favoriteModuleIds = favoriteModuleIds,
                                onToggleFavorite = onToggleFavorite,
                                onNavigate = onNavigate
                            )
                        }
                    } else {
                        items(systemModules, key = { it.id }) { mod ->
                            WorkspaceModuleRow(
                                module = mod,
                                isFavorite = mod.id in favoriteModuleIds,
                                onToggleFavorite = { onToggleFavorite(mod.id) },
                                onClick = { onNavigate(mod.id) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun WorkspaceGroupHeader(
    title: String,
    icon: ImageVector,
    isCollapsible: Boolean = true,
    isExpanded: Boolean = true,
    onToggleExpand: () -> Unit = {}
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .then(if (isCollapsible) Modifier.clickable { onToggleExpand() } else Modifier)
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                letterSpacing = 0.8.sp
            )
        }

        if (isCollapsible) {
            Icon(
                imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                contentDescription = if (isExpanded) "Collapse" else "Expand",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
private fun WorkspaceModuleRow(
    module: WorkspaceModule,
    isFavorite: Boolean,
    onToggleFavorite: () -> Unit,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(module.accentColor.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = module.icon,
                    contentDescription = null,
                    tint = module.accentColor,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = module.title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = module.subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            if (module.count != null && module.count > 0) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = module.accentColor.copy(alpha = 0.15f),
                    modifier = Modifier.padding(horizontal = 6.dp)
                ) {
                    Text(
                        text = "${module.count}",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = module.accentColor,
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                    )
                }
            }

            IconButton(
                onClick = onToggleFavorite,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = if (isFavorite) Icons.Default.Star else Icons.Outlined.StarBorder,
                    contentDescription = if (isFavorite) "Remove from favorites" else "Add to favorites",
                    tint = if (isFavorite) JlabAmber else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
private fun ModuleGridRow(
    modules: List<WorkspaceModule>,
    favoriteModuleIds: Set<String>,
    onToggleFavorite: (String) -> Unit,
    onNavigate: (String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        modules.chunked(2).forEach { pair ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                pair.forEach { mod ->
                    ModuleGridCard(
                        module = mod,
                        isFavorite = mod.id in favoriteModuleIds,
                        onToggleFavorite = { onToggleFavorite(mod.id) },
                        onClick = { onNavigate(mod.id) },
                        modifier = Modifier.weight(1f)
                    )
                }
                if (pair.size == 1) {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun ModuleGridCard(
    module: WorkspaceModule,
    isFavorite: Boolean,
    onToggleFavorite: () -> Unit,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(module.accentColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = module.icon,
                        contentDescription = null,
                        tint = module.accentColor,
                        modifier = Modifier.size(18.dp)
                    )
                }

                IconButton(
                    onClick = onToggleFavorite,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = if (isFavorite) Icons.Default.Star else Icons.Outlined.StarBorder,
                        contentDescription = null,
                        tint = if (isFavorite) JlabAmber else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = module.title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Text(
                text = module.subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                fontSize = 11.sp
            )

            if (module.count != null && module.count > 0) {
                Spacer(modifier = Modifier.height(6.dp))
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = module.accentColor.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = "${module.count}",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = module.accentColor,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        fontSize = 10.sp
                    )
                }
            }
        }
    }
}

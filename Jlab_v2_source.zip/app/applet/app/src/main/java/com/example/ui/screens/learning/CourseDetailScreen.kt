package com.example.ui.screens.learning

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.*
import com.example.ui.components.EmptyState
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CourseDetailScreen(
    course: LearningEntity,
    modules: List<LearningModuleEntity>,
    lessons: List<LearningLessonEntity>,
    notes: List<NoteEntity>,
    resources: List<FileAttachmentEntity>,
    onUpdateCourse: (LearningEntity) -> Unit,
    onDeleteCourse: () -> Unit,
    onSaveModule: (LearningModuleEntity) -> Unit,
    onDeleteModule: (String) -> Unit,
    onSaveLesson: (LearningLessonEntity) -> Unit,
    onDeleteLesson: (String) -> Unit,
    onToggleLessonCompleted: (String, Boolean) -> Unit,
    onOpenLesson: (LearningLessonEntity) -> Unit,
    onOpenNote: (NoteEntity) -> Unit,
    onCreateCourseNote: () -> Unit,
    onOpenResource: (FileAttachmentEntity) -> Unit,
    onAttachResource: () -> Unit,
    onBack: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Overview", "Curriculum", "Notes (${notes.size})", "Resources (${resources.size})")

    var showEditCourseDialog by remember { mutableStateOf(false) }
    var showAddModuleDialog by remember { mutableStateOf(false) }
    var editingModule by remember { mutableStateOf<LearningModuleEntity?>(null) }
    var addingLessonToModuleId by remember { mutableStateOf<String?>(null) }
    var editingLesson by remember { mutableStateOf<LearningLessonEntity?>(null) }
    var showMoreMenu by remember { mutableStateOf(false) }

    // Automatic progress calculation
    val completedLessons = remember(lessons) { lessons.count { it.isCompleted } }
    val totalLessons = remember(lessons) { lessons.size }
    val calculatedProgress = remember(completedLessons, totalLessons, course.progressPercent) {
        if (totalLessons > 0) (completedLessons * 100) / totalLessons else course.progressPercent
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = course.title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${course.type} • $calculatedProgress% complete",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { showEditCourseDialog = true }) {
                        Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit Course")
                    }
                    Box {
                        IconButton(onClick = { showMoreMenu = true }) {
                            Icon(imageVector = Icons.Default.MoreVert, contentDescription = "More")
                        }
                        DropdownMenu(
                            expanded = showMoreMenu,
                            onDismissRequest = { showMoreMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Add Module") },
                                onClick = {
                                    showMoreMenu = false
                                    showAddModuleDialog = true
                                },
                                leadingIcon = { Icon(Icons.Default.Add, contentDescription = null) }
                            )
                            DropdownMenuItem(
                                text = { Text("Add Course Note") },
                                onClick = {
                                    showMoreMenu = false
                                    onCreateCourseNote()
                                },
                                leadingIcon = { Icon(Icons.Default.NoteAdd, contentDescription = null) }
                            )
                            HorizontalDivider()
                            DropdownMenuItem(
                                text = { Text("Delete Course", color = MaterialTheme.colorScheme.error) },
                                onClick = {
                                    showMoreMenu = false
                                    onDeleteCourse()
                                },
                                leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) }
                            )
                        }
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Course Header Bar
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 1.dp
            ) {
                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            CourseStatusPill(status = course.status)
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Text(
                                    text = "$completedLessons / $totalLessons lessons",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Text(
                            text = "$calculatedProgress%",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    LinearProgressIndicator(
                        progress = { calculatedProgress / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    ScrollableTabRow(
                        selectedTabIndex = selectedTab,
                        containerColor = Color.Transparent,
                        edgePadding = 0.dp,
                        divider = {}
                    ) {
                        tabs.forEachIndexed { index, title ->
                            Tab(
                                selected = selectedTab == index,
                                onClick = { selectedTab = index },
                                text = { Text(title, fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal) }
                            )
                        }
                    }
                }
            }

            // Tab View Area
            Box(modifier = Modifier.fillMaxSize()) {
                when (selectedTab) {
                    0 -> CourseOverviewTab(
                        course = course,
                        modulesCount = modules.size,
                        lessonsCount = totalLessons,
                        completedCount = completedLessons,
                        progress = calculatedProgress,
                        onAddModule = { showAddModuleDialog = true },
                        onContinue = {
                            val next = lessons.firstOrNull { !it.isCompleted } ?: lessons.firstOrNull()
                            if (next != null) onOpenLesson(next)
                        }
                    )
                    1 -> CourseCurriculumTab(
                        modules = modules,
                        lessons = lessons,
                        onAddModule = { showAddModuleDialog = true },
                        onEditModule = { editingModule = it },
                        onDeleteModule = onDeleteModule,
                        onAddLesson = { moduleId -> addingLessonToModuleId = moduleId },
                        onEditLesson = { editingLesson = it },
                        onDeleteLesson = onDeleteLesson,
                        onToggleLessonCompleted = onToggleLessonCompleted,
                        onOpenLesson = onOpenLesson
                    )
                    2 -> CourseNotesTab(
                        notes = notes,
                        onOpenNote = onOpenNote,
                        onCreateNote = onCreateCourseNote
                    )
                    3 -> CourseResourcesTab(
                        resources = resources,
                        onOpenResource = onOpenResource,
                        onAttachResource = onAttachResource
                    )
                }
            }
        }
    }

    // Dialogs
    if (showEditCourseDialog) {
        EditCourseDialog(
            course = course,
            onDismiss = { showEditCourseDialog = false },
            onSave = { updated ->
                onUpdateCourse(updated)
                showEditCourseDialog = false
            }
        )
    }

    if (showAddModuleDialog) {
        CreateModuleDialog(
            learningId = course.id,
            nextSortOrder = modules.size + 1,
            onDismiss = { showAddModuleDialog = false },
            onSave = {
                onSaveModule(it)
                showAddModuleDialog = false
            }
        )
    }

    editingModule?.let { mod ->
        EditModuleDialog(
            module = mod,
            onDismiss = { editingModule = null },
            onSave = {
                onSaveModule(it)
                editingModule = null
            }
        )
    }

    addingLessonToModuleId?.let { moduleId ->
        val moduleLessons = lessons.filter { it.moduleId == moduleId }
        CreateLessonDialog(
            learningId = course.id,
            moduleId = moduleId,
            nextSortOrder = moduleLessons.size + 1,
            onDismiss = { addingLessonToModuleId = null },
            onSave = {
                onSaveLesson(it)
                addingLessonToModuleId = null
            }
        )
    }

    editingLesson?.let { lesson ->
        EditLessonDialog(
            lesson = lesson,
            onDismiss = { editingLesson = null },
            onSave = {
                onSaveLesson(it)
                editingLesson = null
            }
        )
    }
}

@Composable
private fun CourseOverviewTab(
    course: LearningEntity,
    modulesCount: Int,
    lessonsCount: Int,
    completedCount: Int,
    progress: Int,
    onAddModule: () -> Unit,
    onContinue: () -> Unit
) {
    var isDescriptionExpanded by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Quick Continue Hero (if lessons exist)
        if (lessonsCount > 0 && progress < 100) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "NEXT STEP",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Continue Curriculum",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${lessonsCount - completedCount} lessons remaining",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Button(
                            onClick = onContinue,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Continue")
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }

        // Stats Overview Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = "Modules",
                    value = "$modulesCount",
                    icon = Icons.Outlined.Layers,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Completed",
                    value = "$completedCount / $lessonsCount",
                    icon = Icons.Outlined.CheckCircle,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Progress",
                    value = "$progress%",
                    icon = Icons.Outlined.PieChart,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Goal & Target Date
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "LEARNING OBJECTIVE",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (course.goal.isNotBlank()) course.goal else "Master this subject through disciplined daily lessons.",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium
                    )

                    if (course.startDate != null || course.targetDate != null) {
                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            if (course.startDate != null) {
                                val sDate = SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date(course.startDate))
                                Text(
                                    text = "Started: $sDate",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (course.targetDate != null) {
                                val tDate = SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date(course.targetDate))
                                Text(
                                    text = "Target: $tDate",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        // Collapsible Course Description
        if (course.description.isNotBlank()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "COURSE DESCRIPTION",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                            if (course.description.length > 180) {
                                TextButton(
                                    onClick = { isDescriptionExpanded = !isDescriptionExpanded },
                                    contentPadding = PaddingValues(0.dp)
                                ) {
                                    Text(
                                        text = if (isDescriptionExpanded) "Show less" else "Show more",
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = course.description,
                            style = MaterialTheme.typography.bodyMedium,
                            maxLines = if (isDescriptionExpanded) Int.MAX_VALUE else 4,
                            overflow = TextOverflow.Ellipsis,
                            lineHeight = 22.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }

        // Quick action: build curriculum
        if (modulesCount == 0) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccountTree,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Ready to structure your learning?", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(
                            text = "Divide this course into sequential modules and bite-sized lessons.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(onClick = onAddModule, shape = RoundedCornerShape(8.dp)) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Add First Module")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CourseCurriculumTab(
    modules: List<LearningModuleEntity>,
    lessons: List<LearningLessonEntity>,
    onAddModule: () -> Unit,
    onEditModule: (LearningModuleEntity) -> Unit,
    onDeleteModule: (String) -> Unit,
    onAddLesson: (String) -> Unit,
    onEditLesson: (LearningLessonEntity) -> Unit,
    onDeleteLesson: (String) -> Unit,
    onToggleLessonCompleted: (String, Boolean) -> Unit,
    onOpenLesson: (LearningLessonEntity) -> Unit
) {
    if (modules.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            EmptyState(
                icon = Icons.Default.School,
                title = "No curriculum modules yet",
                message = "Build this course step by step. Create modules and add lessons underneath.",
                actionButtonText = "Add Module",
                onActionClick = onAddModule
            )
        }
        return
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${modules.size} MODULES",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedButton(
                    onClick = onAddModule,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Module", style = MaterialTheme.typography.labelSmall)
                }
            }
        }

        items(modules.sortedBy { it.sortOrder }, key = { it.id }) { module ->
            val moduleLessons = lessons.filter { it.moduleId == module.id }.sortedBy { it.sortOrder }
            ModuleAccordionCard(
                module = module,
                lessons = moduleLessons,
                onEditModule = { onEditModule(module) },
                onDeleteModule = { onDeleteModule(module.id) },
                onAddLesson = { onAddLesson(module.id) },
                onEditLesson = onEditLesson,
                onDeleteLesson = onDeleteLesson,
                onToggleLessonCompleted = onToggleLessonCompleted,
                onOpenLesson = onOpenLesson
            )
        }
    }
}

@Composable
private fun ModuleAccordionCard(
    module: LearningModuleEntity,
    lessons: List<LearningLessonEntity>,
    onEditModule: () -> Unit,
    onDeleteModule: () -> Unit,
    onAddLesson: () -> Unit,
    onEditLesson: (LearningLessonEntity) -> Unit,
    onDeleteLesson: (String) -> Unit,
    onToggleLessonCompleted: (String, Boolean) -> Unit,
    onOpenLesson: (LearningLessonEntity) -> Unit
) {
    var isExpanded by remember { mutableStateOf(true) }
    val completedCount = lessons.count { it.isCompleted }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
    ) {
        Column {
            // Module Header Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { isExpanded = !isExpanded }
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Column {
                        Text(
                            text = module.title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "$completedCount of ${lessons.size} completed",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onAddLesson, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Add, contentDescription = "Add Lesson", modifier = Modifier.size(18.dp))
                    }
                    var showModuleMenu by remember { mutableStateOf(false) }
                    Box {
                        IconButton(onClick = { showModuleMenu = true }, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.MoreVert, contentDescription = "Module options", modifier = Modifier.size(18.dp))
                        }
                        DropdownMenu(
                            expanded = showModuleMenu,
                            onDismissRequest = { showModuleMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Edit Module") },
                                onClick = {
                                    showModuleMenu = false
                                    onEditModule()
                                },
                                leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null) }
                            )
                            DropdownMenuItem(
                                text = { Text("Delete Module", color = MaterialTheme.colorScheme.error) },
                                onClick = {
                                    showModuleMenu = false
                                    onDeleteModule()
                                },
                                leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) }
                            )
                        }
                    }
                }
            }

            AnimatedVisibility(visible = isExpanded) {
                Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)) {
                    if (module.description.isNotBlank()) {
                        Text(
                            text = module.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                    }

                    if (lessons.isEmpty()) {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("No lessons in this module", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                TextButton(onClick = onAddLesson, contentPadding = PaddingValues(0.dp)) {
                                    Text("+ Add Lesson")
                                }
                            }
                        }
                    } else {
                        lessons.forEachIndexed { idx, lesson ->
                            LessonItemRow(
                                index = idx + 1,
                                lesson = lesson,
                                onToggleCompleted = { onToggleLessonCompleted(lesson.id, !lesson.isCompleted) },
                                onOpenLesson = { onOpenLesson(lesson) },
                                onEdit = { onEditLesson(lesson) },
                                onDelete = { onDeleteLesson(lesson.id) }
                            )
                            if (idx < lessons.size - 1) {
                                HorizontalDivider(
                                    modifier = Modifier.padding(horizontal = 8.dp),
                                    color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                }
            }
        }
    }
}

@Composable
private fun LessonItemRow(
    index: Int,
    lesson: LearningLessonEntity,
    onToggleCompleted: () -> Unit,
    onOpenLesson: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onOpenLesson() }
            .padding(horizontal = 8.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            IconButton(
                onClick = onToggleCompleted,
                modifier = Modifier.size(28.dp)
            ) {
                Icon(
                    imageVector = if (lesson.isCompleted) Icons.Default.CheckCircle else Icons.Outlined.RadioButtonUnchecked,
                    contentDescription = if (lesson.isCompleted) "Completed" else "Mark complete",
                    tint = if (lesson.isCompleted) JlabEmerald else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(20.dp)
                )
            }

            Column {
                Text(
                    text = "$index. ${lesson.title}",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = if (lesson.isCompleted) FontWeight.Normal else FontWeight.SemiBold,
                    color = if (lesson.isCompleted) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
                )
                if (lesson.objective.isNotBlank()) {
                    Text(
                        text = lesson.objective,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(20.dp)
            )

            Box {
                IconButton(onClick = { showMenu = true }, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.MoreVert, contentDescription = "Options", modifier = Modifier.size(16.dp))
                }
                DropdownMenu(
                    expanded = showMenu,
                    onDismissRequest = { showMenu = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("Open Workspace") },
                        onClick = {
                            showMenu = false
                            onOpenLesson()
                        },
                        leadingIcon = { Icon(Icons.Default.OpenInNew, contentDescription = null) }
                    )
                    DropdownMenuItem(
                        text = { Text("Edit Details") },
                        onClick = {
                            showMenu = false
                            onEdit()
                        },
                        leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null) }
                    )
                    HorizontalDivider()
                    DropdownMenuItem(
                        text = { Text("Delete Lesson", color = MaterialTheme.colorScheme.error) },
                        onClick = {
                            showMenu = false
                            onDelete()
                        },
                        leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) }
                    )
                }
            }
        }
    }
}

@Composable
private fun CourseNotesTab(
    notes: List<NoteEntity>,
    onOpenNote: (NoteEntity) -> Unit,
    onCreateNote: () -> Unit
) {
    if (notes.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            EmptyState(
                icon = Icons.Default.NoteAlt,
                title = "No course notes yet",
                message = "Keep dedicated study notes, cheat sheets, and summaries tied directly to this course.",
                actionButtonText = "Create Course Note",
                onActionClick = onCreateNote
            )
        }
        return
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${notes.size} COURSE NOTES",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Button(
                    onClick = onCreateNote,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Note", style = MaterialTheme.typography.labelMedium)
                }
            }
        }

        items(notes, key = { it.id }) { note ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenNote(note) },
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = if (note.title.isNotBlank()) note.title else "Untitled Note",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    if (note.content.isNotBlank()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = note.content.take(120),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    val dateStr = SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date(note.updatedAt))
                    Text(
                        text = "Updated $dateStr • ${note.wordCount} words",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                    )
                }
            }
        }
    }
}

@Composable
private fun CourseResourcesTab(
    resources: List<FileAttachmentEntity>,
    onOpenResource: (FileAttachmentEntity) -> Unit,
    onAttachResource: () -> Unit
) {
    if (resources.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            EmptyState(
                icon = Icons.Default.AttachFile,
                title = "No course resources attached",
                message = "Attach cheat sheet screenshots, syllabus documents, diagrams, and reference PDFs to this course.",
                actionButtonText = "Attach File / Screenshot",
                onActionClick = onAttachResource
            )
        }
        return
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${resources.size} ATTACHMENTS",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedButton(
                    onClick = onAttachResource,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Attach File", style = MaterialTheme.typography.labelMedium)
                }
            }
        }

        items(resources, key = { it.id }) { file ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenResource(file) },
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
                        modifier = Modifier.size(42.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = if (file.category == "Screenshot") Icons.Default.Image else Icons.Default.InsertDriveFile,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = file.name,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${file.category} • ${file.sizeBytes / 1024} KB",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
private fun StatCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 1.dp,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(text = title, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun CourseStatusPill(status: String) {
    val (color, text) = when (status.uppercase()) {
        "COMPLETED" -> JlabEmerald to "Completed"
        "LEARNING" -> JlabIndigoPrimary to "Learning"
        "PAUSED" -> JlabAmber to "Paused"
        else -> MaterialTheme.colorScheme.onSurfaceVariant to "Not Started"
    }

    Surface(
        shape = RoundedCornerShape(6.dp),
        color = color.copy(alpha = 0.15f)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = color,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
        )
    }
}

@Composable
fun EditCourseDialog(
    course: LearningEntity,
    onDismiss: () -> Unit,
    onSave: (LearningEntity) -> Unit
) {
    var title by remember { mutableStateOf(course.title) }
    var type by remember { mutableStateOf(course.type) }
    var goal by remember { mutableStateOf(course.goal) }
    var description by remember { mutableStateOf(course.description) }
    var status by remember { mutableStateOf(course.status) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit Course Information", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Course Title *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = type,
                    onValueChange = { type = it },
                    label = { Text("Type / Level (e.g. Course, Beginner → Advanced)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = goal,
                    onValueChange = { goal = it },
                    label = { Text("Primary Learning Goal") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description & Curriculum Overview") },
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        onSave(
                            course.copy(
                                title = title.trim(),
                                type = type.trim().ifBlank { "Course" },
                                goal = goal.trim(),
                                description = description.trim(),
                                updatedAt = System.currentTimeMillis()
                            )
                        )
                    }
                },
                enabled = title.isNotBlank()
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun CreateModuleDialog(
    learningId: String,
    nextSortOrder: Int,
    onDismiss: () -> Unit,
    onSave: (LearningModuleEntity) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Course Module", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Module Title *") },
                    placeholder = { Text("e.g. Java Fundamentals") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description / Scope") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        onSave(
                            LearningModuleEntity(
                                learningId = learningId,
                                title = title.trim(),
                                description = description.trim(),
                                sortOrder = nextSortOrder
                            )
                        )
                    }
                },
                enabled = title.isNotBlank()
            ) {
                Text("Add Module")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun EditModuleDialog(
    module: LearningModuleEntity,
    onDismiss: () -> Unit,
    onSave: (LearningModuleEntity) -> Unit
) {
    var title by remember { mutableStateOf(module.title) }
    var description by remember { mutableStateOf(module.description) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit Module", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Module Title *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        onSave(
                            module.copy(
                                title = title.trim(),
                                description = description.trim()
                            )
                        )
                    }
                },
                enabled = title.isNotBlank()
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun CreateLessonDialog(
    learningId: String,
    moduleId: String,
    nextSortOrder: Int,
    onDismiss: () -> Unit,
    onSave: (LearningLessonEntity) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var objective by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Lesson", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Lesson Title *") },
                    placeholder = { Text("e.g. Variables & Data Types") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = objective,
                    onValueChange = { objective = it },
                    label = { Text("Learning Objective") },
                    placeholder = { Text("e.g. Understand primitive types and declarations") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        onSave(
                            LearningLessonEntity(
                                learningId = learningId,
                                moduleId = moduleId,
                                title = title.trim(),
                                objective = objective.trim(),
                                sortOrder = nextSortOrder
                            )
                        )
                    }
                },
                enabled = title.isNotBlank()
            ) {
                Text("Add Lesson")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

package com.example.ui.screens.vault

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import com.example.data.local.entity.*
import com.example.ui.components.EmptyState
import com.example.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FilesVaultScreen(
    files: List<FileAttachmentEntity>,
    projects: List<ProjectEntity> = emptyList(),
    learningItems: List<LearningEntity> = emptyList(),
    businesses: List<BusinessEntity> = emptyList(),
    notes: List<NoteEntity> = emptyList(),
    onSaveFile: (FileAttachmentEntity) -> Unit,
    onUpdateFile: (FileAttachmentEntity) -> Unit,
    onDeleteFile: (FileAttachmentEntity) -> Unit,
    onUpdateFileName: (String, String) -> Unit,
    onUpdateFileCategory: (String, String) -> Unit,
    onUpdateFilesCategory: (List<String>, String) -> Unit,
    onLinkFile: (String, String?, String?, String?, String?, String?) -> Unit,
    onLinkFiles: (List<String>, String?, String?, String?, String?, String?) -> Unit,
    onDeleteFiles: (List<String>) -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    // View state
    var isGridView by remember { mutableStateOf(true) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategoryFilter by remember { mutableStateOf("ALL") }
    val categoryTabs = listOf("ALL", "SCREENSHOTS", "IMAGES", "DOCUMENTS", "PDF", "OTHER")

    // Full screen viewer states
    var viewingImageFile by remember { mutableStateOf<FileAttachmentEntity?>(null) }
    var viewingTextFile by remember { mutableStateOf<FileAttachmentEntity?>(null) }
    var fileDetailTarget by remember { mutableStateOf<FileAttachmentEntity?>(null) }
    var renamingFile by remember { mutableStateOf<FileAttachmentEntity?>(null) }
    var attachingFileTarget by remember { mutableStateOf<FileAttachmentEntity?>(null) }

    // Multi-selection state
    val selectedIds = remember { mutableStateListOf<String>() }
    val isSelectionMode = selectedIds.isNotEmpty()
    var showBulkCategoryDialog by remember { mutableStateOf(false) }
    var showBulkAttachDialog by remember { mutableStateOf(false) }
    var showBulkDeleteDialog by remember { mutableStateOf(false) }

    BackHandler {
        when {
            viewingImageFile != null -> viewingImageFile = null
            viewingTextFile != null -> viewingTextFile = null
            isSelectionMode -> selectedIds.clear()
            else -> onNavigateBack()
        }
    }

    // Photo & Document pickers
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch {
                importFileToVault(context, uri, "Screenshot", onSaveFile)
            }
        }
    }

    val documentPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch {
                val mime = context.contentResolver.getType(uri) ?: ""
                val cat = if (mime.contains("pdf", ignoreCase = true)) "PDF" else "Document"
                importFileToVault(context, uri, cat, onSaveFile)
            }
        }
    }

    // Filtered list
    val filteredFiles = remember(files, searchQuery, selectedCategoryFilter) {
        var list = files
        if (selectedCategoryFilter != "ALL") {
            list = list.filter {
                when (selectedCategoryFilter) {
                    "SCREENSHOTS" -> it.category.equals("Screenshot", ignoreCase = true)
                    "IMAGES" -> it.category.equals("Image", ignoreCase = true) || it.mimeType.startsWith("image")
                    "DOCUMENTS" -> it.category.equals("Document", ignoreCase = true)
                    "PDF" -> it.category.equals("PDF", ignoreCase = true) || it.name.endsWith(".pdf", ignoreCase = true)
                    else -> !it.category.equals("Screenshot", ignoreCase = true) && !it.category.equals("Image", ignoreCase = true)
                }
            }
        }
        if (searchQuery.isNotBlank()) {
            val q = searchQuery.trim().lowercase()
            list = list.filter {
                it.name.lowercase().contains(q) ||
                it.category.lowercase().contains(q) ||
                formatHumanFileName(it.name, it.createdAt).lowercase().contains(q)
            }
        }
        list
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    if (isSelectionMode) {
                        Text(
                            text = "${selectedIds.size} selected",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )
                    } else {
                        Column {
                            Text(
                                text = "File & Screenshot Vault",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${files.size} offline files stored",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = {
                            if (isSelectionMode) selectedIds.clear() else onNavigateBack()
                        }
                    ) {
                        Icon(
                            imageVector = if (isSelectionMode) Icons.Default.Close else Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = if (isSelectionMode) "Clear selection" else "Back"
                        )
                    }
                },
                actions = {
                    if (isSelectionMode) {
                        TextButton(
                            onClick = {
                                if (selectedIds.size == filteredFiles.size) {
                                    selectedIds.clear()
                                } else {
                                    selectedIds.clear()
                                    selectedIds.addAll(filteredFiles.map { it.id })
                                }
                            }
                        ) {
                            Text(
                                text = if (selectedIds.size == filteredFiles.size) "Deselect" else "Select all",
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    } else {
                        // Toggle Grid / List
                        IconButton(onClick = { isGridView = !isGridView }) {
                            Icon(
                                imageVector = if (isGridView) Icons.Default.ViewList else Icons.Default.GridView,
                                contentDescription = if (isGridView) "List View" else "Grid View"
                            )
                        }

                        // Import Screenshot
                        IconButton(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            }
                        ) {
                            Icon(imageVector = Icons.Default.AddPhotoAlternate, contentDescription = "Import Screenshot", tint = MaterialTheme.colorScheme.primary)
                        }

                        // Import Document
                        IconButton(onClick = { documentPickerLauncher.launch(arrayOf("*/*")) }) {
                            Icon(imageVector = Icons.Default.UploadFile, contentDescription = "Import File")
                        }
                    }
                }
            )
        },
        bottomBar = {
            if (isSelectionMode) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding(),
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 6.dp,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Move Category
                        IconButton(onClick = { showBulkCategoryDialog = true }) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.Folder, contentDescription = "Category", modifier = Modifier.size(20.dp))
                                Text("Category", style = MaterialTheme.typography.labelSmall)
                            }
                        }

                        // Attach To
                        IconButton(onClick = { showBulkAttachDialog = true }) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.Link, contentDescription = "Attach To", modifier = Modifier.size(20.dp))
                                Text("Attach", style = MaterialTheme.typography.labelSmall)
                            }
                        }

                        // Delete
                        IconButton(onClick = { showBulkDeleteDialog = true }) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(20.dp))
                                Text("Delete", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Search Input
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search files by name or category...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            )

            // Category Filter Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                categoryTabs.forEach { tab ->
                    FilterChip(
                        selected = selectedCategoryFilter == tab,
                        onClick = { selectedCategoryFilter = tab },
                        label = { Text(tab) }
                    )
                }
            }

            // File Content Area
            if (filteredFiles.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    EmptyState(
                        icon = Icons.Default.FolderZip,
                        title = if (searchQuery.isNotEmpty()) "No matching files" else "Vault is empty",
                        message = "Import screenshots, research PDFs, and files directly into Jlab local storage.",
                        actionButtonText = "Import Screenshot",
                        onActionClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        }
                    )
                }
            } else {
                if (isGridView) {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(filteredFiles, key = { it.id }) { file ->
                            val isSelected = selectedIds.contains(file.id)
                            VaultGridCard(
                                file = file,
                                isSelected = isSelected,
                                isSelectionMode = isSelectionMode,
                                onClick = {
                                    if (isSelectionMode) {
                                        if (isSelected) selectedIds.remove(file.id) else selectedIds.add(file.id)
                                    } else {
                                        openFileInternal(
                                            file = file,
                                            context = context,
                                            onOpenImage = { viewingImageFile = it },
                                            onOpenText = { viewingTextFile = it },
                                            onOpenInfo = { fileDetailTarget = it }
                                        )
                                    }
                                },
                                onLongClick = {
                                    if (!isSelectionMode) {
                                        selectedIds.add(file.id)
                                    }
                                },
                                onOpenInfo = { fileDetailTarget = file }
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(filteredFiles, key = { it.id }) { file ->
                            val isSelected = selectedIds.contains(file.id)
                            VaultListRow(
                                file = file,
                                isSelected = isSelected,
                                isSelectionMode = isSelectionMode,
                                onClick = {
                                    if (isSelectionMode) {
                                        if (isSelected) selectedIds.remove(file.id) else selectedIds.add(file.id)
                                    } else {
                                        openFileInternal(
                                            file = file,
                                            context = context,
                                            onOpenImage = { viewingImageFile = it },
                                            onOpenText = { viewingTextFile = it },
                                            onOpenInfo = { fileDetailTarget = it }
                                        )
                                    }
                                },
                                onLongClick = {
                                    if (!isSelectionMode) selectedIds.add(file.id)
                                },
                                onOpenInfo = { fileDetailTarget = file }
                            )
                        }
                    }
                }
            }
        }
    }

    // 1. NATIVE INTERNAL FULL-SCREEN IMAGE VIEWER
    viewingImageFile?.let { fileEntity ->
        val localFile = File(fileEntity.localFilePath)
        NativeImageViewerDialog(
            file = fileEntity,
            localFile = localFile,
            onDismiss = { viewingImageFile = null },
            onOpenInfo = { fileDetailTarget = fileEntity },
            onRename = { renamingFile = fileEntity },
            onAttachTo = { attachingFileTarget = fileEntity },
            onDelete = {
                onDeleteFile(fileEntity)
                localFile.delete()
                viewingImageFile = null
            }
        )
    }

    // 2. NATIVE INTERNAL TEXT VIEWER
    viewingTextFile?.let { fileEntity ->
        val localFile = File(fileEntity.localFilePath)
        val textContent = remember(localFile) {
            try {
                if (localFile.exists()) localFile.readText() else "File not found"
            } catch (e: Exception) {
                "Unable to read text file: ${e.message}"
            }
        }

        AlertDialog(
            onDismissRequest = { viewingTextFile = null },
            title = {
                Text(formatHumanFileName(fileEntity.name, fileEntity.createdAt), fontWeight = FontWeight.Bold, maxLines = 1)
            },
            text = {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 380.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = textContent,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 13.sp,
                        lineHeight = 18.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            },
            confirmButton = {
                Button(onClick = { viewingTextFile = null }) { Text("Close") }
            }
        )
    }

    // 3. FILE INFO / DETAIL MODAL
    fileDetailTarget?.let { file ->
        val localFile = File(file.localFilePath)
        FileDetailDialog(
            file = file,
            localFile = localFile,
            projects = projects,
            learningItems = learningItems,
            businesses = businesses,
            notes = notes,
            onDismiss = { fileDetailTarget = null },
            onRename = {
                fileDetailTarget = null
                renamingFile = file
            },
            onAttachTo = {
                fileDetailTarget = null
                attachingFileTarget = file
            },
            onMoveCategory = { newCat ->
                onUpdateFileCategory(file.id, newCat)
                fileDetailTarget = null
            },
            onDelete = {
                onDeleteFile(file)
                localFile.delete()
                fileDetailTarget = null
            }
        )
    }

    // 4. RENAME DIALOG
    renamingFile?.let { file ->
        var newName by remember { mutableStateOf(file.name) }
        AlertDialog(
            onDismissRequest = { renamingFile = null },
            title = { Text("Rename File", fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    label = { Text("Display Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newName.isNotBlank()) {
                            onUpdateFileName(file.id, newName.trim())
                            renamingFile = null
                        }
                    },
                    enabled = newName.isNotBlank()
                ) {
                    Text("Rename")
                }
            },
            dismissButton = {
                TextButton(onClick = { renamingFile = null }) { Text("Cancel") }
            }
        )
    }

    // 5. ATTACH TO... DIALOG
    attachingFileTarget?.let { file ->
        AttachToDialog(
            file = file,
            projects = projects,
            learningItems = learningItems,
            businesses = businesses,
            notes = notes,
            onDismiss = { attachingFileTarget = null },
            onConfirmLink = { projId, noteId, taskId, bizId, learnId ->
                onLinkFile(file.id, projId, noteId, taskId, bizId, learnId)
                attachingFileTarget = null
                Toast.makeText(context, "Attachment linked successfully", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // Bulk Category Dialog
    if (showBulkCategoryDialog) {
        val categories = listOf("Screenshot", "Image", "Document", "PDF", "Other")
        AlertDialog(
            onDismissRequest = { showBulkCategoryDialog = false },
            title = { Text("Move Category (${selectedIds.size} files)") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    categories.forEach { cat ->
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onUpdateFilesCategory(selectedIds.toList(), cat)
                                    showBulkCategoryDialog = false
                                    selectedIds.clear()
                                    Toast.makeText(context, "Updated category to $cat", Toast.LENGTH_SHORT).show()
                                },
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Text(cat, modifier = Modifier.padding(12.dp), fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showBulkCategoryDialog = false }) { Text("Cancel") }
            }
        )
    }

    // Bulk Delete Dialog
    if (showBulkDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showBulkDeleteDialog = false },
            title = { Text("Delete ${selectedIds.size} files?") },
            text = { Text("This will permanently remove the selected files from your offline vault.") },
            confirmButton = {
                Button(
                    onClick = {
                        val idsToDelete = selectedIds.toList()
                        // Delete physical files
                        files.filter { it.id in idsToDelete }.forEach { File(it.localFilePath).delete() }
                        onDeleteFiles(idsToDelete)
                        showBulkDeleteDialog = false
                        selectedIds.clear()
                        Toast.makeText(context, "Deleted files", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { showBulkDeleteDialog = false }) { Text("Cancel") }
            }
        )
    }
}

// ----------------------------------------------------------------------------
// Grid & List Component Cards
// ----------------------------------------------------------------------------

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun VaultGridCard(
    file: FileAttachmentEntity,
    isSelected: Boolean,
    isSelectionMode: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onOpenInfo: () -> Unit
) {
    val localFile = remember(file.localFilePath) { File(file.localFilePath) }
    val isImage = file.mimeType.startsWith("image") || file.name.endsWith(".jpg", true) || file.name.endsWith(".png", true)
    val displayName = formatHumanFileName(file.name, file.createdAt)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            ),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(
            if (isSelected) 2.dp else 1.dp,
            if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
        )
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(115.dp)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            ) {
                if (isImage && localFile.exists()) {
                    AsyncImage(
                        model = localFile,
                        contentDescription = file.name,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = when {
                                file.category == "PDF" || file.name.endsWith(".pdf", true) -> Icons.Default.PictureAsPdf
                                file.name.endsWith(".txt", true) || file.name.endsWith(".md", true) -> Icons.Default.Description
                                else -> Icons.Default.InsertDriveFile
                            },
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(40.dp)
                        )
                    }
                }

                if (isSelectionMode) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(8.dp)
                    ) {
                        Icon(
                            imageVector = if (isSelected) Icons.Default.CheckCircle else Icons.Outlined.RadioButtonUnchecked,
                            contentDescription = null,
                            tint = if (isSelected) MaterialTheme.colorScheme.primary else Color.White
                        )
                    }
                }
            }

            Column(modifier = Modifier.padding(10.dp)) {
                Text(
                    text = displayName,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${file.sizeBytes / 1024} KB • ${file.category}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    IconButton(onClick = onOpenInfo, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Outlined.Info, contentDescription = "Info", modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun VaultListRow(
    file: FileAttachmentEntity,
    isSelected: Boolean,
    isSelectionMode: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onOpenInfo: () -> Unit
) {
    val localFile = remember(file.localFilePath) { File(file.localFilePath) }
    val isImage = file.mimeType.startsWith("image") || file.name.endsWith(".jpg", true) || file.name.endsWith(".png", true)
    val displayName = formatHumanFileName(file.name, file.createdAt)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            ),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(
            if (isSelected) 2.dp else 1.dp,
            if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                if (isImage && localFile.exists()) {
                    AsyncImage(
                        model = localFile,
                        contentDescription = file.name,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Icon(
                        imageVector = if (file.category == "PDF") Icons.Default.PictureAsPdf else Icons.Default.InsertDriveFile,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = displayName,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                val dateStr = SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date(file.createdAt))
                Text(
                    text = "${file.category} • ${file.sizeBytes / 1024} KB • $dateStr",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (isSelectionMode) {
                Icon(
                    imageVector = if (isSelected) Icons.Default.CheckCircle else Icons.Outlined.RadioButtonUnchecked,
                    contentDescription = null,
                    tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                IconButton(onClick = onOpenInfo) {
                    Icon(Icons.Outlined.Info, contentDescription = "Info", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

// ----------------------------------------------------------------------------
// Native Full-Screen Image Viewer Dialog
// ----------------------------------------------------------------------------

@Composable
private fun NativeImageViewerDialog(
    file: FileAttachmentEntity,
    localFile: File,
    onDismiss: () -> Unit,
    onOpenInfo: () -> Unit,
    onRename: () -> Unit,
    onAttachTo: () -> Unit,
    onDelete: () -> Unit
) {
    val context = LocalContext.current
    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }
    var showMoreMenu by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            // Zoomable / Pannable Image Layer
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onDoubleTap = {
                                if (scale > 1.2f) {
                                    scale = 1f
                                    offsetX = 0f
                                    offsetY = 0f
                                } else {
                                    scale = 2.5f
                                }
                            }
                        )
                    }
                    .pointerInput(Unit) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            scale = (scale * zoom).coerceIn(1f, 5f)
                            if (scale > 1f) {
                                offsetX += pan.x
                                offsetY += pan.y
                            } else {
                                offsetX = 0f
                                offsetY = 0f
                            }
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                if (localFile.exists()) {
                    AsyncImage(
                        model = localFile,
                        contentDescription = file.name,
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer(
                                scaleX = scale,
                                scaleY = scale,
                                translationX = offsetX,
                                translationY = offsetY
                            ),
                        contentScale = ContentScale.Fit
                    )
                } else {
                    Text("Image not found on device storage", color = Color.White)
                }
            }

            // Top Bar Overlay
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .statusBarsPadding(),
                color = Color.Black.copy(alpha = 0.65f)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                    }

                    Text(
                        text = formatHumanFileName(file.name, file.createdAt),
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                    )

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Share
                        IconButton(
                            onClick = {
                                shareFile(context, localFile, file.mimeType)
                            }
                        ) {
                            Icon(imageVector = Icons.Default.Share, contentDescription = "Share", tint = Color.White)
                        }

                        // Info
                        IconButton(onClick = onOpenInfo) {
                            Icon(imageVector = Icons.Outlined.Info, contentDescription = "Info", tint = Color.White)
                        }

                        // More Menu
                        Box {
                            IconButton(onClick = { showMoreMenu = true }) {
                                Icon(imageVector = Icons.Default.MoreVert, contentDescription = "More", tint = Color.White)
                            }
                            DropdownMenu(
                                expanded = showMoreMenu,
                                onDismissRequest = { showMoreMenu = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("Rename") },
                                    onClick = {
                                        showMoreMenu = false
                                        onRename()
                                    },
                                    leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null) }
                                )
                                DropdownMenuItem(
                                    text = { Text("Attach To...") },
                                    onClick = {
                                        showMoreMenu = false
                                        onAttachTo()
                                    },
                                    leadingIcon = { Icon(Icons.Default.Link, contentDescription = null) }
                                )
                                DropdownMenuItem(
                                    text = { Text("Open in External App") },
                                    onClick = {
                                        showMoreMenu = false
                                        openInExternalApp(context, localFile, file.mimeType)
                                    },
                                    leadingIcon = { Icon(Icons.Default.OpenInNew, contentDescription = null) }
                                )
                                HorizontalDivider()
                                DropdownMenuItem(
                                    text = { Text("Delete", color = MaterialTheme.colorScheme.error) },
                                    onClick = {
                                        showMoreMenu = false
                                        onDelete()
                                    },
                                    leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) }
                                )
                            }
                        }
                    }
                }
            }

            // Bottom Bar Overlay (Zoom reset & info)
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding(),
                color = Color.Black.copy(alpha = 0.65f)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${file.sizeBytes / 1024} KB • Double tap to zoom",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.75f)
                    )

                    if (scale > 1.05f) {
                        TextButton(
                            onClick = {
                                scale = 1f
                                offsetX = 0f
                                offsetY = 0f
                            }
                        ) {
                            Text("Reset Zoom", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------------------------------
// File Detail & Linking Dialog
// ----------------------------------------------------------------------------

@Composable
private fun FileDetailDialog(
    file: FileAttachmentEntity,
    localFile: File,
    projects: List<ProjectEntity>,
    learningItems: List<LearningEntity>,
    businesses: List<BusinessEntity>,
    notes: List<NoteEntity>,
    onDismiss: () -> Unit,
    onRename: () -> Unit,
    onAttachTo: () -> Unit,
    onMoveCategory: (String) -> Unit,
    onDelete: () -> Unit
) {
    val context = LocalContext.current
    var showCategoryMenu by remember { mutableStateOf(false) }

    val linkedItemName = remember(file) {
        when {
            file.projectId != null -> projects.find { it.id == file.projectId }?.name?.let { "Project: $it" }
            file.learningId != null -> learningItems.find { it.id == file.learningId }?.title?.let { "Course: $it" }
            file.businessId != null -> businesses.find { it.id == file.businessId }?.name?.let { "Business: $it" }
            file.noteId != null -> notes.find { it.id == file.noteId }?.title?.let { "Note: $it" }
            else -> "Unattached"
        } ?: "Unattached"
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = formatHumanFileName(file.name, file.createdAt),
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                DetailRow(label = "Category", value = file.category)
                DetailRow(label = "Size", value = "${file.sizeBytes / 1024} KB")
                val dateStr = SimpleDateFormat("MMM d, yyyy, h:mm a", Locale.getDefault()).format(Date(file.createdAt))
                DetailRow(label = "Imported", value = dateStr)
                DetailRow(label = "Linked To", value = linkedItemName)
                DetailRow(label = "Raw Path", value = localFile.name)

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onRename,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Rename")
                    }

                    OutlinedButton(
                        onClick = onAttachTo,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Attach To")
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(modifier = Modifier.weight(1f)) {
                        OutlinedButton(
                            onClick = { showCategoryMenu = true },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Category")
                        }
                        DropdownMenu(
                            expanded = showCategoryMenu,
                            onDismissRequest = { showCategoryMenu = false }
                        ) {
                            listOf("Screenshot", "Image", "Document", "PDF", "Other").forEach { cat ->
                                DropdownMenuItem(
                                    text = { Text(cat) },
                                    onClick = {
                                        showCategoryMenu = false
                                        onMoveCategory(cat)
                                    }
                                )
                            }
                        }
                    }

                    Button(
                        onClick = {
                            shareFile(context, localFile, file.mimeType)
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Share")
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        },
        dismissButton = {
            TextButton(onClick = onDelete) {
                Text("Delete", color = MaterialTheme.colorScheme.error)
            }
        }
    )
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun AttachToDialog(
    file: FileAttachmentEntity,
    projects: List<ProjectEntity>,
    learningItems: List<LearningEntity>,
    businesses: List<BusinessEntity>,
    notes: List<NoteEntity>,
    onDismiss: () -> Unit,
    onConfirmLink: (String?, String?, String?, String?, String?) -> Unit
) {
    var selectedType by remember { mutableStateOf("COURSE") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Attach File To Workspace", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Select target module to associate this attachment:", style = MaterialTheme.typography.bodySmall)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("COURSE", "BUSINESS", "PROJECT", "NOTE").forEach { type ->
                        FilterChip(
                            selected = selectedType == type,
                            onClick = { selectedType = type },
                            label = { Text(type, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 220.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    when (selectedType) {
                        "COURSE" -> {
                            items(learningItems, key = { it.id }) { course ->
                                AttachmentOptionItem(title = course.title, subtitle = course.type) {
                                    onConfirmLink(null, null, null, null, course.id)
                                }
                            }
                        }
                        "BUSINESS" -> {
                            items(businesses, key = { it.id }) { biz ->
                                AttachmentOptionItem(title = biz.name, subtitle = biz.status) {
                                    onConfirmLink(null, null, null, biz.id, null)
                                }
                            }
                        }
                        "PROJECT" -> {
                            items(projects, key = { it.id }) { proj ->
                                AttachmentOptionItem(title = proj.name, subtitle = proj.status) {
                                    onConfirmLink(proj.id, null, null, null, null)
                                }
                            }
                        }
                        "NOTE" -> {
                            items(notes, key = { it.id }) { note ->
                                AttachmentOptionItem(title = note.title.ifBlank { "Untitled Note" }, subtitle = note.category) {
                                    onConfirmLink(null, note.id, null, null, null)
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun AttachmentOptionItem(title: String, subtitle: String, onClick: () -> Unit) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(8.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text("Attach →", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
    }
}

// ----------------------------------------------------------------------------
// Internal Viewer Routing & Helper Utilities
// ----------------------------------------------------------------------------

private fun openFileInternal(
    file: FileAttachmentEntity,
    context: Context,
    onOpenImage: (FileAttachmentEntity) -> Unit,
    onOpenText: (FileAttachmentEntity) -> Unit,
    onOpenInfo: (FileAttachmentEntity) -> Unit
) {
    val name = file.name.lowercase()
    val mime = file.mimeType.lowercase()

    when {
        mime.startsWith("image") || name.endsWith(".jpg") || name.endsWith(".png") || name.endsWith(".webp") || name.endsWith(".jpeg") -> {
            onOpenImage(file)
        }
        mime.startsWith("text") || name.endsWith(".txt") || name.endsWith(".md") || name.endsWith(".json") || name.endsWith(".csv") -> {
            onOpenText(file)
        }
        else -> {
            onOpenInfo(file)
        }
    }
}

private fun formatHumanFileName(name: String, createdAt: Long): String {
    // If the name starts with the ugly raw timestamp pattern "jlab_...", convert to a friendly label
    return if (name.startsWith("jlab_")) {
        val dateStr = SimpleDateFormat("MMM d, h:mm a", Locale.getDefault()).format(Date(createdAt))
        val ext = name.substringAfterLast('.', "")
        if (ext.isNotBlank()) "Screenshot • $dateStr.$ext" else "Screenshot • $dateStr"
    } else {
        name
    }
}

private fun shareFile(context: Context, file: File, mimeType: String) {
    if (!file.exists()) {
        Toast.makeText(context, "File does not exist", Toast.LENGTH_SHORT).show()
        return
    }
    try {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType.ifBlank { "*/*" }
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Share file"))
    } catch (e: Exception) {
        Toast.makeText(context, "Unable to share file: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}

private fun openInExternalApp(context: Context, file: File, mimeType: String) {
    if (!file.exists()) {
        Toast.makeText(context, "File does not exist", Toast.LENGTH_SHORT).show()
        return
    }
    try {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mimeType.ifBlank { "*/*" })
            flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
        }
        context.startActivity(Intent.createChooser(intent, "Open file with"))
    } catch (e: Exception) {
        Toast.makeText(context, "No app found to open this file", Toast.LENGTH_SHORT).show()
    }
}

private suspend fun importFileToVault(
    context: Context,
    uri: Uri,
    category: String,
    onSaveFile: (FileAttachmentEntity) -> Unit
) = withContext(Dispatchers.IO) {
    try {
        val vaultDir = File(context.filesDir, "vault")
        vaultDir.mkdirs()

        val time = System.currentTimeMillis()
        val originalName = uri.lastPathSegment?.substringAfterLast('/') ?: "file"
        val fileName = if (originalName.contains(".")) originalName else "file_$time"
        val destFile = File(vaultDir, "jlab_${time}_$fileName")

        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(destFile).use { output ->
                input.copyTo(output)
            }
        }

        val mimeType = context.contentResolver.getType(uri) ?: "application/octet-stream"
        val friendlyName = when (category) {
            "Screenshot" -> "Screenshot • " + SimpleDateFormat("MMM d, h:mm a", Locale.getDefault()).format(Date(time))
            "PDF" -> fileName.removePrefix("jlab_${time}_")
            else -> fileName.removePrefix("jlab_${time}_")
        }

        val entity = FileAttachmentEntity(
            name = friendlyName,
            localFilePath = destFile.absolutePath,
            mimeType = mimeType,
            sizeBytes = destFile.length(),
            category = category
        )
        onSaveFile(entity)

        withContext(Dispatchers.Main) {
            Toast.makeText(context, "Imported $category to Jlab Vault!", Toast.LENGTH_SHORT).show()
        }
    } catch (e: Exception) {
        withContext(Dispatchers.Main) {
            Toast.makeText(context, "Failed to import file: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}

package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.entity.*
import com.example.data.model.Priority
import java.util.Calendar

enum class CaptureType(val label: String, val icon: ImageVector) {
    TASK("Task", Icons.Default.CheckCircle),
    NOTE("Note", Icons.Default.Description),
    IDEA("Idea", Icons.Default.Lightbulb),
    PROMPT("Prompt", Icons.Default.AutoAwesome),
    PLAN("Plan", Icons.Default.EventNote),
    PROJECT("Project", Icons.Default.Folder),
    REMINDER("Reminder", Icons.Default.Alarm),
    FILE("File", Icons.Default.AttachFile)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuickCaptureSheet(
    onDismiss: () -> Unit,
    onSaveTask: (TaskEntity) -> Unit,
    onSaveNote: (NoteEntity) -> Unit,
    onSaveProject: (ProjectEntity) -> Unit,
    onSavePlan: (PlanEntity) -> Unit,
    onSavePrompt: (PromptEntity) -> Unit
) {
    var selectedType by remember { mutableStateOf(CaptureType.TASK) }
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var selectedPriority by remember { mutableStateOf("MEDIUM") }
    var category by remember { mutableStateOf("General") }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Quick Capture",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Type Selector
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(CaptureType.values()) { type ->
                    val isSelected = selectedType == type
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedType = type },
                        label = { Text(type.label) },
                        leadingIcon = {
                            Icon(
                                imageVector = type.icon,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text(if (selectedType == CaptureType.NOTE) "Note Title" else "Title / Thought") },
                placeholder = {
                    Text(
                        when (selectedType) {
                            CaptureType.TASK -> "e.g., Review contract draft"
                            CaptureType.IDEA -> "e.g., Explore Kotlin Multiplatform idea"
                            CaptureType.PROJECT -> "e.g., Q4 App Redesign"
                            CaptureType.PLAN -> "e.g., Week 40 Sprint Plan"
                            CaptureType.PROMPT -> "e.g., High-Converting Headline Generator"
                            CaptureType.REMINDER -> "e.g., Call accountant at 3 PM"
                            CaptureType.FILE -> "e.g., Quarterly Report File Note"
                            else -> "Enter title..."
                        }
                    )
                },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = {
                    Text(
                        if (selectedType == CaptureType.PROMPT) "Full Prompt Text"
                        else "Details / Description / Script"
                    )
                },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3,
                maxLines = 5,
                shape = RoundedCornerShape(12.dp)
            )

            if (selectedType == CaptureType.TASK || selectedType == CaptureType.REMINDER) {
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Priority:",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    listOf("LOW", "MEDIUM", "HIGH", "CRITICAL").forEach { p ->
                        val isPSelected = selectedPriority == p
                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { selectedPriority = p },
                            color = if (isPSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Text(
                                text = p,
                                color = if (isPSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = {
                    if (title.isBlank()) return@Button
                    when (selectedType) {
                        CaptureType.TASK -> {
                            onSaveTask(
                                TaskEntity(
                                    title = title.trim(),
                                    description = description.trim(),
                                    priority = selectedPriority,
                                    status = "PLANNED",
                                    category = category,
                                    dueDate = System.currentTimeMillis()
                                )
                            )
                        }
                        CaptureType.IDEA -> {
                            onSaveTask(
                                TaskEntity(
                                    title = title.trim(),
                                    description = description.trim(),
                                    status = "INBOX",
                                    category = "Idea",
                                    isQuickTodo = true
                                )
                            )
                        }
                        CaptureType.FILE -> {
                            onSaveNote(
                                NoteEntity(
                                    title = title.trim(),
                                    content = description.trim(),
                                    category = "Files"
                                )
                            )
                        }
                        CaptureType.REMINDER -> {
                            val inOneHour = System.currentTimeMillis() + (60 * 60 * 1000L)
                            onSaveTask(
                                TaskEntity(
                                    title = title.trim(),
                                    description = description.trim(),
                                    priority = "HIGH",
                                    status = "PLANNED",
                                    dueDate = inOneHour,
                                    reminderTimestamp = inOneHour
                                )
                            )
                        }
                        CaptureType.NOTE -> {
                            onSaveNote(
                                NoteEntity(
                                    title = title.trim(),
                                    content = description.trim(),
                                    category = "Personal"
                                )
                            )
                        }
                        CaptureType.PROJECT -> {
                            onSaveProject(
                                ProjectEntity(
                                    name = title.trim(),
                                    objective = description.trim(),
                                    status = "ACTIVE"
                                )
                            )
                        }
                        CaptureType.PLAN -> {
                            onSavePlan(
                                PlanEntity(
                                    title = title.trim(),
                                    planType = "WEEKLY",
                                    goals = description.trim()
                                )
                            )
                        }
                        CaptureType.PROMPT -> {
                            onSavePrompt(
                                PromptEntity(
                                    title = title.trim(),
                                    fullPrompt = description.ifBlank { title.trim() },
                                    category = "Coding"
                                )
                            )
                        }
                    }
                    onDismiss()
                },
                enabled = title.isNotBlank(),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(imageVector = Icons.Default.Bolt, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "Capture to Jlab", fontWeight = FontWeight.Bold)
            }
        }
    }
}

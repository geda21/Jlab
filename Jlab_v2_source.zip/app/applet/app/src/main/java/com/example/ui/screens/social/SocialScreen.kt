package com.example.ui.screens.social

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.SocialContentEntity
import com.example.ui.components.EmptyState
import com.example.ui.components.JlabTopBar
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SocialScreen(
    items: List<SocialContentEntity>,
    onSaveItem: (SocialContentEntity) -> Unit,
    onDeleteItem: (String) -> Unit,
    onNavigateBack: () -> Unit
) {
    var selectedStage by remember { mutableStateOf("ALL") }
    var selectedItem by remember { mutableStateOf<SocialContentEntity?>(null) }
    var editingItem by remember { mutableStateOf<SocialContentEntity?>(null) }
    var isCreatingNew by remember { mutableStateOf(false) }

    val stages = listOf("ALL", "IDEA", "DRAFTING", "READY", "SCHEDULED", "PUBLISHED")

    BackHandler {
        when {
            editingItem != null || isCreatingNew -> {
                editingItem = null
                isCreatingNew = false
            }
            selectedItem != null -> {
                selectedItem = null
            }
            else -> onNavigateBack()
        }
    }

    // 1. Full-screen Content Editor
    if (editingItem != null || isCreatingNew) {
        SocialEditorScreen(
            initialItem = editingItem,
            onSave = { saved ->
                onSaveItem(saved)
                selectedItem = saved
                editingItem = null
                isCreatingNew = false
            },
            onCancel = {
                editingItem = null
                isCreatingNew = false
            }
        )
        return
    }

    // 2. Content Detail View
    if (selectedItem != null) {
        val current = items.find { it.id == selectedItem!!.id } ?: selectedItem!!
        SocialDetailScreen(
            item = current,
            onEdit = { editingItem = current },
            onDelete = {
                onDeleteItem(current.id)
                selectedItem = null
            },
            onAdvanceStatus = { nextStatus ->
                val updated = current.copy(status = nextStatus, updatedAt = System.currentTimeMillis())
                onSaveItem(updated)
                selectedItem = updated
            },
            onBack = { selectedItem = null }
        )
        return
    }

    // 3. Pipeline List View
    val filtered = remember(items, selectedStage) {
        if (selectedStage == "ALL") items else items.filter { it.status.equals(selectedStage, ignoreCase = true) }
    }

    Scaffold(
        topBar = {
            JlabTopBar(
                title = "Social Content Pipeline",
                subtitle = "${items.size} pieces in content engine",
                navigationIcon = Icons.AutoMirrored.Filled.ArrowBack,
                onNavigationClick = onNavigateBack,
                actions = {
                    IconButton(onClick = { isCreatingNew = true }) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "New Content")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Pipeline Stage Filter with live item counts
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                stages.forEach { stage ->
                    val isSelected = selectedStage.equals(stage, ignoreCase = true)
                    val count = if (stage == "ALL") items.size else items.count { it.status.equals(stage, ignoreCase = true) }

                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedStage = stage },
                        label = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(stage, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal)
                                if (count > 0) {
                                    Surface(
                                        shape = CircleShape,
                                        color = if (isSelected) MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant
                                    ) {
                                        Text(
                                            text = "$count",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                                        )
                                    }
                                }
                            }
                        },
                        shape = RoundedCornerShape(8.dp)
                    )
                }
            }

            if (filtered.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    EmptyState(
                        icon = Icons.Default.Share,
                        title = if (selectedStage != "ALL") "No $selectedStage content" else "No content yet",
                        message = "Turn raw ideas into published posts, videos, threads, and newsletters across platforms.",
                        actionButtonText = "Create Content Idea",
                        onActionClick = { isCreatingNew = true }
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filtered, key = { it.id }) { item ->
                        SocialCard(
                            item = item,
                            onClick = { selectedItem = item },
                            onAdvanceStatus = { nextStatus ->
                                onSaveItem(item.copy(status = nextStatus, updatedAt = System.currentTimeMillis()))
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SocialCard(
    item: SocialContentEntity,
    onClick: () -> Unit,
    onAdvanceStatus: (String) -> Unit
) {
    val platformColor = when (item.platform.lowercase()) {
        "youtube" -> Color(0xFFEF4444)
        "linkedin" -> Color(0xFF0A66C2)
        "tiktok" -> Color(0xFF000000)
        "instagram" -> Color(0xFFE1306C)
        "x", "twitter" -> Color(0xFF1D9BF0)
        "telegram" -> Color(0xFF229ED9)
        else -> MaterialTheme.colorScheme.primary
    }

    val statusColor = when (item.status.uppercase()) {
        "IDEA" -> JlabAmber
        "DRAFTING" -> Color(0xFF8B5CF6)
        "READY" -> JlabCyan
        "SCHEDULED" -> JlabIndigoPrimary
        "PUBLISHED" -> JlabEmerald
        else -> MaterialTheme.colorScheme.primary
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header Row: Platform + Type + Status
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = platformColor.copy(alpha = 0.15f)
                    ) {
                        Text(
                            text = item.platform,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = platformColor,
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Text(
                            text = item.contentType,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = statusColor.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = item.status,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = statusColor,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Title / Hook
            Text(
                text = item.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            // Snippet of script or idea
            val previewText = item.scriptOrCaption.ifBlank { item.idea }
            if (previewText.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = previewText,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    lineHeight = 18.sp
                )
            }

            if (item.tags.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    item.tags.split(",").take(3).forEach { t ->
                        val clean = t.trim()
                        if (clean.isNotBlank()) {
                            Text(
                                text = "#$clean",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SocialDetailScreen(
    item: SocialContentEntity,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onAdvanceStatus: (String) -> Unit,
    onBack: () -> Unit
) {
    var showDeleteConfirm by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(item.title, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = onEdit) {
                        Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit")
                    }
                    IconButton(onClick = { showDeleteConfirm = true }) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Badges row
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = RoundedCornerShape(6.dp), color = MaterialTheme.colorScheme.primaryContainer) {
                    Text(item.platform, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp))
                }
                Surface(shape = RoundedCornerShape(6.dp), color = MaterialTheme.colorScheme.secondaryContainer) {
                    Text(item.contentType, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp))
                }
                Surface(shape = RoundedCornerShape(6.dp), color = JlabEmerald.copy(alpha = 0.15f)) {
                    Text(item.status, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = JlabEmerald, modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp))
                }
            }

            // Hook / Title
            Column {
                Text("HOOK / TITLE", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.height(2.dp))
                Text(item.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }

            // Script or Caption
            if (item.scriptOrCaption.isNotBlank()) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("SCRIPT / CAPTION", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Text("${item.scriptOrCaption.length} chars", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(item.scriptOrCaption, style = MaterialTheme.typography.bodyLarge, lineHeight = 24.sp)
                    }
                }
            }

            // Call to Action
            if (item.callToAction.isNotBlank()) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("CALL TO ACTION (CTA)", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(item.callToAction, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }

            // Advance pipeline stage
            Text("Advance Pipeline Status", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("IDEA", "DRAFTING", "READY", "SCHEDULED", "PUBLISHED").forEach { st ->
                    OutlinedButton(
                        onClick = { onAdvanceStatus(st) },
                        enabled = !item.status.equals(st, ignoreCase = true),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(st)
                    }
                }
            }
        }
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Delete Content Draft?") },
            text = { Text("Delete \"${item.title}\"?") },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirm = false
                        onDelete()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) { Text("Cancel") }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SocialEditorScreen(
    initialItem: SocialContentEntity?,
    onSave: (SocialContentEntity) -> Unit,
    onCancel: () -> Unit
) {
    var title by remember { mutableStateOf(initialItem?.title ?: "") }
    var platform by remember { mutableStateOf(initialItem?.platform ?: "LinkedIn") }
    var contentType by remember { mutableStateOf(initialItem?.contentType ?: "Post") }
    var status by remember { mutableStateOf(initialItem?.status ?: "IDEA") }
    var idea by remember { mutableStateOf(initialItem?.idea ?: "") }
    var script by remember { mutableStateOf(initialItem?.scriptOrCaption ?: "") }
    var cta by remember { mutableStateOf(initialItem?.callToAction ?: "") }
    var tags by remember { mutableStateOf(initialItem?.tags ?: "") }

    val platforms = listOf("LinkedIn", "YouTube", "TikTok", "X", "Instagram", "Telegram", "Facebook", "Other")
    val contentTypes = listOf("Post", "Short Video", "Long Video", "Carousel", "Thread", "Story", "Live", "Educational", "Promo")
    val statuses = listOf("IDEA", "DRAFTING", "READY", "SCHEDULED", "PUBLISHED")

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (initialItem == null) "New Content" else "Edit Content", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onCancel) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Cancel")
                    }
                },
                actions = {
                    Button(
                        onClick = {
                            if (title.isNotBlank()) {
                                val entity = (initialItem ?: SocialContentEntity(title = title)).copy(
                                    title = title.trim(),
                                    platform = platform,
                                    contentType = contentType,
                                    status = status,
                                    idea = idea.trim(),
                                    scriptOrCaption = script.trim(),
                                    callToAction = cta.trim(),
                                    tags = tags.trim(),
                                    updatedAt = System.currentTimeMillis()
                                )
                                onSave(entity)
                            }
                        },
                        enabled = title.isNotBlank()
                    ) {
                        Text("Save Draft")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Hook / Working Title *") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            // Platform Selector
            Text("Platform", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                platforms.forEach { p ->
                    FilterChip(
                        selected = platform.equals(p, ignoreCase = true),
                        onClick = { platform = p },
                        label = { Text(p) }
                    )
                }
            }

            // Content Type Selector
            Text("Content Format", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                contentTypes.forEach { ct ->
                    FilterChip(
                        selected = contentType.equals(ct, ignoreCase = true),
                        onClick = { contentType = ct },
                        label = { Text(ct) }
                    )
                }
            }

            // Status Selector
            Text("Pipeline Stage", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                statuses.forEach { st ->
                    FilterChip(
                        selected = status.equals(st, ignoreCase = true),
                        onClick = { status = st },
                        label = { Text(st) }
                    )
                }
            }

            // Script / Caption editor
            OutlinedTextField(
                value = script,
                onValueChange = { script = it },
                label = { Text("Script / Full Caption Body") },
                modifier = Modifier
                    .fillMaxWidth()
                    .defaultMinSize(minHeight = 150.dp),
                minLines = 6
            )

            // Call to Action
            OutlinedTextField(
                value = cta,
                onValueChange = { cta = it },
                label = { Text("Call to Action (CTA)") },
                placeholder = { Text("e.g. Comment 'GUIDE' below to receive the PDF") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            // Tags
            OutlinedTextField(
                value = tags,
                onValueChange = { tags = it },
                label = { Text("Hashtags / Keywords") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

package com.example.ui.screens.learning

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.*
import com.example.ui.components.EmptyState
import com.example.ui.theme.*
import kotlinx.coroutines.flow.Flow
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LearningScreen(
    items: List<LearningEntity>,
    allLessons: List<LearningLessonEntity> = emptyList(),
    notes: List<NoteEntity> = emptyList(),
    files: List<FileAttachmentEntity> = emptyList(),
    getModulesForCourse: (String) -> Flow<List<LearningModuleEntity>>,
    getLessonsForCourse: (String) -> Flow<List<LearningLessonEntity>>,
    onSaveItem: (LearningEntity) -> Unit,
    onDeleteItem: (String) -> Unit,
    onSaveModule: (LearningModuleEntity) -> Unit,
    onDeleteModule: (String) -> Unit,
    onSaveLesson: (LearningLessonEntity) -> Unit,
    onDeleteLesson: (String, String) -> Unit,
    onToggleLessonCompleted: (String, String, Boolean) -> Unit,
    onOpenNote: (NoteEntity) -> Unit,
    onCreateCourseNote: (String) -> Unit,
    onOpenResource: (FileAttachmentEntity) -> Unit,
    onAttachResource: (String) -> Unit,
    onNavigateBack: () -> Unit
) {
    var selectedCourse by remember { mutableStateOf<LearningEntity?>(null) }
    var selectedLesson by remember { mutableStateOf<LearningLessonEntity?>(null) }

    var searchQuery by remember { mutableStateOf("") }
    var selectedCategoryFilter by remember { mutableStateOf("ALL") }
    val filterTabs = listOf("ALL", "COURSES", "SKILLS", "BOOKS", "COMPLETED")

    var showCreateCourseDialog by remember { mutableStateOf(false) }

    // Synchronize selectedCourse with updated state in items
    val currentCourse = remember(items, selectedCourse) {
        selectedCourse?.let { sc -> items.find { it.id == sc.id } ?: sc }
    }

    // Back handling hierarchy: Lesson -> Course Detail -> Learning Home -> Main App
    BackHandler {
        when {
            selectedLesson != null -> selectedLesson = null
            selectedCourse != null -> selectedCourse = null
            else -> onNavigateBack()
        }
    }

    // 1. LESSON WORKSPACE VIEW
    if (currentCourse != null && selectedLesson != null) {
        val courseLessons by getLessonsForCourse(currentCourse.id).collectAsState(initial = emptyList())
        val courseModules by getModulesForCourse(currentCourse.id).collectAsState(initial = emptyList())
        val currentModule = courseModules.find { it.id == selectedLesson!!.moduleId }

        LessonWorkspaceScreen(
            courseTitle = currentCourse.title,
            moduleTitle = currentModule?.title ?: "Module",
            lesson = selectedLesson!!,
            allLessonsInCourse = courseLessons,
            onUpdateLesson = { updated ->
                onSaveLesson(updated)
                selectedLesson = updated
            },
            onToggleCompleted = { isCompleted ->
                onToggleLessonCompleted(selectedLesson!!.id, currentCourse.id, isCompleted)
                selectedLesson = selectedLesson!!.copy(
                    isCompleted = isCompleted,
                    completedAt = if (isCompleted) System.currentTimeMillis() else null
                )
            },
            onSelectLesson = { nextLesson ->
                selectedLesson = nextLesson
            },
            onBack = { selectedLesson = null }
        )
        return
    }

    // 2. COURSE DETAIL VIEW
    if (currentCourse != null) {
        val courseModules by getModulesForCourse(currentCourse.id).collectAsState(initial = emptyList())
        val courseLessons by getLessonsForCourse(currentCourse.id).collectAsState(initial = emptyList())
        val courseNotes = remember(notes, currentCourse.id) { notes.filter { it.learningId == currentCourse.id } }
        val courseFiles = remember(files, currentCourse.id) { files.filter { it.learningId == currentCourse.id } }

        CourseDetailScreen(
            course = currentCourse,
            modules = courseModules,
            lessons = courseLessons,
            notes = courseNotes,
            resources = courseFiles,
            onUpdateCourse = { updated ->
                onSaveItem(updated)
                selectedCourse = updated
            },
            onDeleteCourse = {
                onDeleteItem(currentCourse.id)
                selectedCourse = null
            },
            onSaveModule = onSaveModule,
            onDeleteModule = onDeleteModule,
            onSaveLesson = onSaveLesson,
            onDeleteLesson = { lessonId -> onDeleteLesson(lessonId, currentCourse.id) },
            onToggleLessonCompleted = { lessonId, isDone ->
                onToggleLessonCompleted(lessonId, currentCourse.id, isDone)
            },
            onOpenLesson = { lesson -> selectedLesson = lesson },
            onOpenNote = onOpenNote,
            onCreateCourseNote = { onCreateCourseNote(currentCourse.id) },
            onOpenResource = onOpenResource,
            onAttachResource = { onAttachResource(currentCourse.id) },
            onBack = { selectedCourse = null }
        )
        return
    }

    // 3. LEARNING HOME VIEW
    val activeCourses = remember(items) { items.filter { it.status == "LEARNING" || it.status == "NOT_STARTED" } }
    val completedCourses = remember(items) { items.filter { it.status == "COMPLETED" } }
    val completedLessonsTotal = remember(allLessons) { allLessons.count { it.isCompleted } }

    val filteredItems = remember(items, searchQuery, selectedCategoryFilter) {
        var list = items
        if (selectedCategoryFilter != "ALL") {
            list = when (selectedCategoryFilter) {
                "COMPLETED" -> list.filter { it.status == "COMPLETED" }
                "COURSES" -> list.filter { it.type.contains("Course", ignoreCase = true) }
                "SKILLS" -> list.filter { it.type.contains("Skill", ignoreCase = true) }
                "BOOKS" -> list.filter { it.type.contains("Book", ignoreCase = true) || it.type.contains("Resource", ignoreCase = true) }
                else -> list
            }
        }
        if (searchQuery.isNotBlank()) {
            val q = searchQuery.trim().lowercase()
            list = list.filter {
                it.title.lowercase().contains(q) ||
                it.goal.lowercase().contains(q) ||
                it.type.lowercase().contains(q)
            }
        }
        list
    }

    // Continue Learning Target (most recently updated active course or first course)
    val continueCourse = remember(items) {
        items.firstOrNull { it.status == "LEARNING" && it.progressPercent < 100 }
            ?: items.firstOrNull { it.progressPercent in 1..99 }
            ?: items.firstOrNull { it.status == "NOT_STARTED" }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Learning",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Build skills systematically",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { showCreateCourseDialog = true }) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Add Course", tint = MaterialTheme.colorScheme.primary)
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Search Bar
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search courses, skills, goals...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // Stats Metrics Row
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    MetricChip(
                        title = "Active",
                        value = "${activeCourses.size}",
                        icon = Icons.Outlined.School,
                        modifier = Modifier.weight(1f)
                    )
                    MetricChip(
                        title = "Completed",
                        value = "${completedCourses.size}",
                        icon = Icons.Outlined.CheckCircle,
                        modifier = Modifier.weight(1f)
                    )
                    MetricChip(
                        title = "Lessons Done",
                        value = "$completedLessonsTotal",
                        icon = Icons.Outlined.DoneAll,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Continue Learning Hero Card
            if (continueCourse != null && searchQuery.isBlank() && selectedCategoryFilter == "ALL") {
                item {
                    val courseLessons = allLessons.filter { it.learningId == continueCourse.id }
                    val nextLesson = courseLessons.firstOrNull { !it.isCompleted }
                    val completedInCourse = courseLessons.count { it.isCompleted }
                    val totalInCourse = courseLessons.size

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedCourse = continueCourse },
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = MaterialTheme.colorScheme.primary
                                ) {
                                    Text(
                                        text = "CONTINUE LEARNING",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onPrimary,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                    )
                                }

                                Text(
                                    text = "${continueCourse.progressPercent}%",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = continueCourse.title,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )

                            if (nextLesson != null) {
                                Text(
                                    text = "Up next: ${nextLesson.title}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            } else if (totalInCourse > 0) {
                                Text(
                                    text = "$completedInCourse of $totalInCourse lessons completed",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            LinearProgressIndicator(
                                progress = { continueCourse.progressPercent / 100f },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = MaterialTheme.colorScheme.primary
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                Button(
                                    onClick = { selectedCourse = continueCourse },
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                                ) {
                                    Text("Continue", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Icon(Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }

            // Filter Chips
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    filterTabs.forEach { tab ->
                        FilterChip(
                            selected = selectedCategoryFilter == tab,
                            onClick = { selectedCategoryFilter = tab },
                            label = { Text(tab) }
                        )
                    }
                }
            }

            // Courses List
            if (filteredItems.isEmpty()) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(vertical = 32.dp), contentAlignment = Alignment.Center) {
                        EmptyState(
                            icon = Icons.Default.School,
                            title = if (searchQuery.isNotEmpty()) "No matching courses" else "No courses found",
                            message = "Create a course or skill roadmap to organize modules, lessons, and dedicated study notes.",
                            actionButtonText = "Create Course",
                            onActionClick = { showCreateCourseDialog = true }
                        )
                    }
                }
            } else {
                items(filteredItems, key = { it.id }) { course ->
                    val courseLessons = allLessons.filter { it.learningId == course.id }
                    val totalL = courseLessons.size
                    val completedL = courseLessons.count { it.isCompleted }

                    CompactCourseCard(
                        course = course,
                        lessonsCount = totalL,
                        completedLessons = completedL,
                        onClick = { selectedCourse = course },
                        onDelete = { onDeleteItem(course.id) }
                    )
                }
            }
        }
    }

    if (showCreateCourseDialog) {
        CreateCourseDialog(
            onDismiss = { showCreateCourseDialog = false },
            onSave = { newCourse ->
                onSaveItem(newCourse)
                showCreateCourseDialog = false
                selectedCourse = newCourse
            }
        )
    }
}

@Composable
private fun CompactCourseCard(
    course: LearningEntity,
    lessonsCount: Int,
    completedLessons: Int,
    onClick: () -> Unit,
    onDelete: () -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CourseStatusPill(status = course.status)
                    Text(
                        text = course.type,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Box {
                    IconButton(onClick = { showMenu = true }, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.MoreVert, contentDescription = "Options", modifier = Modifier.size(16.dp))
                    }
                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Open Workspace") },
                            onClick = {
                                showMenu = false
                                onClick()
                            },
                            leadingIcon = { Icon(Icons.Default.OpenInNew, contentDescription = null) }
                        )
                        HorizontalDivider()
                        DropdownMenuItem(
                            text = { Text("Delete Course", color = MaterialTheme.colorScheme.error) },
                            onClick = {
                                showMenu = false
                                onDelete()
                            },
                            leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = course.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            if (course.goal.isNotBlank()) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = course.goal,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (lessonsCount > 0) "$completedLessons / $lessonsCount lessons" else "Curriculum ready",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "${course.progressPercent}%",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            LinearProgressIndicator(
                progress = { course.progressPercent / 100f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp)),
                color = MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Continue →",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

@Composable
private fun MetricChip(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
            Column {
                Text(text = value, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Text(text = title, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun CreateCourseDialog(
    onDismiss: () -> Unit,
    onSave: (LearningEntity) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("Course") }
    var goal by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create New Course", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Course Title *") },
                    placeholder = { Text("e.g. Modern Android Architecture") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = type,
                    onValueChange = { type = it },
                    label = { Text("Type / Level") },
                    placeholder = { Text("e.g. Course, Beginner → Advanced, Book") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = goal,
                    onValueChange = { goal = it },
                    label = { Text("Primary Objective / Target") },
                    placeholder = { Text("e.g. Build reactive offline-first apps") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description") },
                    placeholder = { Text("Curriculum overview & roadmap notes") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        onSave(
                            LearningEntity(
                                title = title.trim(),
                                type = type.trim().ifBlank { "Course" },
                                goal = goal.trim(),
                                description = description.trim(),
                                status = "NOT_STARTED",
                                progressPercent = 0,
                                startDate = System.currentTimeMillis()
                            )
                        )
                    }
                },
                enabled = title.isNotBlank()
            ) {
                Text("Create Course")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

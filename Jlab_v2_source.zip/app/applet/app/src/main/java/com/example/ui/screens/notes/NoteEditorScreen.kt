package com.example.ui.screens.notes

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.FormatListBulleted
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.NoteEntity
import com.example.ui.theme.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoteEditorScreen(
    initialNote: NoteEntity?,
    existingCategories: List<String>,
    onSaveNote: (NoteEntity, Boolean) -> Unit,
    onMoveToTrash: (() -> Unit)? = null,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val isNewNote = initialNote == null

    // Load initial note with structured document spans (or converts legacy markup once)
    val (initialPlain, initialSpans) = remember(initialNote) {
        RichTextDocument.parseLegacyContentToDocument(
            initialNote?.content ?: "",
            initialNote?.formattingJson
        )
    }

    var title by remember { mutableStateOf(initialNote?.title ?: "") }
    var contentValue by remember { mutableStateOf(TextFieldValue(initialPlain)) }
    var documentSpans by remember { mutableStateOf(initialSpans) }
    var category by remember { mutableStateOf(initialNote?.category ?: "Personal") }
    var isPinned by remember { mutableStateOf(initialNote?.isPinned ?: false) }
    var isFavorite by remember { mutableStateOf(initialNote?.isFavorite ?: false) }

    // Active typing modes when NO text is selected
    var activeTypingBold by remember { mutableStateOf(false) }
    var activeTypingItalic by remember { mutableStateOf(false) }
    var activeTypingUnderline by remember { mutableStateOf(false) }
    var activeTypingStrikethrough by remember { mutableStateOf(false) }
    var activeTypingHighlight by remember { mutableStateOf<String?>(null) }

    var isSaved by remember { mutableStateOf(!isNewNote) }
    var hasUnsavedChanges by remember { mutableStateOf(false) }
    var isPreviewMode by remember { mutableStateOf(false) }

    var showExitConfirmDialog by remember { mutableStateOf(false) }
    var showCategorySheet by remember { mutableStateOf(false) }
    var showHighlightPicker by remember { mutableStateOf(false) }
    var showStyleMenu by remember { mutableStateOf(false) }
    var showListMenu by remember { mutableStateOf(false) }
    var showMoreMenu by remember { mutableStateOf(false) }
    var showNoteInfoDialog by remember { mutableStateOf(false) }

    val contentFocusRequester = remember { FocusRequester() }

    // Crash-Safe Temporary Draft handling
    val draftFile = remember { File(context.cacheDir, "jlab_note_draft.tmp") }

    fun clearDraft() {
        try {
            if (draftFile.exists()) draftFile.delete()
        } catch (_: Exception) {}
    }

    fun saveDraftLocally() {
        try {
            if (hasUnsavedChanges && (title.isNotBlank() || contentValue.text.isNotBlank())) {
                val jsonSpans = RichTextDocument.spansToJson(documentSpans)
                draftFile.writeText("$title\n---JLAB_DRAFT_SPLIT---\n${contentValue.text}\n---JLAB_SPANS_SPLIT---\n$jsonSpans")
            }
        } catch (_: Exception) {}
    }

    // Monitor changes against initial state
    LaunchedEffect(title, contentValue.text, documentSpans, category, isPinned, isFavorite) {
        val changed = if (isNewNote) {
            title.isNotBlank() || contentValue.text.isNotBlank() || documentSpans.isNotEmpty()
        } else {
            title != (initialNote?.title ?: "") ||
            contentValue.text != initialPlain ||
            documentSpans != initialSpans ||
            category != (initialNote?.category ?: "Personal") ||
            isPinned != (initialNote?.isPinned ?: false) ||
            isFavorite != (initialNote?.isFavorite ?: false)
        }
        hasUnsavedChanges = changed
        if (changed) {
            isSaved = false
            saveDraftLocally()
        }
    }

    // Manual Save execution
    fun performSave(shouldExit: Boolean = false) {
        val trimmedTitle = title.trim()
        val plainContent = contentValue.text

        // If user didn't enter a title, derive from the first line of content
        val finalTitle = if (trimmedTitle.isNotBlank()) {
            trimmedTitle
        } else {
            val firstLine = plainContent.lineSequence()
                .map { it.trim() }
                .firstOrNull { it.isNotBlank() }
            if (!firstLine.isNullOrBlank()) {
                firstLine.take(50)
            } else {
                "Untitled Note"
            }
        }

        val words = if (plainContent.isBlank()) 0 else plainContent.trim().split(Regex("\\s+")).size
        val chars = plainContent.length
        val serializedSpans = RichTextDocument.spansToJson(documentSpans)

        val noteToSave = if (isNewNote) {
            NoteEntity(
                id = UUID.randomUUID().toString(),
                title = finalTitle,
                content = plainContent,
                formattingJson = serializedSpans,
                category = category,
                isPinned = isPinned,
                isFavorite = isFavorite,
                wordCount = words,
                charCount = chars,
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )
        } else {
            initialNote!!.copy(
                title = finalTitle,
                content = plainContent,
                formattingJson = serializedSpans,
                category = category,
                isPinned = isPinned,
                isFavorite = isFavorite,
                wordCount = words,
                charCount = chars,
                updatedAt = System.currentTimeMillis()
            )
        }

        onSaveNote(noteToSave, isNewNote)
        hasUnsavedChanges = false
        isSaved = true
        title = finalTitle
        clearDraft()
        Toast.makeText(context, "Note saved", Toast.LENGTH_SHORT).show()

        if (shouldExit) {
            onBack()
        }
    }

    // Handle back action safely
    fun handleBack() {
        if (!hasUnsavedChanges) {
            clearDraft()
            onBack()
            return
        }
        // If it's a new note and both title and body are completely empty
        if (isNewNote && title.isBlank() && contentValue.text.isBlank()) {
            clearDraft()
            onBack()
            return
        }
        showExitConfirmDialog = true
    }

    BackHandler {
        handleBack()
    }

    // Selection ranges
    val selStart = minOf(contentValue.selection.start, contentValue.selection.end)
    val selEnd = maxOf(contentValue.selection.start, contentValue.selection.end)
    val hasSelection = selStart != selEnd

    // Format active state checks
    val isBoldActive = if (hasSelection) {
        RichTextDocument.isTypeActive(documentSpans, selStart, selEnd, DocumentSpan.TYPE_BOLD)
    } else activeTypingBold

    val isItalicActive = if (hasSelection) {
        RichTextDocument.isTypeActive(documentSpans, selStart, selEnd, DocumentSpan.TYPE_ITALIC)
    } else activeTypingItalic

    val isUnderlineActive = if (hasSelection) {
        RichTextDocument.isTypeActive(documentSpans, selStart, selEnd, DocumentSpan.TYPE_UNDERLINE)
    } else activeTypingUnderline

    val isStrikethroughActive = if (hasSelection) {
        RichTextDocument.isTypeActive(documentSpans, selStart, selEnd, DocumentSpan.TYPE_STRIKETHROUGH)
    } else activeTypingStrikethrough

    val isHighlightActive = if (hasSelection) {
        documentSpans.any { it.type == DocumentSpan.TYPE_HIGHLIGHT && it.start <= selStart && it.end >= selEnd }
    } else (activeTypingHighlight != null)

    // Formatting Actions on selection or typing mode
    fun toggleBold() {
        if (hasSelection) {
            documentSpans = RichTextDocument.toggleSpan(documentSpans, selStart, selEnd, DocumentSpan.TYPE_BOLD)
            hasUnsavedChanges = true
            isSaved = false
        } else {
            activeTypingBold = !activeTypingBold
        }
    }

    fun toggleItalic() {
        if (hasSelection) {
            documentSpans = RichTextDocument.toggleSpan(documentSpans, selStart, selEnd, DocumentSpan.TYPE_ITALIC)
            hasUnsavedChanges = true
            isSaved = false
        } else {
            activeTypingItalic = !activeTypingItalic
        }
    }

    fun toggleUnderline() {
        if (hasSelection) {
            documentSpans = RichTextDocument.toggleSpan(documentSpans, selStart, selEnd, DocumentSpan.TYPE_UNDERLINE)
            hasUnsavedChanges = true
            isSaved = false
        } else {
            activeTypingUnderline = !activeTypingUnderline
        }
    }

    fun toggleStrikethrough() {
        if (hasSelection) {
            documentSpans = RichTextDocument.toggleSpan(documentSpans, selStart, selEnd, DocumentSpan.TYPE_STRIKETHROUGH)
            hasUnsavedChanges = true
            isSaved = false
        } else {
            activeTypingStrikethrough = !activeTypingStrikethrough
        }
    }

    fun applyHighlight(colorHex: String?) {
        if (hasSelection) {
            if (colorHex == null) {
                documentSpans = documentSpans.filterNot {
                    it.type == DocumentSpan.TYPE_HIGHLIGHT && it.start >= selStart && it.end <= selEnd
                }
            } else {
                documentSpans = RichTextDocument.toggleSpan(documentSpans, selStart, selEnd, DocumentSpan.TYPE_HIGHLIGHT, colorHex)
            }
            hasUnsavedChanges = true
            isSaved = false
        } else {
            activeTypingHighlight = colorHex
        }
        showHighlightPicker = false
    }

    fun applyBlockStyle(type: String?) {
        val text = contentValue.text
        val lineStart = text.lastIndexOf('\n', (selStart - 1).coerceAtLeast(0)).let { if (it == -1) 0 else it + 1 }
        val lineEnd = text.indexOf('\n', selEnd).let { if (it == -1) text.length else it }
        if (lineEnd > lineStart) {
            val filtered = documentSpans.filterNot {
                (it.type == DocumentSpan.TYPE_HEADING_1 ||
                 it.type == DocumentSpan.TYPE_HEADING_2 ||
                 it.type == DocumentSpan.TYPE_HEADING_3 ||
                 it.type == DocumentSpan.TYPE_QUOTE ||
                 it.type == DocumentSpan.TYPE_CODE) &&
                it.start >= lineStart && it.end <= lineEnd
            }
            documentSpans = if (type != null) {
                filtered + DocumentSpan(lineStart, lineEnd, type)
            } else {
                filtered
            }
            hasUnsavedChanges = true
            isSaved = false
        }
        showStyleMenu = false
    }

    fun insertLinePrefix(prefix: String) {
        val text = contentValue.text
        val lineStart = text.lastIndexOf('\n', (selStart - 1).coerceAtLeast(0)).let { if (it == -1) 0 else it + 1 }
        val newText = text.substring(0, lineStart) + prefix + text.substring(lineStart)
        // Shift spans that start after lineStart
        val shift = prefix.length
        documentSpans = documentSpans.map { s ->
            if (s.start >= lineStart) {
                s.copy(start = s.start + shift, end = s.end + shift)
            } else if (s.end > lineStart) {
                s.copy(end = s.end + shift)
            } else s
        }
        contentValue = TextFieldValue(newText, TextRange(selStart + shift))
        hasUnsavedChanges = true
        isSaved = false
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = if (isNewNote) "New Note" else "Edit Note",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        // Status badge (Saved / Unsaved)
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (isSaved && !hasUnsavedChanges) JlabEmerald.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Text(
                                text = if (isSaved && !hasUnsavedChanges) "Saved" else "Unsaved",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isSaved && !hasUnsavedChanges) JlabEmerald else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { handleBack() }) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    // Preview / Edit Toggle
                    IconButton(onClick = { isPreviewMode = !isPreviewMode }) {
                        Icon(
                            imageVector = if (isPreviewMode) Icons.Default.Edit else Icons.Default.Visibility,
                            contentDescription = if (isPreviewMode) "Edit Mode" else "Preview Mode",
                            tint = if (isPreviewMode) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                        )
                    }

                    // Prominent Save Button
                    Button(
                        onClick = { performSave(shouldExit = false) },
                        enabled = hasUnsavedChanges || (title.isNotBlank() || contentValue.text.isNotBlank()),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary
                        )
                    ) {
                        Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }

                    // More Menu
                    Box {
                        IconButton(onClick = { showMoreMenu = true }) {
                            Icon(imageVector = Icons.Default.MoreVert, contentDescription = "More")
                        }
                        DropdownMenu(
                            expanded = showMoreMenu,
                            onDismissRequest = { showMoreMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text(if (isPinned) "Unpin Note" else "Pin Note") },
                                onClick = {
                                    isPinned = !isPinned
                                    showMoreMenu = false
                                },
                                leadingIcon = {
                                    Icon(
                                        imageVector = if (isPinned) Icons.Default.PushPin else Icons.Outlined.PushPin,
                                        contentDescription = null
                                    )
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Note Details") },
                                onClick = {
                                    showMoreMenu = false
                                    showNoteInfoDialog = true
                                },
                                leadingIcon = { Icon(Icons.Outlined.Info, contentDescription = null) }
                            )
                            if (onMoveToTrash != null && !isNewNote) {
                                HorizontalDivider()
                                DropdownMenuItem(
                                    text = { Text("Move to Trash", color = MaterialTheme.colorScheme.error) },
                                    onClick = {
                                        showMoreMenu = false
                                        onMoveToTrash()
                                    },
                                    leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) }
                                )
                            }
                        }
                    }
                }
            )
        },
        bottomBar = {
            if (!isPreviewMode) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .imePadding()
                        .navigationBarsPadding(),
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 3.dp,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        // Bold
                        FormatToggleButton(
                            label = "B",
                            isActive = isBoldActive,
                            fontWeight = FontWeight.Bold,
                            onClick = { toggleBold() }
                        )

                        // Italic
                        FormatToggleButton(
                            label = "I",
                            isActive = isItalicActive,
                            fontStyle = FontStyle.Italic,
                            fontWeight = FontWeight.Bold,
                            onClick = { toggleItalic() }
                        )

                        // Underline
                        FormatToggleButton(
                            label = "U",
                            isActive = isUnderlineActive,
                            textDecoration = TextDecoration.Underline,
                            fontWeight = FontWeight.Bold,
                            onClick = { toggleUnderline() }
                        )

                        // Highlight Marker
                        Box {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isHighlightActive) RichTextDocument.HighlightYellow.copy(alpha = 0.5f) else Color.Transparent,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { showHighlightPicker = true }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.BorderColor,
                                        contentDescription = "Highlight",
                                        modifier = Modifier.size(18.dp),
                                        tint = if (isHighlightActive) Color.Black else MaterialTheme.colorScheme.onSurface
                                    )
                                    Icon(
                                        imageVector = Icons.Default.ArrowDropDown,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp),
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            DropdownMenu(
                                expanded = showHighlightPicker,
                                onDismissRequest = { showHighlightPicker = false }
                            ) {
                                Text(
                                    text = "Highlight Color",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                                )
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    // Clear highlight
                                    ColorSwatch(
                                        color = MaterialTheme.colorScheme.surfaceVariant,
                                        hasBorder = true,
                                        onClick = { applyHighlight(null) }
                                    )
                                    // Yellow
                                    ColorSwatch(color = RichTextDocument.HighlightYellow, onClick = { applyHighlight("#FFF176") })
                                    // Green
                                    ColorSwatch(color = RichTextDocument.HighlightGreen, onClick = { applyHighlight("#A5D6A7") })
                                    // Blue
                                    ColorSwatch(color = RichTextDocument.HighlightBlue, onClick = { applyHighlight("#90CAF9") })
                                    // Pink
                                    ColorSwatch(color = RichTextDocument.HighlightPink, onClick = { applyHighlight("#F48FB1") })
                                    // Purple
                                    ColorSwatch(color = RichTextDocument.HighlightPurple, onClick = { applyHighlight("#CE93D8") })
                                }
                            }
                        }

                        VerticalDivider(modifier = Modifier.height(24.dp).padding(horizontal = 2.dp))

                        // Text Style (Aa)
                        Box {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color.Transparent,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { showStyleMenu = true }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Aa", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp))
                                }
                            }

                            DropdownMenu(
                                expanded = showStyleMenu,
                                onDismissRequest = { showStyleMenu = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("Normal Text") },
                                    onClick = { applyBlockStyle(null) }
                                )
                                DropdownMenuItem(
                                    text = { Text("Heading 1", fontSize = 18.sp, fontWeight = FontWeight.Bold) },
                                    onClick = { applyBlockStyle(DocumentSpan.TYPE_HEADING_1) }
                                )
                                DropdownMenuItem(
                                    text = { Text("Heading 2", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                                    onClick = { applyBlockStyle(DocumentSpan.TYPE_HEADING_2) }
                                )
                                DropdownMenuItem(
                                    text = { Text("Heading 3", fontSize = 14.sp, fontWeight = FontWeight.Bold) },
                                    onClick = { applyBlockStyle(DocumentSpan.TYPE_HEADING_3) }
                                )
                                DropdownMenuItem(
                                    text = { Text("Quote", fontStyle = FontStyle.Italic) },
                                    onClick = { applyBlockStyle(DocumentSpan.TYPE_QUOTE) }
                                )
                                DropdownMenuItem(
                                    text = { Text("Code Block", fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace) },
                                    onClick = { applyBlockStyle(DocumentSpan.TYPE_CODE) }
                                )
                            }
                        }

                        // Lists
                        Box {
                            IconButton(onClick = { showListMenu = true }) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.List,
                                    contentDescription = "Lists",
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            DropdownMenu(
                                expanded = showListMenu,
                                onDismissRequest = { showListMenu = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("Bullet List") },
                                    onClick = {
                                        insertLinePrefix("• ")
                                        showListMenu = false
                                    },
                                    leadingIcon = { Icon(Icons.AutoMirrored.Filled.FormatListBulleted, contentDescription = null) }
                                )
                                DropdownMenuItem(
                                    text = { Text("Numbered List") },
                                    onClick = {
                                        insertLinePrefix("1. ")
                                        showListMenu = false
                                    },
                                    leadingIcon = { Icon(Icons.Default.FormatListNumbered, contentDescription = null) }
                                )
                                DropdownMenuItem(
                                    text = { Text("Checklist") },
                                    onClick = {
                                        insertLinePrefix("- [ ] ")
                                        showListMenu = false
                                    },
                                    leadingIcon = { Icon(Icons.Outlined.CheckBox, contentDescription = null) }
                                )
                            }
                        }

                        // Strikethrough
                        IconButton(onClick = { toggleStrikethrough() }) {
                            Icon(
                                imageVector = Icons.Default.FormatStrikethrough,
                                contentDescription = "Strikethrough",
                                modifier = Modifier.size(19.dp),
                                tint = if (isStrikethroughActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                            )
                        }

                        // Divider
                        IconButton(onClick = { insertLinePrefix("\n---\n") }) {
                            Icon(imageVector = Icons.Default.HorizontalRule, contentDescription = "Divider", modifier = Modifier.size(19.dp))
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Compact Header metadata bar: Category chip + Pinned badge
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Category Pill
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.6f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { showCategorySheet = true }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Folder, contentDescription = null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.primary)
                        Text(
                            text = category,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                        Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(14.dp))
                    }
                }

                if (isPinned) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(imageVector = Icons.Default.PushPin, contentDescription = null, modifier = Modifier.size(12.dp), tint = MaterialTheme.colorScheme.primary)
                            Text("Pinned", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            HorizontalDivider(
                modifier = Modifier.padding(horizontal = 20.dp),
                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)
            )

            if (isPreviewMode) {
                // Reading / Preview Mode with pure rich native text (NO raw markdown)
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(20.dp)
                ) {
                    Text(
                        text = if (title.isBlank()) "Untitled Note" else title,
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    if (contentValue.text.isBlank()) {
                        Text(
                            text = "Empty note",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                            fontStyle = FontStyle.Italic
                        )
                    } else {
                        // Render lines with checklists support
                        val lines = contentValue.text.lines()
                        var charOffset = 0

                        lines.forEachIndexed { index, line ->
                            val lineLen = line.length
                            val lineSpans = documentSpans.filter {
                                it.start < charOffset + lineLen && it.end > charOffset
                            }.map { s ->
                                s.copy(
                                    start = (s.start - charOffset).coerceAtLeast(0),
                                    end = (s.end - charOffset).coerceAtMost(lineLen)
                                )
                            }

                            when {
                                line.startsWith("- [ ] ") || line.startsWith("- [x] ") -> {
                                    val isChecked = line.startsWith("- [x] ")
                                    val checkText = line.removePrefix("- [ ] ").removePrefix("- [x] ")
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 2.dp)
                                            .clickable {
                                                val newPrefix = if (isChecked) "- [ ] " else "- [x] "
                                                val updatedLines = lines.toMutableList()
                                                updatedLines[index] = newPrefix + checkText
                                                contentValue = TextFieldValue(updatedLines.joinToString("\n"))
                                                hasUnsavedChanges = true
                                                isSaved = false
                                            }
                                    ) {
                                        Checkbox(
                                            checked = isChecked,
                                            onCheckedChange = { checked ->
                                                val newPrefix = if (checked) "- [x] " else "- [ ] "
                                                val updatedLines = lines.toMutableList()
                                                updatedLines[index] = newPrefix + checkText
                                                contentValue = TextFieldValue(updatedLines.joinToString("\n"))
                                                hasUnsavedChanges = true
                                                isSaved = false
                                            }
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = RichTextDocument.documentToAnnotatedString(checkText, lineSpans, isDarkTheme = false),
                                            style = MaterialTheme.typography.bodyMedium,
                                            textDecoration = if (isChecked) TextDecoration.LineThrough else TextDecoration.None,
                                            color = if (isChecked) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                                line == "---" -> {
                                    HorizontalDivider(
                                        modifier = Modifier.padding(vertical = 8.dp),
                                        color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                                    )
                                }
                                line.startsWith("• ") || line.startsWith("- ") -> {
                                    val itemText = line.removePrefix("• ").removePrefix("- ")
                                    Row(modifier = Modifier.padding(vertical = 2.dp)) {
                                        Text("• ", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                        Text(
                                            text = RichTextDocument.documentToAnnotatedString(itemText, lineSpans, isDarkTheme = false),
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                    }
                                }
                                else -> {
                                    if (line.isNotBlank()) {
                                        Text(
                                            text = RichTextDocument.documentToAnnotatedString(line, lineSpans, isDarkTheme = false),
                                            style = MaterialTheme.typography.bodyMedium,
                                            modifier = Modifier.padding(vertical = 2.dp)
                                        )
                                    } else {
                                        Spacer(modifier = Modifier.height(8.dp))
                                    }
                                }
                            }
                            charOffset += lineLen + 1
                        }
                    }
                }
            } else {
                // Native Rich Editing Mode
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp, vertical = 12.dp)
                ) {
                    // Note Title input
                    BasicTextField(
                        value = title,
                        onValueChange = { title = it },
                        textStyle = MaterialTheme.typography.headlineSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        ),
                        cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                        singleLine = false,
                        maxLines = 3,
                        decorationBox = { innerTextField ->
                            if (title.isEmpty()) {
                                Text(
                                    text = "Title",
                                    style = MaterialTheme.typography.headlineSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                                    )
                                )
                            }
                            innerTextField()
                        },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Note Body input with native VisualTransformation
                    BasicTextField(
                        value = contentValue,
                        onValueChange = { newTv ->
                            val oldText = contentValue.text
                            val newText = newTv.text
                            if (oldText != newText) {
                                val diff = newText.length - oldText.length
                                val changeIndex = minOf(contentValue.selection.start, newTv.selection.start)
                                val updatedSpans = mutableListOf<DocumentSpan>()

                                for (span in documentSpans) {
                                    if (span.end <= changeIndex) {
                                        updatedSpans.add(span)
                                    } else if (span.start >= changeIndex + (if (diff < 0) -diff else 0)) {
                                        val newStart = (span.start + diff).coerceAtLeast(0)
                                        val newEnd = (span.end + diff).coerceAtLeast(newStart)
                                        if (newEnd > newStart) updatedSpans.add(span.copy(start = newStart, end = newEnd))
                                    } else {
                                        val newEnd = (span.end + diff).coerceAtLeast(span.start)
                                        if (newEnd > span.start) updatedSpans.add(span.copy(end = newEnd))
                                    }
                                }

                                if (diff > 0) {
                                    val typedStart = changeIndex
                                    val typedEnd = changeIndex + diff
                                    if (activeTypingBold) updatedSpans.add(DocumentSpan(typedStart, typedEnd, DocumentSpan.TYPE_BOLD))
                                    if (activeTypingItalic) updatedSpans.add(DocumentSpan(typedStart, typedEnd, DocumentSpan.TYPE_ITALIC))
                                    if (activeTypingUnderline) updatedSpans.add(DocumentSpan(typedStart, typedEnd, DocumentSpan.TYPE_UNDERLINE))
                                    if (activeTypingStrikethrough) updatedSpans.add(DocumentSpan(typedStart, typedEnd, DocumentSpan.TYPE_STRIKETHROUGH))
                                    if (activeTypingHighlight != null) updatedSpans.add(DocumentSpan(typedStart, typedEnd, DocumentSpan.TYPE_HIGHLIGHT, activeTypingHighlight))
                                }

                                documentSpans = RichTextDocument.mergeContiguousSpans(updatedSpans)
                                hasUnsavedChanges = true
                                isSaved = false
                            }
                            contentValue = newTv
                        },
                        visualTransformation = RichTextDocument.DocumentVisualTransformation(
                            spans = documentSpans,
                            isDarkTheme = false
                        ),
                        textStyle = MaterialTheme.typography.bodyLarge.copy(
                            color = MaterialTheme.colorScheme.onSurface,
                            lineHeight = 24.sp
                        ),
                        cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                        modifier = Modifier
                            .fillMaxWidth()
                            .defaultMinSize(minHeight = 350.dp)
                            .focusRequester(contentFocusRequester),
                        decorationBox = { innerTextField ->
                            if (contentValue.text.isEmpty()) {
                                Text(
                                    text = "Type your thoughts, ideas, plans...\nSelect text and use the toolbar below to format.",
                                    style = MaterialTheme.typography.bodyLarge.copy(
                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                                        lineHeight = 24.sp
                                    )
                                )
                            }
                            innerTextField()
                        }
                    )
                }
            }
        }
    }

    // Unsaved Changes Confirmation Dialog
    if (showExitConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showExitConfirmDialog = false },
            title = {
                Text("Unsaved changes", fontWeight = FontWeight.Bold)
            },
            text = {
                Text("Save this note before leaving?")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showExitConfirmDialog = false
                        performSave(shouldExit = true)
                    }
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(
                        onClick = { showExitConfirmDialog = false }
                    ) {
                        Text("Cancel")
                    }
                    TextButton(
                        onClick = {
                            showExitConfirmDialog = false
                            clearDraft()
                            onBack()
                        },
                        colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                    ) {
                        Text("Discard")
                    }
                }
            }
        )
    }

    // Category Bottom Sheet
    if (showCategorySheet) {
        var newCategoryName by remember { mutableStateOf("") }
        var showAddCustomCategory by remember { mutableStateOf(false) }

        val allCategories = remember(existingCategories) {
            (listOf("Personal", "Learning", "Business", "Development", "Ideas", "Reference") + existingCategories).distinct()
        }

        ModalBottomSheet(
            onDismissRequest = { showCategorySheet = false },
            sheetState = rememberModalBottomSheetState()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Select Category",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                allCategories.forEach { cat ->
                    val isSelected = cat.equals(category, ignoreCase = true)
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .clickable {
                                category = cat
                                showCategorySheet = false
                            }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = cat,
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                            )
                            if (isSelected) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }

                if (!showAddCustomCategory) {
                    TextButton(
                        onClick = { showAddCustomCategory = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Add Custom Category")
                    }
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = newCategoryName,
                            onValueChange = { newCategoryName = it },
                            placeholder = { Text("Category name") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        Button(
                            onClick = {
                                if (newCategoryName.isNotBlank()) {
                                    category = newCategoryName.trim()
                                    showCategorySheet = false
                                }
                            },
                            enabled = newCategoryName.isNotBlank()
                        ) {
                            Text("Use")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }

    // Note Details Dialog
    if (showNoteInfoDialog) {
        val plain = contentValue.text
        val wordCount = if (plain.isBlank()) 0 else plain.trim().split(Regex("\\s+")).size
        val charCount = plain.length
        val createdDateStr = SimpleDateFormat("MMM d, yyyy HH:mm", Locale.getDefault()).format(Date(initialNote?.createdAt ?: System.currentTimeMillis()))
        val updatedDateStr = SimpleDateFormat("MMM d, yyyy HH:mm", Locale.getDefault()).format(Date(initialNote?.updatedAt ?: System.currentTimeMillis()))

        AlertDialog(
            onDismissRequest = { showNoteInfoDialog = false },
            title = { Text("Note Details", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("• Words: $wordCount", style = MaterialTheme.typography.bodyMedium)
                    Text("• Characters: $charCount", style = MaterialTheme.typography.bodyMedium)
                    Text("• Category: $category", style = MaterialTheme.typography.bodyMedium)
                    Text("• Created: $createdDateStr", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("• Last Modified: $updatedDateStr", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            confirmButton = {
                TextButton(onClick = { showNoteInfoDialog = false }) {
                    Text("Close")
                }
            }
        )
    }
}

@Composable
private fun FormatToggleButton(
    label: String,
    isActive: Boolean,
    fontWeight: FontWeight? = null,
    fontStyle: FontStyle? = null,
    textDecoration: TextDecoration? = null,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = if (isActive) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
        border = if (isActive) BorderStroke(1.dp, MaterialTheme.colorScheme.primary) else null,
        modifier = Modifier
            .size(36.dp)
            .clip(RoundedCornerShape(8.dp))
            .clickable { onClick() }
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = label,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = fontWeight ?: FontWeight.Normal,
                    fontStyle = fontStyle,
                    textDecoration = textDecoration,
                    color = if (isActive) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                )
            )
        }
    }
}

@Composable
private fun ColorSwatch(
    color: Color,
    hasBorder: Boolean = false,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(28.dp)
            .clip(CircleShape)
            .background(color)
            .then(
                if (hasBorder) Modifier.padding(1.dp) else Modifier
            )
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        if (hasBorder) {
            Icon(Icons.Default.Clear, contentDescription = "Clear", modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
